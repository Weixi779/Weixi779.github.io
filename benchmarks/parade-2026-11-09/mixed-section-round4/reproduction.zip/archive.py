# -*- coding: utf-8 -*-
# Created by weixi on 2026/11/09.
from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
r=Path(__file__).parent;repo=Path('/Users/sunshiwei/Develop/Parade')
out=Path('/Users/sunshiwei/Develop/Weixi779.github.io/public/benchmarks/parade-2026-11-09/mixed-section-round4');out.mkdir(exist_ok=True)
rows=json.loads((r/'summary.json').read_text());lookup={(x['variant'],x['n'],x['scenario'],x['engine']):x for x in rows}
def row(v,n,s,e='Current-staged'):return lookup[v,n,s,e]
def num(v,n,s,k='totalMs',e='Current-staged'):return f'{row(v,n,s,e).get(k,0):.3f}'
def table(head,body):return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,x))+' |' for x in body])
scenarios=[('new-section-move1','新建 Section，移入并更新 1 项'),('new-section-move5pct','新建 Section，移入并更新 5%'),('delete-section-transfer','删除 Section，迁出并更新其中全部 10%'),('replace-section','替换一个 Section，迁移并更新其中全部 10%'),('section-reorder-transfer','Section 重排＋跨组迁移并更新 5%'),('section-churn','Section 增删、重排和跨组迁移混合'),('replace-all-sections','替换全部 Section，保留并更新全部 Item'),('existing-cross-update','已有 Section 之间迁移并更新 5%'),('rotate-control','单 Section 左旋一项，对照')]
controls=['Current-Apple-adapter','Current-Apple-background','Current-ListKit']
for v in ['baseline','indexed']:
 for n in [100,1000,10000]:
  for s,_ in scenarios:
   for e in ['Current-staged']+controls:assert row(v,n,s,e)['runs']==3
test=(r/'indexed-package/test.log').read_text();testline=next(x for x in test.splitlines() if 'Test run with' in x);assert '164 tests in 14 suites passed' in testline
for x in rows:
 if x['engine']!='Current-ListKit':assert x['selectionFailures']==0
probe=json.loads((r/'indexedProbe/mixed-7-0.json').read_text());assert probe['complete'] and len(probe['records'])==20
probeRows=[]
for x in probe['records']:
 if x['engine']=='Current-staged':
  a=x['samples'][0];assert a['selectedIDs']==['A'] and all(a['retainedCells'].values()) and a['batches']==1
  probeRows.append([x['scenario'],int(a['batches']),int(a['itemMoves']),','.join(a['selectedIDs']),str(a['retainedCells'])])
ablation=[]
for s,label in scenarios:
 values=[]
 for v in ['baseline','merged','indexed']:
  a=next(x for x in row(v,10000,s)['runMedians'] if x['repetition']==1)
  values.append(f"{a['totalMs']:.3f} / {int(a['batches'])}")
 ablation.append([label]+values)
profileKeys=[('packInputMs','主线程投影身份与内容'),('diffMs','后台 Diff'),('mixedReplayMs','后台混合操作回放检查'),('materializeMs','主线程还原展示引用与内容计划'),('structureApplyMs','结构批次执行与完成等待'),('contentApplyMs','内容更新与同步布局'),('indexInstallMs','其中：安装位置索引')]
text=[
'# 复杂 Section 更新：合并结构批次与复用已有索引',
'2026-11-09。生产 Parade 基线 `dedfb5907f54890b3e0b11da99610e933cea5508` 保持干净。全部实验在临时副本；默认实现、公开 API、文章均未修改。本轮 baseline 是上一轮 lean 临时版，已经包含 LIS、简单结构整数规划及无动画内容快速路径。',
'## 三个版本',
table(['版本','变化'],[['baseline','沿用上一轮 lean；复杂 Section 增删仍回到对象快照和多阶段计划。'],['merged','Section 增删、移动及跨组 Item 移动合成一个结构批次。用旧坐标描述删除／移动起点，新坐标描述插入／移动终点。仍在结构完成后更新内容。'],['indexed','在 merged 上复用 CollectionSnapshot 捕获时已经生成的位置索引：规划读取源快照索引，单个结构批次直接安装目标快照索引。外部自定义算法仍使用原来的分阶段和校验路径。']]),
'混合批次省去的是为了复用旧规划器而构造的 WorkerPresenter、完整对象快照、重复对象索引和分阶段坐标转换。保留全局 Item 身份以及跨新建／删除 Section 的显式移动；没有将其替换为 delete＋insert。',
'索引复用没有跳过输入身份检查：捕获快照原本就要检查并生成位置表。现在保留这份表，而不在后续规划和 DataSource 安装时再次构造。代价是快照额外持有位置字典；共享通过 Swift 值语义／COW 完成，不是跨线程共享可变字典。本轮未测峰值内存，不能将此收益描述成零成本。',
'## 场景与对照',
'每个规模初始有 10 个 Section，Item 均匀分组，身份全局唯一。迁移项改变 revision；整组替换也保留 Item 身份并改变内容。另保留已有 Section 跨组移动和单 Section 左旋对照。计时前选中第一条消息，它在全部场景中存活；完成后核对选中身份。',
'所有后端共享目标 Presenter 捕获、注册、展示视图和验证。ListKit 使用 Iron-Ham/Lists `221e1513f2786a4e5e836c9b76092c3bd6e61575` 原始六个源码文件，没有修改其算法。ListKit 走精确批次更新路径，不使用 apply(false) 的 reloadData 分支。原生后台沿用上一轮固定串行队列的 completion API 实验；SDK 的 MainActor 注解问题没有因此解决。',
'三个规模、九个场景；baseline 与 indexed 各三轮独立进程，每组预热 3 次、正式 10 次。merged 仅在 10,000 项做一轮消融。每进程四种后端随机顺序，版本交错运行。完整耗时包含目标捕获／注册、规划、apply 完成等待与最终 layoutIfNeeded；不包含业务 SectionController 捕获、外层 Orchestrator 排队，以及 host 在计时后替换 previous 快照的收尾。',
'## 完整更新耗时',
'单位毫秒。每行取三轮组内中位数的中位数；系统与 ListKit 取 indexed 同进程对照。',
table(['项数','场景','上轮临时版','本轮 indexed','系统主线程','系统后台','ListKit'],[[n,label,num('baseline',n,s),num('indexed',n,s)]+[num('indexed',n,s,e=e) for e in controls] for n in [100,1000,10000] for s,label in scenarios]),
'小规模相近数值不能据此宣称稳定胜负。不同场景的操作和语义也有差异，特别是 ListKit 在新建／删除 Section 中使用整组增删，下面列出状态检查结果。',
'## 选中状态检查',
table(['规模','场景','本轮失败次数／样本','系统主线程','系统后台','ListKit'],[[n,label]+[f"{row('indexed',n,s,e)['selectionFailures']} / {row('indexed',n,s,e)['samples']}" for e in ['Current-staged']+controls] for n in [100,1000,10000] for s,label in scenarios]),
'ListKit 在已有 Section 之间能保留选中身份，但涉及新建／删除 Section 的本组场景会丢失选中状态。最终内容仍通过检查。比较耗时时保留这些原始结果，不将状态不一致的低耗时说成语义等价的胜负。',
'## 合并批次与索引复用分别带来多少',
'以下是首轮消融，每格为“完整耗时 ms / UIKit 批次数”。只作为机制定位；最终比较使用上面的三轮数据。',
table(['场景','baseline','只合并结构 merged','再复用索引 indexed'],ablation),
'## 最终版本内部耗时',
'以下为 10,000 项三轮中位数。indexInstallMs 包含在结构阶段中，不能重复相加；后台各分项也包含在 workerWaitMs 中。各项独立取中位数，合计不必等于整体中位数；目标捕获、调度和释放开销等另包含在完整更新内。',
table(['步骤','新 Section＋1 项','混合 Section 变化','全部 Section 替换'],[[label]+[num('indexed',10000,s,'detail.'+key) for s in ['new-section-move1','section-churn','replace-all-sections']] for key,label in profileKeys]),
'全量更换 Section 的场景保留一万条 Item，执行一万次显式移动。它仍是本轮最重的一项；ListKit 的整组删除／插入做了更少的移动，却没有保留选中状态。当前结果不支持“所有场景全面超过 ListKit”的结论。',
'## 混合计划怎样验证',
'先按旧坐标删除、移动 Section，再按新坐标填入新 Section，并核对重放后的 Section 身份。对 Item 分别维护旧位置是否消费和目标位置的槽位；移动必须由旧数据取身份，不能用目标内容假装重放成功。保留 Section 内未显式移动的 Item 按原顺序补入；新 Section 中未被移动填入的项必须是全新身份。最后逐项核对目标身份和实际供 DataSource 使用的批次内容。',
'随整个 Section 消失的真正删除项、随新 Section 出现的真正新增项，由 Section 操作覆盖，不再重复调用 Item 增删。全局存活的 Item 即使一端 Section 消失或新建，也仍需显式移动。内容比较与 Cell 类型兼容性判断仍走原流程。',
'## 状态和内容时序验证',
testline,
'在前一轮 162 项基础上新增两项测试：一项以有／无动画分别验证跨新旧 Section 移动，结构批次完成回调中检查旧正文和选中状态，最终再检查新正文、同一 Cell 对象和 reconfigure；另一项运行 300 次固定随机 Section 增删／重排／跨组移动与内容变化，核对所有选中存活项、每项最终位置和可见内容。',
'原有批次验证器明确禁止 Section 和 Item 操作共用一批，所以不能直接拿它回放新格式。实验属性测试仍先用旧独立规划器验证同一份 Diff，再用混合回放验证器检查新计划；现有 UIKit 结构／内容／Cell 类型替换／补充视图／FIFO 测试也运行。',
'初次测试的随机 UI 用例没有把初始化与正式更新分开计数，记录到一次 reload，因计数断言失败；选中身份和内容断言没有失败。随后先建立可见初始列表，再清零计数，最终 300 次更新的 reload 计数为零。两次日志保留，未隐藏初次失败。',
'另用最终 indexed 源码复跑五个可见状态探针，全部结构操作合为一批：',
table(['场景','批次','Item move','最终选中 ID','兼容可见 Cell 对象保留'],probeRows),
'原生适配也能把 Section 增删和 Item 移动放入同一结构批次；内容更新可能产生后续批次。我们的有动画路径继续保留内容阶段完成等待，无动画路径在结构完成后直接更新内容并同步布局。',
'## 实验限制与复现',
'同一 iPhone 18 Pro／iOS 27.0 模拟器、M4 Max 宿主机、Xcode 27.1，320×480 视口、36 高 label Cell、FlowLayout，关闭动画和预取。每次样本初始化后 flush 并等待 30 ms。计时期间 reloadData 必须为零；结束后验证 Section／Item 身份数量与可见 Cell revision。',
'这是固定无动画场景的相对性能实验，不能代替真实设备的 CPU／帧时间表现。未测真实首页、持续滚动、峰值内存、所有支持的 OS，以及生产压力下的动画完成时机。带动画行为测试通过不等于已测动画性能。',
'reproduction.zip 包含三种计时版本、最终状态探针、完整 Swift 6 测试包、原始样本、构建日志、哈希和第三方许可证。先运行 ListKit/build.py，再构建相应版本的 build.py；`python3 run.py baseline,indexed 100,1000,10000 1,2,3` 复测；`python3 run_probe.py indexedProbe` 运行状态探针。脚本查找已启动的 iPhone 18 Pro。',
'patches/ 保存最终临时实现和测试相对生产基线的差异，因此包含前几轮优化；default implementation 未变。summary.json 保留各轮数据，summary.csv 可用于后续制图。'
]
(out/'README.md').write_text('\n\n'.join(text)+'\n')
for name in ['summary.json','summary.csv']:shutil.copy2(r/name,out/name)
shutil.copy2(r/'indexedProbe/mixed-7-0.json',out/'capability-probe.json')
(out/'patches').mkdir(exist_ok=True)
for part in ['Sources','Tests']:
 a=repo/part;b=r/'indexed-package'/part
 p=subprocess.run(['git','diff','--no-index','--',str(a),str(b)],capture_output=True,text=True);assert p.returncode in [0,1]
 patch=p.stdout
 for prefix in ['a','b']:
  for original in [str(a),str(b)]:patch=patch.replace(prefix+original,prefix+'/'+part)
 (out/'patches'/f'indexed-{part}.patch').write_text(patch)
validation={'tests':testline,'formalGroups':len(rows),'formalSamples':sum(x['samples'] for x in rows),'probeGroups':len(probe['records'])}
# Verify that the exact optimized library source was compiled in the test package.
for p in (r/'indexed/Sources/Parade').glob('*.swift'):
 name=p.name.split('-',1)[-1] if p.name[:3].isdigit() else p.name
 matches=list((r/'indexed-package/Sources/Parade').rglob(name));assert len(matches)==1 and p.read_bytes()==matches[0].read_bytes()
with zipfile.ZipFile(out/'reproduction.zip','w',zipfile.ZIP_DEFLATED) as z:
 for v in ['baseline','merged','indexed','probe','indexedProbe']:
  base=r/v;env=json.loads((base/'environment.json').read_text())
  for name,h in env['allSourceHashes'].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h
  assert hashlib.sha256((base/'ArticleBench.app/ArticleBench').read_bytes()).hexdigest()==env['binarySHA256']
  for p in (base/'Sources').rglob('*.swift'):z.write(p,v+'/'+str(p.relative_to(base)))
  for name in ['build.py','build.log']:z.write(base/name,v+'/'+name)
  for name in ['LICENSE-Parade','LICENSE-DifferenceKit']:z.write(Path('/tmp/parade-round2-20261109/lis')/name,v+'/'+name)
  for key in ['sourceHashes','selectedSimulator','otherBootedDevices']:env.pop(key,None)
  z.writestr(v+'/environment.json',json.dumps(env,indent=2))
  for p in base.glob('mixed-*-*.json'):z.write(p,v+'/'+p.name)
  for p in base.glob('mixed-*-*.log'):z.write(p,v+'/'+p.name)
  if (base/'probe.log').exists():z.write(base/'probe.log',v+'/probe.log')
 for p in (r/'ListKit').rglob('*'):
  if p.is_file() and 'ModuleCache' not in p.parts and (p.suffix=='.swift' or p.name in ['LICENSE','build.py','environment.json']):z.write(p,str(p.relative_to(r)))
 for p in r.glob('*.py'):z.write(p,p.name)
 for part in ['Sources','Tests']:
  for p in (r/'indexed-package'/part).rglob('*.swift'):z.write(p,str(p.relative_to(r)))
 for name in ['Package.swift','build.log','test.log']:z.write(r/'indexed-package'/name,'indexed-package/'+name)
 z.write(r/'merged-package/test.log','initial-test-failure.log')
 for p in (out/'patches').iterdir():z.write(p,'patches/'+p.name)
 for name in ['README.md','summary.json','summary.csv','capability-probe.json']:z.write(out/name,name)
with zipfile.ZipFile(out/'reproduction.zip') as z:assert z.testzip() is None
validation['reproductionSHA256']=hashlib.sha256((out/'reproduction.zip').read_bytes()).hexdigest()
validation['paradeStatus']=subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True);assert validation['paradeStatus']==''
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(validation);print(out)
