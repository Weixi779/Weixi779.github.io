// Created by weixi on 2026/11/05.
import UIKit

struct ArticlePresenter: CellPresenter {
    let item: UIItem
    var id: String { item.id }
    func configure(_ cell: BenchCell) { cell.configure(item) }
}
extension BenchItem: DiffableElement {}
struct AlgorithmSection: DiffableSection {
    let id = 0
    let items: [UIItem]
    func isContentEqual(to other: Self) -> Bool { true }
}
@MainActor final class ArticleCollection: UICollectionView {
    var forceReload = false
    var batches = 0
    var itemMoves = 0, sectionMoves = 0, reloadCalls = 0, reconfiguredItems = 0, reloadedItems = 0
    func resetCounters() { batches = 0; itemMoves = 0; sectionMoves = 0; reloadCalls = 0; reconfiguredItems = 0; reloadedItems = 0 }
    override func moveItem(at from: IndexPath, to: IndexPath) { itemMoves += 1; super.moveItem(at: from, to: to) }
    override func moveSection(_ section: Int, toSection newSection: Int) { sectionMoves += 1; super.moveSection(section, toSection: newSection) }
    override func reloadData() { reloadCalls += 1; super.reloadData() }
    override func reloadItems(at paths: [IndexPath]) { reloadedItems += paths.count; super.reloadItems(at: paths) }
    override func performBatchUpdates(_ updates: (() -> Void)?, completion: ((Bool) -> Void)? = nil) {
        batches += 1
        super.performBatchUpdates(updates, completion: completion)
    }
    override func reconfigureItems(at indexPaths: [IndexPath]) {
        reconfiguredItems += indexPaths.count
        if forceReload { super.reloadItems(at: indexPaths) }
        else { super.reconfigureItems(at: indexPaths) }
    }
}
// Minimal factory owner: identical production registrations and cell bridge,
// no business controllers, queue or behavior refresh included in this timing.
@MainActor final class CurrentHost: CollectionViewBridgeOwner {
    let collectionView: UICollectionView
    let registry = ViewRegistry()
    var eventHandler: (any CollectionEventHandler)? { nil }
    var scrollViewDelegate: (any UIScrollViewDelegate)? { nil }
    let bridge: CollectionViewBridge
    let source: any CollectionDataSource<Int>
    var previous = CollectionSnapshot<Int>.empty
    init(_ engine: String, container: UIView) {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 320,height: 36)
        layout.minimumLineSpacing = 0; layout.minimumInteritemSpacing = 0
        let view = ArticleCollection(frame: container.bounds,collectionViewLayout: layout)
        view.forceReload = engine == "Current-reload-control"
        collectionView = view; view.isPrefetchingEnabled = false
        bridge = CollectionViewBridge(collectionView: view)
        let views = CollectionViews(collectionView: view,bridge: bridge)
        if engine == "Current-Apple-adapter" { source = DiffableCollectionDataSource<Int>(collectionView: view,views: views) }
        else if engine == "Current-Apple-background" { source = BackgroundNativeDataSource<Int>(collectionView: view,views: views) }
        else if engine == "Current-ListKit" { source = ListKitAdapter<Int>(collectionView: view,views: views) }
        else { source = StagedCollectionDataSource<Int>(collectionView: view,views: views) }
        bridge.owner = self
        view.dataSource = source.dataSource; view.delegate = bridge
        container.addSubview(view)
    }
    func sectionId(at index: Int) -> AnyHashable? { source.sectionId(at:index) }
    func sectionDisplayIdentity(for sectionId: AnyHashable?) -> SectionDisplayIdentity? { nil }
    func cellPresenter(at path: IndexPath) -> AnyCellPresenter? { source.cellPresenter(at:path) }
    func supplementaryPresenter(ofKind kind: String, at path: IndexPath) -> AnySupplementaryPresenter? { nil }
    func synchronizeSectionDisplay() {}
    func report(_ diagnostic: CollectionDiagnostic) { preconditionFailure("Unexpected diagnostic") }
    func capture(_ sections:[UISection]) -> CollectionSnapshot<Int> {
        let snapshots = sections.map { section in
            let cells = section.elements.map { AnyCellPresenter(ArticlePresenter(item:$0)) }
            for cell in cells { registry.prepare(cell) }
            return SectionSnapshot(id:section.model.id,cells:cells,layout:0)
        }
        return try! CollectionSnapshot(snapshots)
    }
    func reset(_ sections:[UISection]) async {
        let target=capture(sections)
        let d=await source.apply(from:.empty,to:target,animated:false,mode:.reload)
        precondition(d.isEmpty);previous=target;collectionView.layoutIfNeeded()
        if let first = sections.first, !first.elements.isEmpty {
            collectionView.selectItem(at: IndexPath(item:0,section:0), animated:false, scrollPosition:[])
        }
    }
    func apply(_ sections:[UISection]) async -> [String:Any] {
        (collectionView as! ArticleCollection).resetCounters()
        BenchCell.configurations=0
        SpikeTimings.reset()
        let start=nanos()
        let target=capture(sections)
        let prepared=nanos()
        let d=await source.apply(from:previous,to:target,animated:false,mode:.diff)
        let completed=nanos()
        collectionView.layoutIfNeeded()
        let end=nanos()
        precondition(d.isEmpty)
        // No timed candidate may substitute reloadData for precise updates.
        precondition((collectionView as! ArticleCollection).reloadCalls == 0)
        precondition(collectionView.window != nil && !collectionView.visibleCells.isEmpty)
        precondition(collectionView.numberOfSections == sections.count)
        for (s,section) in sections.enumerated() {
            precondition(collectionView.numberOfItems(inSection:s)==section.elements.count)
            precondition(source.sectionId(at:s)==AnyHashable(section.model.id))
            for (i,item) in section.elements.enumerated() {
                precondition(source.cellPresenter(at:IndexPath(item:i,section:s))?.id==AnyHashable(item.id))
            }
        }
        for raw in collectionView.visibleCells {
            let cell=raw as! BenchCell;let path=collectionView.indexPath(for:cell)!
            let item=sections[path.section].elements[path.item]
            precondition(cell.renderedID==item.id && cell.renderedRevision==item.revision)
        }
        let selected = (collectionView.indexPathsForSelectedItems ?? []).compactMap { source.cellPresenter(at:$0)?.id }
        let expected = previous.sections.first?.cells.first?.id
        let preserved = expected.map { selected.contains($0) } ?? true
        if source is StagedCollectionDataSource<Int> { precondition(preserved) }
        previous=target
        return ["selectionPreserved":preserved,"totalMs":Double(end-start)/1e6,"prepareMs":Double(prepared-start)/1e6,
          "applyMs":Double(completed-prepared)/1e6,"layoutMs":Double(end-completed)/1e6,
          "batches":(collectionView as! ArticleCollection).batches,"configuredCells":BenchCell.configurations,
          "itemMoves":(collectionView as! ArticleCollection).itemMoves,
          "sectionMoves":(collectionView as! ArticleCollection).sectionMoves,
          "reloadCalls":(collectionView as! ArticleCollection).reloadCalls,
          "reconfiguredItems":(collectionView as! ArticleCollection).reconfiguredItems,
          "reloadedItems":(collectionView as! ArticleCollection).reloadedItems,
          "detail":SpikeTimings.detail,"planningMs":SpikeTimings.planningMs,"workerWaitMs":SpikeTimings.workerWaitMs,
          "mainPreparePlanMs":Double(prepared-start)/1e6+SpikeTimings.planningMs-SpikeTimings.workerWaitMs]
    }
}

@MainActor final class RunnerController: UIViewController {
    var started=false
    override func viewDidAppear(_ animated:Bool) {
        super.viewDidAppear(animated)
        if !started { started=true; Task { await run() } }
    }
    func run() async {
        UIView.setAnimationsEnabled(false)
        let container=UIView(frame:CGRect(x:0,y:0,width:320,height:480));view.addSubview(container)
        let args=CommandLine.arguments
        let repetition=Int(args[1])!, n=Int(args[2])!
        var rng=BenchRNG(state:UInt64(repetition)*81817+UInt64(n))
        var cases=scaleFixtures(n);cases.shuffle(using:&rng)
        var records:[[String:Any]]=[]
        var checksum=0
        func save(_ complete:Bool) {
            let result:[String:Any]=["complete":complete,"date":ISO8601DateFormatter().string(from:Date()),"repetition":repetition,"n":n,"cpuWarmups":3,"cpuRuns":20,"uiWarmups":3,"uiRuns":10,"os":UIDevice.current.systemVersion,"records":records,"checksum":checksum]
            let url=URL.documentsDirectory.appendingPathComponent("mixed-\(n)-\(repetition).json")
            try! JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]).write(to:url,options:.atomic)
        }
        for c in cases {
            let f=c.fixture
            var engines=["Current-staged","Current-Apple-adapter","Current-Apple-background","Current-ListKit"]
            var samples:[String:[[String:Any]]]=[:]
            for i in 0..<(repetition == 0 ? 1 : 13) {
                engines.shuffle(using:&rng)
                for e in engines {
                    if e.hasPrefix("Current") {
                        let host=CurrentHost(e,container:container);await host.reset(f.old)
                        CATransaction.flush();try! await Task.sleep(nanoseconds:30_000_000)
                        let sample=await host.apply(f.new)
                        if i >= (repetition == 0 ? 0 : 3) { samples[e,default:[]].append(sample) }
                        host.collectionView.removeFromSuperview()
                    } else {
                        let host=UIHost(engine:UIEngine(rawValue:e)!,container:container);await host.reset(f.old)
                        CATransaction.flush();try! await Task.sleep(nanoseconds:30_000_000)
                        host.configured=0;BenchCell.configurations=0
                        let sample=await host.apply(f)
                        if i >= (repetition == 0 ? 0 : 3) { samples[e,default:[]].append(sample) }
                        host.collection.removeFromSuperview()
                    }
                }
            }
            for e in engines { records.append(["lane":"ui","scenario":f.name,"engine":e,"n":n,"sections":f.old.count,"changeCount":c.changeCount,"changeMode":c.changeMode,"samples":samples[e]!]) }
            save(false)
            print("Completed n=\(n) rep=\(repetition) case=\(f.name)");fflush(stdout)
        }
        save(true);print("ROUND2_COMPLETE n=\(n) rep=\(repetition)");fflush(stdout);exit(0)
    }
}

@main @MainActor final class ArticleApp:UIResponder,UIApplicationDelegate {
    func application(_ application:UIApplication,configurationForConnecting session:UISceneSession,options:UIScene.ConnectionOptions)->UISceneConfiguration {
        let c=UISceneConfiguration(name:"Benchmark",sessionRole:session.role); c.delegateClass=ArticleScene.self; return c
    }
}
@MainActor final class ArticleScene:UIResponder,UIWindowSceneDelegate {
    var window:UIWindow?
    func scene(_ scene:UIScene,willConnectTo session:UISceneSession,options:UIScene.ConnectionOptions) {
        guard let scene=scene as? UIWindowScene else{return}
        let w=UIWindow(windowScene:scene); w.rootViewController=RunnerController(); window=w; w.makeKeyAndVisible()
    }
}
