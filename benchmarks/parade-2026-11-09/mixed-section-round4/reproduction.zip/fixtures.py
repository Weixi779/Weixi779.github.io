# Created by weixi on 2026/11/09.
from pathlib import Path
r=Path(__file__).parent
fixture='''// Created by weixi on 2026/11/09.
import Foundation
struct ScaleCase { let fixture: UIFixture; let changeCount: Int; let changeMode: String }
func scaleFixtures(_ n: Int) -> [ScaleCase] {
    let values = (0..<n).map { UIItem(id: "item-\\($0)") }
    let old = (0..<10).map { s in UISection(model: UIHeader(id:s), elements: Array(values[s*(n/10)..<(s+1)*(n/10)])) }
    var result: [ScaleCase] = []
    func add(_ name: String, _ source: [UISection], _ target: [UISection], _ changes: Int) {
        result.append(ScaleCase(fixture: UIFixture(name:name, old:source, new:target, flat:false),changeCount:changes,changeMode:"mixed-section"))
    }
    func changed(_ items: [UIItem]) -> [UIItem] { items.map { UIItem(id:$0.id,revision:$0.revision+1) } }
    for k in [1,n/20] {
        var target = old
        let moving = changed(Array(target[0].elements.prefix(k)))
        target[0].elements.removeFirst(k)
        target.insert(UISection(model:UIHeader(id:10),elements:moving),at:0)
        add(k == 1 ? "new-section-move1" : "new-section-move5pct",old,target,k)
    }
    var deleted = old
    let outgoing = changed(deleted.removeFirst().elements)
    deleted[0].elements.insert(contentsOf:outgoing,at:0)
    add("delete-section-transfer",old,deleted,outgoing.count)
    var replaced = old
    replaced[0] = UISection(model:UIHeader(id:10),elements:changed(replaced[0].elements))
    add("replace-section",old,replaced,n/10)
    var crossed = old
    let moved = changed(Array(crossed[0].elements.prefix(n/20)))
    crossed[0].elements.removeFirst(n/20);crossed[1].elements.insert(contentsOf:moved,at:0)
    add("existing-cross-update",old,crossed,moved.count)
    let reordered = Array(crossed.dropFirst()) + Array(crossed.prefix(1))
    add("section-reorder-transfer",old,reordered,moved.count)
    var churn = old
    let removed = churn.removeFirst()
    let half = n/20
    let fromSecond = Array(churn[0].elements.prefix(half))
    churn[0].elements.removeFirst(half)
    churn[1].elements.append(contentsOf:changed(Array(removed.elements.dropFirst(half))))
    churn.insert(UISection(model:UIHeader(id:10),elements:changed(Array(removed.elements.prefix(half))+fromSecond)),at:2)
    churn = Array(churn.dropFirst(3)) + Array(churn.prefix(3))
    add("section-churn",old,churn,n/10+half)
    let allNew = old.enumerated().map { s, section in
        UISection(model:UIHeader(id:s+10),elements:changed(section.elements))
    }
    add("replace-all-sections",old,allNew,n)
    let flatOld = [UISection(model:UIHeader(id:0),elements:values)]
    add("rotate-control",flatOld,[UISection(model:UIHeader(id:0),elements:Array(values.dropFirst())+Array(values.prefix(1)))],1)
    return result
}
'''
for v in ['baseline','merged']:
 d=r/v
 (d/'Sources/ScaleFixtures.swift').write_text(fixture)
 p=d/'Sources/ArticleMain.swift';s=p.read_text()
 start=s.index('var cases=scaleFixtures(n)');end=s.index(';cases.shuffle',start)
 s=s[:start]+'var cases=scaleFixtures(n)'+s[end:]
 s=s.replace('''precondition(d.isEmpty);previous=target;collectionView.layoutIfNeeded()''','''precondition(d.isEmpty);previous=target;collectionView.layoutIfNeeded()
        if let first = sections.first, !first.elements.isEmpty {
            collectionView.selectItem(at: IndexPath(item:0,section:0), animated:false, scrollPosition:[])
        }''')
 s=s.replace('''        previous=target
        return''','''        let selected = (collectionView.indexPathsForSelectedItems ?? []).compactMap { source.cellPresenter(at:$0)?.id }
        let expected = previous.sections.first?.cells.first?.id
        let preserved = expected.map { selected.contains($0) } ?? true
        if source is StagedCollectionDataSource<Int> { precondition(preserved) }
        previous=target
        return''')
 s=s.replace('''return ["totalMs"''','''return ["selectionPreserved":preserved,"totalMs"''')
 p.write_text(s)
s=(Path('/tmp/parade-structure-20261109/run.py')).read_text().replace('ParadeStructure','ParadeMixed').replace('structure-','mixed-')
(r/'run.py').write_text(s)
print('9 fixtures with selection checks')
