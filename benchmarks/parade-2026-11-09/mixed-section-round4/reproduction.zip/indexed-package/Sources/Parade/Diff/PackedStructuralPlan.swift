// Created by weixi on 2026/11/09.
import UIKit

// Internal experiment. All values crossing the worker boundary are Sendable.
struct PackedStructuralPlan: Sendable {
    struct Contents: Sendable { let section: Int; let items: [Int] }
    struct Batch: Sendable {
        let contents: [Contents]
        let deletedSections: IndexSet
        let insertedSections: IndexSet
        let movedSections: [(from: Int, to: Int)]
        let deletedItems: [ItemLocation]
        let insertedItems: [ItemLocation]
        let movedItems: [(from: ItemLocation, to: ItemLocation)]
    }
    let changes: SectionedChanges
    let batches: [Batch]
    let metrics: [String: Double]

    static func calculate(_ input: PackedDiffInput) throws -> Self {
        let profile = StructureProfile()
        func capture(_ sections: [PackedDiffInput.Section]) throws -> CollectionSnapshot<Int> {
            let snapshots = profile.measure("workerPresentersMs") { sections.map { section in
                SectionSnapshot(id: section.id,
                    cells: section.items.map { AnyCellPresenter(WorkerPresenter(id: $0.id, changed: $0.changed)) },
                    layout: 0)
            } }
            return try profile.measure("workerSnapshotsMs") { try CollectionSnapshot(snapshots) }
        }
        let changes = try profile.measure("diffMs") { try input.calculate() }
        if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty && changes.movedSections.isEmpty &&
           changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            // Inputs are already validated snapshots. No structural operation exists
            // to replay, so avoid constructing worker-local intermediate snapshots.
            return Self(changes: changes, batches: [], metrics: profile.values)
        }

        if input.source.map(\.id) == input.target.map(\.id) {
            let batch = Batch(contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\.id)) },
                deletedSections: [], insertedSections: [], movedSections: [],
                deletedItems: changes.deletedItems, insertedItems: changes.insertedItems,
                movedItems: changes.movedItems)
            try profile.measure("typedReplayMs") { try validateItemBatch(batch, input: input) }
            return Self(changes: changes, batches: [batch], metrics: profile.values)
        }

        // Section-only reorder: item identities remain in their own sections.
        // A small section replay is sufficient; there is no item phase to stage.
        if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty &&
           changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            let batch = Batch(contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\.id)) },
                deletedSections: [], insertedSections: [], movedSections: changes.movedSections,
                deletedItems: [], insertedItems: [], movedItems: [])
            try profile.measure("typedSectionReplayMs") { try validateSectionReorder(batch, input: input) }
            return Self(changes: changes, batches: [batch], metrics: profile.values)
        }
        let batch = Batch(contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\.id)) },
            deletedSections: changes.deletedSections, insertedSections: changes.insertedSections,
            movedSections: changes.movedSections,
            deletedItems: changes.deletedItems.filter { !changes.deletedSections.contains($0.section) },
            insertedItems: changes.insertedItems.filter { !changes.insertedSections.contains($0.section) },
            movedItems: changes.movedItems)
        try profile.measure("mixedReplayMs") { try validateMixedBatch(batch, input: input) }
        return Self(changes: changes, batches: [batch], metrics: profile.values)
    }

    // Same replay guarantee, on dense IDs; source/target uniqueness was checked
    // at capture. This path only accepts unchanged section identities and order.
    static func validateItemBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ value: Bool) throws {
            if !value { throw CollectionPlanValidationError("Invalid compact item replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target))
            try check(slots[p.section][p.item] == -1)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for m in batch.movedItems {
            try check(valid(m.from, input.source) && valid(m.to, input.target))
            try check(!removed[m.from.section][m.from.item] && slots[m.to.section][m.to.item] == -1)
            removed[m.from.section][m.from.item] = true
            slots[m.to.section][m.to.item] = input.source[m.from.section].items[m.from.item].id
        }
        for s in input.source.indices {
            var origin = 0
            for d in slots[s].indices {
                if slots[s][d] == -1 {
                    while origin < removed[s].count && removed[s][origin] { origin += 1 }
                    try check(origin < removed[s].count)
                    slots[s][d] = input.source[s].items[origin].id
                    origin += 1
                }
                try check(slots[s][d] == input.target[s].items[d].id)
            }
            while origin < removed[s].count && removed[s][origin] { origin += 1 }
            try check(origin == removed[s].count)
        }
    }

    static func validateSectionReorder(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ condition: Bool) throws {
            if !condition { throw CollectionPlanValidationError("Invalid compact section replay") }
        }
        try check(input.source.count == input.target.count)
        var removed = [Bool](repeating: false, count: input.source.count)
        var slots = [Int](repeating: -1, count: input.target.count)
        for move in batch.movedSections {
            try check(input.source.indices.contains(move.from) && slots.indices.contains(move.to))
            try check(!removed[move.from] && slots[move.to] == -1)
            removed[move.from] = true; slots[move.to] = move.from
        }
        var origin = 0
        for destination in slots.indices {
            if slots[destination] == -1 {
                while origin < removed.count && removed[origin] { origin += 1 }
                try check(origin < removed.count)
                slots[destination] = origin; origin += 1
            }
            let old = input.source[slots[destination]], new = input.target[destination]
            try check(old.id == new.id && old.items.map(\.id) == new.items.map(\.id))
        }
        while origin < removed.count && removed[origin] { origin += 1 }
        try check(origin == removed.count)
    }

    // Replay mixed operations using old coordinates for origins and target
    // coordinates for destinations. Whole-section edits account for their own
    // new/deleted items; globally retained identities must still move explicitly.
    static func validateMixedBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ condition: Bool) throws {
            if !condition { throw CollectionPlanValidationError("Invalid mixed replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        let oldCount = input.source.reduce(0) { $0 + $1.items.count }
        var removedSections = [Bool](repeating: false, count: input.source.count)
        var sectionSlots = [Int](repeating: -1, count: input.target.count)
        for s in batch.deletedSections {
            try check(input.source.indices.contains(s)); removedSections[s] = true
        }
        for s in batch.insertedSections {
            try check(input.target.indices.contains(s))
            try check(input.target[s].id >= input.source.count)
            sectionSlots[s] = -2
        }
        for move in batch.movedSections {
            try check(input.source.indices.contains(move.from) && sectionSlots.indices.contains(move.to))
            try check(!removedSections[move.from] && sectionSlots[move.to] == -1)
            removedSections[move.from] = true; sectionSlots[move.to] = move.from
        }
        var originSection = 0
        for s in sectionSlots.indices {
            if sectionSlots[s] == -1 {
                while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
                try check(originSection < removedSections.count)
                sectionSlots[s] = originSection; originSection += 1
            }
            if sectionSlots[s] >= 0 { try check(input.source[sectionSlots[s]].id == input.target[s].id) }
        }
        while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
        try check(originSection == removedSections.count)

        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source) && !batch.deletedSections.contains(p.section))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target) && !batch.insertedSections.contains(p.section))
            try check(slots[p.section][p.item] == -1 && input.target[p.section].items[p.item].id >= oldCount)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for move in batch.movedItems {
            try check(valid(move.from, input.source) && valid(move.to, input.target))
            try check(!removed[move.from.section][move.from.item] && slots[move.to.section][move.to.item] == -1)
            removed[move.from.section][move.from.item] = true
            slots[move.to.section][move.to.item] = input.source[move.from.section].items[move.from.item].id
        }
        for targetSection in input.target.indices {
            let sourceSection = sectionSlots[targetSection]
            var origin = 0
            for item in slots[targetSection].indices {
                if slots[targetSection][item] == -1 {
                    if sourceSection == -2 {
                        let id = input.target[targetSection].items[item].id
                        try check(id >= oldCount)
                        slots[targetSection][item] = id
                    } else {
                        while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                        try check(origin < removed[sourceSection].count)
                        slots[targetSection][item] = input.source[sourceSection].items[origin].id
                        origin += 1
                    }
                }
                try check(slots[targetSection][item] == input.target[targetSection].items[item].id)
            }
            if sourceSection >= 0 {
                while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                try check(origin == removed[sourceSection].count)
            }
        }
        // Contents are what the data source will expose to UIKit.
        try check(batch.contents.count == input.target.count)
        for (content, section) in zip(batch.contents, input.target) {
            try check(content.section == section.id && content.items == section.items.map(\.id))
        }
    }

    func materialize<L>(from source: CollectionSnapshot<L>, to target: CollectionSnapshot<L>,
                        input: PackedDiffInput) -> CollectionUpdatePlan<L> {
        if batches.isEmpty {
            return CollectionUpdatePlan(batches: [], content: CollectionContentUpdates(
                from: source, to: target, updatedSections: changes.updatedSections,
                updatedItems: Set(changes.updatedItems)))
        }
        let oldItems = source.sections.flatMap(\.cells)
        var added: [AnyCellPresenter] = []
        for (encoded, section) in zip(input.target, target.sections) {
            for (item, presenter) in zip(encoded.items, section.cells) where item.id >= oldItems.count {
                precondition(item.id == oldItems.count + added.count)
                added.append(presenter)
            }
        }
        let batches = batches.map { batch in
            CollectionBatch<L>(sections: batch.contents.map { content in
                let original = content.section < source.sections.count
                    ? source.sections[content.section]
                    : target.sections[content.section - source.sections.count]
                return original.replacingCells(content.items.map {
                    $0 < oldItems.count ? oldItems[$0] : added[$0 - oldItems.count]
                })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        }
        return CollectionUpdatePlan(batches: batches,
            content: CollectionContentUpdates(from: source, to: target,
                updatedSections: changes.updatedSections, updatedItems: Set(changes.updatedItems)))
    }
}

private struct WorkerPresenter: CellPresenter {
    let id: Int
    let changed: Bool
    @MainActor func configure(_ cell: UICollectionViewCell) {}
}
