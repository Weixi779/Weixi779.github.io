# Created by weixi on 2026/11/09.
from pathlib import Path
import shutil
r=Path(__file__).parent;d=r/'indexed';d.mkdir(exist_ok=True)
shutil.copytree(r/'merged/Sources',d/'Sources',dirs_exist_ok=True)
shutil.copy2(r/'merged/environment.json',d/'environment.json')
(d/'build.py').write_text((r/'merged/build.py').read_text().replace('Mixedmerged','Mixedindexed'))
p=next((d/'Sources/Parade').glob('*CollectionPositions.swift'));s=p.read_text();pos=s.index('    init<Section:')
s=s[:pos]+'''    // Reuse indexes already produced by validated CollectionSnapshot capture.
    init(sectionIndices: [SectionId: Int], itemLocations: [ItemId: ItemLocation]) {
        self.sectionIndices = sectionIndices
        self.itemLocations = itemLocations
    }

'''+s[pos:];p.write_text(s)
p=next((d/'Sources/Parade').glob('*CollectionSnapshot.swift'));s=p.read_text()
s=s.replace('    public let sections:', '    let positions: CollectionPositions<AnyHashable, AnyHashable>\n    public let sections:')
s=s.replace('''        sections = []''','''        positions = CollectionPositions(sectionIndices: [:], itemLocations: [:])
        sections = []''')
s=s.replace('[AnyHashable: (section: Int, item: Int)]','[AnyHashable: ItemLocation]')
s=s.replace('let location = (section: sectionIndex, item: item)','let location = ItemLocation(section: sectionIndex, item: item)')
s=s.replace('''        self.sections = sections''','''        positions = CollectionPositions(sectionIndices: sectionLocations, itemLocations: cellLocations)
        self.sections = sections''');p.write_text(s)
p=next((d/'Sources/Parade').glob('*StagedCollectionDataSource.swift'));s=p.read_text()
s=s.replace('private var cellLocations: [AnyHashable: IndexPath]','private var cellLocations: [AnyHashable: ItemLocation]')
s=s.replace('cellLocations[presenter.id] = IndexPath(item: item, section: index)','cellLocations[presenter.id] = ItemLocation(section: index, item: item)')
s=s.replace('public func indexPath(for id: AnyHashable) -> IndexPath? { cellLocations[id] }','public func indexPath(for id: AnyHashable) -> IndexPath? { cellLocations[id]?.indexPath }')
s=s.replace('let sourcePositions = try CollectionPositions(source.sections, input: .source)','let sourcePositions = source.positions')
s=s.replace('''                self.sections = batch.sections''','''                if self.diffAlgorithm is SectionedDiff {
                    // Built-in merged planner has at most one structural batch,
                    // with exactly the target identities and positions.
                    let indexStart = SpikeTimings.now()
                    self.sectionLocations = target.positions.sectionIndices
                    self.cellLocations = target.positions.itemLocations
                    self.installContent(batch.sections)
                    SpikeTimings.detail["indexInstallMs", default: 0] += SpikeTimings.elapsed(indexStart)
                } else {
                    self.sections = batch.sections
                }''');p.write_text(s)
print(d)
