# Created by weixi on 2026/11/09.
from pathlib import Path
import shutil
r=Path(__file__).parent;old=Path('/tmp/parade-structure-20261109')
shutil.copytree(old/'ListKit',r/'ListKit',dirs_exist_ok=True,ignore=shutil.ignore_patterns('ModuleCache'))
for v in ['baseline','merged']:
 d=r/v;d.mkdir(exist_ok=True)
 shutil.copytree(old/'lean/Sources',d/'Sources',dirs_exist_ok=True)
 shutil.copy2(old/'lean/environment.json',d/'environment.json')
 (d/'build.py').write_text((old/'lean/build.py').read_text().replace('Structurelean','Mixed'+v))
 p=d/'Sources/ArticleMain.swift';s=p.read_text().replace('structure-','mixed-');p.write_text(s)
p=r/'merged/Sources/Parade/PackedStructuralPlan.swift';s=p.read_text()
a=s.index('        // Presenter erasers');b=s.index('\n    // Same replay guarantee',a)
s=s[:a]+'''        let batch = Batch(contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\\.id)) },
            deletedSections: changes.deletedSections, insertedSections: changes.insertedSections,
            movedSections: changes.movedSections,
            deletedItems: changes.deletedItems.filter { !changes.deletedSections.contains($0.section) },
            insertedItems: changes.insertedItems.filter { !changes.insertedSections.contains($0.section) },
            movedItems: changes.movedItems)
        try profile.measure("mixedReplayMs") { try validateMixedBatch(batch, input: input) }
        return Self(changes: changes, batches: [batch], metrics: profile.values)
    }
''' +s[b:]
pos=s.index('    func materialize')
validator='''    // Replay mixed operations using old coordinates for origins and target
    // coordinates for destinations. Whole-section edits account for their own
    // new/deleted items; globally retained identities must still move explicitly.
    static func validateMixedBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ condition: Bool) throws {
            if !condition { throw CollectionPlanValidationError("Invalid mixed replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        let oldCount = input.source.reduce(0) { $0 + $1.items.count }
        var removedSections = [Bool](repeating: false, count: input.source.count)
        var sectionSlots = [Int](repeating: -1, count: input.target.count)
        for s in batch.deletedSections {
            try check(input.source.indices.contains(s)); removedSections[s] = true
        }
        for s in batch.insertedSections {
            try check(input.target.indices.contains(s))
            try check(input.target[s].id >= input.source.count)
            sectionSlots[s] = -2
        }
        for move in batch.movedSections {
            try check(input.source.indices.contains(move.from) && sectionSlots.indices.contains(move.to))
            try check(!removedSections[move.from] && sectionSlots[move.to] == -1)
            removedSections[move.from] = true; sectionSlots[move.to] = move.from
        }
        var originSection = 0
        for s in sectionSlots.indices {
            if sectionSlots[s] == -1 {
                while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
                try check(originSection < removedSections.count)
                sectionSlots[s] = originSection; originSection += 1
            }
            if sectionSlots[s] >= 0 { try check(input.source[sectionSlots[s]].id == input.target[s].id) }
        }
        while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
        try check(originSection == removedSections.count)

        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source) && !batch.deletedSections.contains(p.section))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target) && !batch.insertedSections.contains(p.section))
            try check(slots[p.section][p.item] == -1 && input.target[p.section].items[p.item].id >= oldCount)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for move in batch.movedItems {
            try check(valid(move.from, input.source) && valid(move.to, input.target))
            try check(!removed[move.from.section][move.from.item] && slots[move.to.section][move.to.item] == -1)
            removed[move.from.section][move.from.item] = true
            slots[move.to.section][move.to.item] = input.source[move.from.section].items[move.from.item].id
        }
        for targetSection in input.target.indices {
            let sourceSection = sectionSlots[targetSection]
            var origin = 0
            for item in slots[targetSection].indices {
                if slots[targetSection][item] == -1 {
                    if sourceSection == -2 {
                        let id = input.target[targetSection].items[item].id
                        try check(id >= oldCount)
                        slots[targetSection][item] = id
                    } else {
                        while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                        try check(origin < removed[sourceSection].count)
                        slots[targetSection][item] = input.source[sourceSection].items[origin].id
                        origin += 1
                    }
                }
                try check(slots[targetSection][item] == input.target[targetSection].items[item].id)
            }
            if sourceSection >= 0 {
                while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                try check(origin == removed[sourceSection].count)
            }
        }
        // Contents are what the data source will expose to UIKit.
        try check(batch.contents.count == input.target.count)
        for (content, section) in zip(batch.contents, input.target) {
            try check(content.section == section.id && content.items == section.items.map(\\.id))
        }
    }

'''
s=s[:pos]+validator+s[pos:];p.write_text(s)
# Small state probe retains the previous five identical fixtures.
d=r/'probe';d.mkdir(exist_ok=True)
shutil.copytree(r/'merged/Sources',d/'Sources',dirs_exist_ok=True)
shutil.copy2(r/'merged/environment.json',d/'environment.json')
(d/'build.py').write_text((r/'merged/build.py').read_text().replace('Mixedmerged','Mixedprobe'))
s=(old/'probe/Sources/ArticleMain.swift').read_text().replace('structure-','mixed-')
(d/'Sources/ArticleMain.swift').write_text(s)
print('Prepared baseline, merged, probe')
