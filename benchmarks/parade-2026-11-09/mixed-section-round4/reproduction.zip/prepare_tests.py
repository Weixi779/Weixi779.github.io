# Created by weixi on 2026/11/09.
from pathlib import Path
import shutil
r=Path(__file__).parent;old=Path('/tmp/parade-structure-20261109/lean-package')
d=r/'merged-package';d.mkdir(exist_ok=True)
for name in ['Sources','Tests']:shutil.copytree(old/name,d/name,dirs_exist_ok=True)
shutil.copy2(old/'Package.swift',d/'Package.swift')
for p in (r/'merged/Sources/Parade').glob('*.swift'):
 name=p.name.split('-',1)[-1] if p.name[:3].isdigit() else p.name
 dest=list((d/'Sources/Parade').rglob(name))[0]
 shutil.copy2(p,dest)
p=d/'Tests/ParadeTests/SpikeOptimizationTests.swift';s=p.read_text().replace('''        let plan = try PackedStructuralPlan.calculate(input).materialize(from: old, to: new, input: input)
        try CollectionUpdatePlan.validate(plan.batches, from: old.sections, to: new.sections)''','''        let packed = try PackedStructuralPlan.calculate(input)
        for batch in packed.batches { try PackedStructuralPlan.validateMixedBatch(batch, input: input) }
        // The old independent staged planner above still verifies the same diff.
        // Its replay explicitly forbids mixed batches, so it cannot replay this executor format.''');p.write_text(s)
p=d/'Tests/ParadeTests/CollectionOrchestratorTests.swift';s=p.read_text();pos=s.index('    @Test(')
s=s[:pos]+'''    @Test("Merged structure preserves selection and installs content after structure", arguments: [false, true])
    func mergedSelectionAndContentTiming(animated: Bool) async throws {
        let fixture = CollectionFixture()
        defer { fixture.close() }
        try await fixture.orchestrator.compose([textSection("removed", [1,2]), textSection("retained", [3])]).apply(animated: false)
        let view = fixture.collectionView
        let path = IndexPath(item: 0, section: 0)
        let oldCell = try #require(view.cellForItem(at: path) as? TextCell)
        view.selectItem(at: path, animated: false, scrollPosition: [])
        view.resetCounts()
        var structuralText: String?
        var structuralSelection = false
        view.afterBatch = {
            if view.batches == 1 {
                structuralText = (view.cellForItem(at: path) as? TextCell)?.label.text
                structuralSelection = view.indexPathsForSelectedItems?.contains(path) == true
            }
        }
        let content = String(repeating: "A changed message. ", count: 8)
        try await fixture.orchestrator.compose([
            TestSection(id: "inserted", cells: [AnyCellPresenter(TextPresenter(id: 1, text: content)), AnyCellPresenter(TextPresenter(id: 4, text: "New"))]),
            textSection("retained", [2,3])
        ]).apply(animated: animated)
        view.afterBatch = nil
        #expect(structuralText == "Item 1")
        #expect(structuralSelection)
        let newCell = try #require(view.cellForItem(at: path) as? TextCell)
        #expect(newCell === oldCell)
        #expect(newCell.label.text == content)
        #expect(view.indexPathsForSelectedItems == [path])
        #expect(view.batches == (animated ? 2 : 1))
        #expect(view.reloads == 0)
        #expect(view.movedItems.count == 2)
        #expect(view.reconfigured.contains(path))
    }

    @Test("Mixed section operations preserve selected survivors across 300 transitions")
    func randomizedMixedUIKitSelection() async throws {
        let fixture = CollectionFixture()
        defer { fixture.close() }
        let view = fixture.collectionView
        view.allowsMultipleSelection = true
        var state: UInt64 = 0x53454354494f4e
        func next(_ limit: Int) -> Int {
            state = state &* 6364136223846793005 &+ 1
            return Int(state >> 32) % limit
        }
        var previous = Set<Int>()
        for generation in 0..<300 {
            var sectionIDs = Array(0..<5)
            for i in sectionIDs.indices.reversed() { sectionIDs.swapAt(i, next(i+1)) }
            sectionIDs = Array(sectionIDs.prefix(next(6)))
            var groups = [[Int]](repeating: [], count: sectionIDs.count)
            if !groups.isEmpty {
                var ids = (0..<12).filter { _ in next(4) != 0 }
                for i in ids.indices.reversed() { ids.swapAt(i, next(i+1)) }
                for id in ids { groups[next(groups.count)].append(id) }
            }
            let current = Set(groups.flatMap { $0 })
            let sections = zip(sectionIDs,groups).map { s, ids in
                TestSection(id: "s\\(s)", cells: ids.map { AnyCellPresenter(TextPresenter(id: $0, text: "\\(generation):\\($0)")) })
            }
            try await fixture.orchestrator.compose(sections).apply(animated: false)
            let selected = Set((view.indexPathsForSelectedItems ?? []).map { groups[$0.section][$0.item] })
            #expect(selected == previous.intersection(current))
            for (s, ids) in groups.enumerated() {
                for (i,id) in ids.enumerated() {
                    let path = IndexPath(item: i, section: s)
                    #expect(fixture.orchestrator.indexPath(for: id) == path)
                    view.selectItem(at: path, animated: false, scrollPosition: [])
                }
            }
            for path in view.indexPathsForVisibleItems {
                let cell = try #require(view.cellForItem(at: path) as? TextCell)
                #expect(cell.label.text == "\\(generation):\\(groups[path.section][path.item])")
            }
            previous = current
        }
        #expect(view.reloads == 0)
    }

''' +s[pos:]
s=s.replace('    var maximumActiveBatches = 0','    var maximumActiveBatches = 0\n    var afterBatch: (() -> Void)?')
s=s.replace('''            activeBatches -= 1
            completion?''','''            activeBatches -= 1
            afterBatch?()
            completion?''');p.write_text(s)
print(d)
