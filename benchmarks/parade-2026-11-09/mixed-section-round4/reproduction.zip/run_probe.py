# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,shutil,sys
r=Path(__file__).parent/sys.argv[1];bundle='dev.weixi.ParadeMixed'+sys.argv[1]+'20261109'
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro')
subprocess.run(['xcrun','simctl','install',u,str(r/'ArticleBench.app')],check=True)
with (r/'probe.log').open('w') as f:p=subprocess.run(['xcrun','simctl','launch','--console','--terminate-running-process',u,bundle,'0','7'],stdout=f,stderr=subprocess.STDOUT,timeout=90)
assert p.returncode==0
container=Path(subprocess.check_output(['xcrun','simctl','get_app_container',u,bundle,'data'],text=True).strip())
src=container/'Documents/mixed-7-0.json';shutil.copy2(src,r/src.name)
d=json.loads(src.read_text());assert d['complete']
for x in d['records']:
 if x['engine']=='Current-staged':print(x['scenario'],x['samples'][0]['operations'],x['samples'][0]['selectedIDs'],x['samples'][0]['retainedCells'])
