# Created by weixi on 2026/11/09.
from pathlib import Path
import json,statistics,csv
r=Path(__file__).parent;groups={}
for v in ['baseline','merged','indexed']:
 for p in sorted((r/v).glob('mixed-*-*.json')):
  d=json.loads(p.read_text());assert d['complete']
  for x in d['records']:
   key=(v,x['n'],x['scenario'],x['engine']);a=x['samples']
   assert len(a)==10 and all(z['reloadCalls']==0 for z in a)
   metrics={k:statistics.median(z[k] for z in a) for k in a[0] if k not in ['detail','selectionPreserved']}
   metrics.update({'detail.'+k:statistics.median(z['detail'].get(k,0) for z in a) for k in set().union(*(z['detail'] for z in a))})
   groups.setdefault(key,[]).append({'repetition':d['repetition'],'samples':len(a),'selectionFailures':sum(not z['selectionPreserved'] for z in a),**metrics})
rows=[]
for (v,n,s,e),runs in groups.items():
 keys=set().union(*(x.keys() for x in runs))-{'repetition','samples','selectionFailures'}
 rows.append({'variant':v,'n':n,'scenario':s,'engine':e,'runs':len(runs),'samples':sum(x['samples'] for x in runs),
              'selectionFailures':sum(x['selectionFailures'] for x in runs),
              **{k:statistics.median(x.get(k,0) for x in runs) for k in sorted(keys)},'runMedians':runs})
(r/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
keys=['variant','n','scenario','engine','runs','samples','selectionFailures']+sorted(set().union(*(x.keys() for x in rows))-{'variant','n','scenario','engine','runs','samples','selectionFailures','runMedians'})
with (r/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
print('groups',len(rows),'samples',sum(x['samples'] for x in rows))
for n in [100,1000,10000]:
 for s in ['new-section-move1','new-section-move5pct','delete-section-transfer','replace-section','section-reorder-transfer','section-churn','replace-all-sections']:
  entries=[x for x in rows if x['n']==n and x['scenario']==s and (x['variant']=='indexed' or (x['variant']=='baseline' and x['engine']=='Current-staged'))]
  print(n,s,' | '.join(x['variant']+':'+x['engine']+'='+str(round(x['totalMs'],2))+' ('+str(x['runs'])+')' for x in entries))
