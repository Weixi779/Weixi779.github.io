# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,shutil
r=Path(__file__).parent;d=r/'lean-package';d.mkdir(exist_ok=True)
for name in ['Sources','Tests']:
 shutil.copytree(r/'reuseIndex-package'/name,d/name,dirs_exist_ok=True)
shutil.copy2(r/'reuseIndex-package/Package.swift',d/'Package.swift')
for p in (r/'lean/Sources/Parade').glob('*.swift'):
 name=p.name.split('-',1)[-1] if p.name[:3].isdigit() else p.name
 matches=list((d/'Sources/Parade').rglob(name))
 shutil.copy2(p,matches[0] if matches else d/'Sources/Parade/Diff'/name)
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro')
base=['xcodebuild','-scheme','Parade','-destination',f'platform=iOS Simulator,id={u}','-derivedDataPath',str(d/'DerivedData'),'-parallel-testing-enabled','NO','CODE_SIGNING_ALLOWED=NO']
for stage,args in [('build', ['build-for-testing']),('test',['-resultBundlePath',str(d/'Verified.xcresult'),'-collect-test-diagnostics','never','test-without-building'])]:
 with (d/(stage+'.log')).open('w') as f:p=subprocess.run(base+args,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 print(stage,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
