// Created by weixi on 2026/11/09.
// Throwaway experiment: only immutable integers and flags cross the worker boundary.
struct PackedDiffInput: Sendable {
    struct Item: DiffableElement, Sendable {
        let id: Int
        let changed: Bool
    }
    struct Section: DiffableSection, Sendable {
        let id: Int
        let changed: Bool
        let items: [Item]
        func isContentEqual(to other: Self) -> Bool { changed == other.changed }
    }
    let source: [Section]
    let target: [Section]

    init<L>(from old: [SectionSnapshot<L>], to new: [SectionSnapshot<L>],
            sourcePositions: CollectionPositions<AnyHashable, AnyHashable>) {
        var offsets: [Int] = []
        var next = 0
        source = old.enumerated().map { section, value in
            offsets.append(next)
            let items = value.cells.map { _ in
                defer { next += 1 }
                return Item(id: next, changed: false)
            }
            return Section(id: section, changed: false, items: items)
        }
        target = new.enumerated().map { section, value in
            let origin = sourcePositions.sectionIndices[value.id]
            let items = value.cells.map { presenter in
                if let location = sourcePositions.itemLocations[presenter.id] {
                    return Item(id: offsets[location.section] + location.item,
                                changed: old[location.section].cells[location.item] != presenter)
                }
                defer { next += 1 }
                return Item(id: next, changed: false)
            }
            return Section(id: origin ?? old.count + section,
                changed: origin.map { !old[$0].isContentEqual(to: value) } ?? false,
                items: items)
        }
    }

    func calculate() throws -> SectionedChanges {
        // Equality here checks identities only. Content flags are handled separately.
        var stable = Set<Int>()
        var contentUpdates: [ItemLocation] = []
        for (index, section) in target.enumerated() where section.id < source.count {
            let old = source[section.id]
            if old.items.count == section.items.count && zip(old.items, section.items).allSatisfy({ $0.id == $1.id }) {
                stable.insert(section.id)
                for (item, value) in section.items.enumerated() where value.changed {
                    contentUpdates.append(ItemLocation(section: index, item: item))
                }
            }
        }
        // Remove only unchanged item sequences from the structural matcher. Section
        // order/identity and content metadata remain present. Cross-section moves
        // cannot enter or leave an unchanged sequence with globally unique IDs.
        func structural(_ sections: [Section]) -> [Section] {
            sections.map { stable.contains($0.id) ? Section(id: $0.id, changed: $0.changed, items: []) : $0 }
        }
        var changes = try SectionedDiff().diff(from: structural(source), to: structural(target))
        changes.updatedItems.append(contentsOf: contentUpdates)
        return changes
    }
}
