// Created by weixi on 2026/11/09.
import UIKit

// Internal experiment. All values crossing the worker boundary are Sendable.
struct PackedStructuralPlan: Sendable {
    struct Contents: Sendable { let section: Int; let items: [Int] }
    struct Batch: Sendable {
        let contents: [Contents]
        let deletedSections: IndexSet
        let insertedSections: IndexSet
        let movedSections: [(from: Int, to: Int)]
        let deletedItems: [ItemLocation]
        let insertedItems: [ItemLocation]
        let movedItems: [(from: ItemLocation, to: ItemLocation)]
    }
    let changes: SectionedChanges
    let batches: [Batch]

    static func calculate(_ input: PackedDiffInput) throws -> Self {
        func capture(_ sections: [PackedDiffInput.Section]) throws -> CollectionSnapshot<Int> {
            try CollectionSnapshot(sections.map { section in
                SectionSnapshot(id: section.id,
                    cells: section.items.map { AnyCellPresenter(WorkerPresenter(id: $0.id, changed: $0.changed)) },
                    layout: 0)
            })
        }
        let changes = try input.calculate()
        if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty && changes.movedSections.isEmpty &&
           changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            // Inputs are already validated snapshots. No structural operation exists
            // to replay, so avoid constructing worker-local intermediate snapshots.
            return Self(changes: changes, batches: [])
        }
        // Presenter erasers below are created and consumed entirely inside this worker.
        let source = try capture(input.source)
        let target = try capture(input.target)
        let prepared = PreparedSectionedDiff(changes: changes,
            sourcePositions: try CollectionPositions(source.sections, input: .source),
            targetPositions: try CollectionPositions(target.sections, input: .target))
        let plan = try CollectionUpdatePlan(from: source, to: target, prepared: prepared)
        return Self(changes: changes, batches: plan.batches.map { batch in
            Batch(contents: batch.sections.map { section in
                Contents(section: section.id.base as! Int, items: section.cells.map { $0.id.base as! Int })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        })
    }

    func materialize<L>(from source: CollectionSnapshot<L>, to target: CollectionSnapshot<L>,
                        input: PackedDiffInput) -> CollectionUpdatePlan<L> {
        if batches.isEmpty {
            return CollectionUpdatePlan(batches: [], content: CollectionContentUpdates(
                from: source, to: target, updatedSections: changes.updatedSections,
                updatedItems: Set(changes.updatedItems)))
        }
        let oldItems = source.sections.flatMap(\.cells)
        var added: [AnyCellPresenter] = []
        for (encoded, section) in zip(input.target, target.sections) {
            for (item, presenter) in zip(encoded.items, section.cells) where item.id >= oldItems.count {
                precondition(item.id == oldItems.count + added.count)
                added.append(presenter)
            }
        }
        let batches = batches.map { batch in
            CollectionBatch<L>(sections: batch.contents.map { content in
                let original = content.section < source.sections.count
                    ? source.sections[content.section]
                    : target.sections[content.section - source.sections.count]
                return original.replacingCells(content.items.map {
                    $0 < oldItems.count ? oldItems[$0] : added[$0 - oldItems.count]
                })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        }
        return CollectionUpdatePlan(batches: batches,
            content: CollectionContentUpdates(from: source, to: target,
                updatedSections: changes.updatedSections, updatedItems: Set(changes.updatedItems)))
    }
}

private struct WorkerPresenter: CellPresenter {
    let id: Int
    let changed: Bool
    @MainActor func configure(_ cell: UICollectionViewCell) {}
}
