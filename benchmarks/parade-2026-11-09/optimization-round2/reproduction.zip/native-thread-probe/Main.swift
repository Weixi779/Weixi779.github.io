// Created by weixi on 2026/11/09.
import UIKit
final class ProbeLog: @unchecked Sendable {
    static let shared=ProbeLog()
    private let lock=NSLock()
    private var events:[String]=[]
    private var counts:[String:Int]=[:]
    func event(_ name:String) { lock.lock();defer{lock.unlock()};events.append(name+(Thread.isMainThread ? ":main":":background")) }
    func count(_ name:String) { lock.lock();defer{lock.unlock()};counts[name+(Thread.isMainThread ? ":main":":background"),default:0] += 1 }
    func save() { lock.lock();defer{lock.unlock()};let value:[String:Any]=["events":events,"counts":counts];let data=try! JSONSerialization.data(withJSONObject:value,options:[.prettyPrinted,.sortedKeys]);try! data.write(to:URL.documentsDirectory.appendingPathComponent("queue-probe.json")) }
}
struct ProbeID: Hashable, Sendable {
    let value:Int
    func hash(into hasher:inout Hasher) { ProbeLog.shared.count("hash");hasher.combine(value) }
    static func ==(a:Self,b:Self)->Bool { ProbeLog.shared.count("equality");return a.value==b.value }
}
@MainActor final class VC:UIViewController {
    var started=false
    override func viewDidAppear(_ animated:Bool) {
        super.viewDidAppear(animated);if started{return};started=true
        Task { await run() }
    }
    func run() async {
        let layout=UICollectionViewFlowLayout();layout.itemSize=CGSize(width:300,height:36)
        let cv=UICollectionView(frame:CGRect(x:0,y:0,width:320,height:480),collectionViewLayout:layout)
        cv.register(UICollectionViewCell.self,forCellWithReuseIdentifier:"cell");view.addSubview(cv)
        let native=UICollectionViewDiffableDataSource<Int,ProbeID>(collectionView:cv) { cv,path,id in
            ProbeLog.shared.count("cellProvider")
            precondition(Thread.isMainThread)
            return cv.dequeueReusableCell(withReuseIdentifier:"cell",for:path)
        }
        let queue=DispatchQueue(label:"weixi.parade.queue-probe")
        for generation in 0..<3 {
            var snapshot=NSDiffableDataSourceSnapshot<Int,ProbeID>();snapshot.appendSections([0])
            let ids=(0..<1000).filter { generation==0 || $0 % 3 != generation }.map{ProbeID(value:$0)}
            snapshot.appendItems(ids)
            let captured=snapshot
            await withCheckedContinuation { (continuation:CheckedContinuation<Void,Never>) in
                queue.async {
                    ProbeLog.shared.event("begin-\(generation)")
                    native.apply(captured,animatingDifferences:false) {
                        ProbeLog.shared.event("complete-\(generation)");continuation.resume()
                    }
                }
            }
            precondition(native.snapshot().itemIdentifiers == ids)
        }
        ProbeLog.shared.save();print("QUEUE_PROBE_COMPLETE");fflush(stdout);exit(0)
    }
}
@main @MainActor final class App:UIResponder,UIApplicationDelegate {
    func application(_ application:UIApplication,configurationForConnecting session:UISceneSession,options:UIScene.ConnectionOptions)->UISceneConfiguration {
        let c=UISceneConfiguration(name:"Probe",sessionRole:session.role);c.delegateClass=Scene.self;return c
    }
}
@MainActor final class Scene:UIResponder,UIWindowSceneDelegate {
    var window:UIWindow?
    func scene(_ scene:UIScene,willConnectTo session:UISceneSession,options:UIScene.ConnectionOptions) {
        guard let s=scene as? UIWindowScene else{return};let w=UIWindow(windowScene:s);w.rootViewController=VC();window=w;w.makeKeyAndVisible()
    }
}
