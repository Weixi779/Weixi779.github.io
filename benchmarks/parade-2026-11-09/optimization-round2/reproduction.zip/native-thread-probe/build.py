from pathlib import Path
import subprocess,plistlib
r=Path(__file__).parent;app=r/'QueueProbe.app';app.mkdir(exist_ok=True)
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
subprocess.run(['xcrun','swiftc','-parse-as-library','-O','-swift-version','6','-sdk',sdk,'-target','arm64-apple-ios17.0-simulator','-module-cache-path','/tmp/parade-profile-20261109/ModuleCache',str(r/'Main.swift'),'-o',str(app/'QueueProbe')],check=True)
with (app/'Info.plist').open('wb') as f:plistlib.dump({'CFBundleIdentifier':'dev.weixi.ParadeQueueProbe20261109','CFBundleName':'Queue Probe','CFBundleExecutable':'QueueProbe','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1.0','MinimumOSVersion':'17.0','LSRequiresIPhoneOS':True,'UIDeviceFamily':[1,2],'UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False}},f)
subprocess.run(['codesign','--force','--sign','-',str(app)],check=True)
