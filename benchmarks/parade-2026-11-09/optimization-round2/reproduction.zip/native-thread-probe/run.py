from pathlib import Path
import subprocess,json,shutil
r=Path(__file__).parent
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro');bundle='dev.weixi.ParadeQueueProbe20261109'
subprocess.run(['xcrun','simctl','install',u,str(r/'QueueProbe.app')],check=True)
with (r/'run.log').open('w') as f:subprocess.run(['xcrun','simctl','launch','--console','--terminate-running-process',u,bundle],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=40)
p=Path(subprocess.check_output(['xcrun','simctl','get_app_container',u,bundle,'data'],text=True).strip())/'Documents/queue-probe.json'
shutil.copy2(p,r/p.name)
print((r/p.name).read_text())
