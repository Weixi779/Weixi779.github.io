# Created by weixi on 2026/11/09.
from pathlib import Path
import shutil,json
r=Path(__file__).parent;repo=Path('/Users/sunshiwei/Develop/Parade');upstream=repo/'research/frameworks/Lists'
lib=r/'ListKit';lib.mkdir(exist_ok=True)
shutil.copytree(upstream/'Sources/ListKit',lib/'Sources',dirs_exist_ok=True)
shutil.copy2(upstream/'LICENSE',lib/'LICENSE')
base=(repo/'Sources/Parade/DataSource/Diffable/DiffableCollectionDataSource.swift').read_text()
bg=base.replace('public final class DiffableCollectionDataSource','public final class BackgroundNativeDataSource')
bg=bg.replace('    private var current =', '    private let applyQueue = DispatchQueue(label: "weixi.parade.native-background", qos: .userInitiated)\n    private var current =')
bg=bg.replace('await native.applySnapshotUsingReloadData(snapshot)','await applyNative(snapshot, animated: false, reload: true)')
bg=bg.replace('await native.apply(snapshot, animatingDifferences: animated)','await applyNative(snapshot, animated: animated, reload: false)')
a='''    public func apply(
'''
b='''    // Benchmark-only: use Apple's runtime-supported background completion API.
    // Current SDK emits an isolation warning; retained in build.log, not hidden.
    private func applyNative(_ snapshot: NSDiffableDataSourceSnapshot<Int, Int>, animated: Bool, reload: Bool) async {
        let native = self.native
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            applyQueue.async {
                precondition(!Thread.isMainThread)
                let completion = {
                    precondition(Thread.isMainThread)
                    continuation.resume()
                }
                if reload {
                    native.applySnapshotUsingReloadData(snapshot, completion: completion)
                } else {
                    native.apply(snapshot, animatingDifferences: animated, completion: completion)
                }
            }
        }
    }

    public func apply(
'''
assert a in bg;bg=bg.replace(a,b)
lk=base.replace('import UIKit','import UIKit\nimport ListKit')
lk=lk.replace('public final class DiffableCollectionDataSource','public final class ListKitAdapter')
lk=lk.replace('UICollectionViewDiffableDataSource<Int, Int>','ListKit.CollectionViewDiffableDataSource<Int, Int>')
lk=lk.replace('NSDiffableDataSourceSnapshot<Int, Int>','ListKit.DiffableDataSourceSnapshot<Int, Int>')
lk=lk.replace('await native.apply(snapshot, animatingDifferences: animated)','''// Force the precise batch path; the harness globally disables animations.
            await native.apply(snapshot, animatingDifferences: true)''')
for v in ['baseline','previous','fast','lis']:
 d=r/v
 (d/'Sources/BackgroundNativeDataSource.swift').write_text(bg)
 (d/'Sources/ListKitAdapter.swift').write_text(lk)
 p=d/'Sources/ArticleMain.swift';s=p.read_text()
 s=s.replace('    var batches = 0','''    var batches = 0
    var itemMoves = 0, sectionMoves = 0, reloadCalls = 0, reconfiguredItems = 0, reloadedItems = 0
    func resetCounters() { batches = 0; itemMoves = 0; sectionMoves = 0; reloadCalls = 0; reconfiguredItems = 0; reloadedItems = 0 }
    override func moveItem(at from: IndexPath, to: IndexPath) { itemMoves += 1; super.moveItem(at: from, to: to) }
    override func moveSection(_ section: Int, toSection newSection: Int) { sectionMoves += 1; super.moveSection(section, toSection: newSection) }
    override func reloadData() { reloadCalls += 1; super.reloadData() }
    override func reloadItems(at paths: [IndexPath]) { reloadedItems += paths.count; super.reloadItems(at: paths) }''')
 s=s.replace('''        if forceReload {''','''        reconfiguredItems += indexPaths.count
        if forceReload {''')
 s=s.replace('''        else { source = StagedCollectionDataSource''','''        else if engine == "Current-Apple-background" { source = BackgroundNativeDataSource<Int>(collectionView: view,views: views) }
        else if engine == "Current-ListKit" { source = ListKitAdapter<Int>(collectionView: view,views: views) }
        else { source = StagedCollectionDataSource''')
 s=s.replace('(collectionView as! ArticleCollection).batches=0','(collectionView as! ArticleCollection).resetCounters()')
 s=s.replace('''        precondition(d.isEmpty)
        precondition(collectionView.window''','''        precondition(d.isEmpty)
        // No timed candidate may substitute reloadData for precise updates.
        precondition((collectionView as! ArticleCollection).reloadCalls == 0)
        precondition(collectionView.window''')
 s=s.replace('''"configuredCells":BenchCell.configurations,''','''"configuredCells":BenchCell.configurations,
          "itemMoves":(collectionView as! ArticleCollection).itemMoves,
          "sectionMoves":(collectionView as! ArticleCollection).sectionMoves,
          "reloadCalls":(collectionView as! ArticleCollection).reloadCalls,
          "reconfiguredItems":(collectionView as! ArticleCollection).reconfiguredItems,
          "reloadedItems":(collectionView as! ArticleCollection).reloadedItems,''')
 s=s.replace('var engines=["Current-staged","Current-Apple-adapter"]','var engines=["Current-staged","Current-Apple-adapter","Current-Apple-background","Current-ListKit"]')
 s=s.replace('"opt-\\(n)-\\(repetition).json"','"round2-\\(n)-\\(repetition).json"')
 s=s.replace('"OPT_COMPLETE','"ROUND2_COMPLETE')
 # Optional quick smoke runs use rep 0; same cases, only 1 sample without warmup.
 s=s.replace('for i in 0..<13 {','for i in 0..<(repetition == 0 ? 1 : 13) {').replace('if i>=3 {','if i >= (repetition == 0 ? 0 : 3) {')
 p.write_text(s)
 env=json.loads((d/'environment.json').read_text());env['listKitCommit']='221e1513f2786a4e5e836c9b76092c3bd6e61575';(d/'environment.json').write_text(json.dumps(env,indent=2))
 build='''# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,plistlib,json,hashlib
r=Path(__file__).parent;lib=r.parent/'ListKit';app=r/'ArticleBench.app';app.mkdir(exist_ok=True)
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
cmd=['xcrun','swiftc','-O','-whole-module-optimization','-swift-version','5','-enable-upcoming-feature','IsolatedDefaultValues','-sdk',sdk,'-target','arm64-apple-ios17.0-simulator','-module-cache-path',str(r/'ModuleCache'),'-I',str(lib),'-L',str(lib),'-lListKit']+[str(p) for p in sorted((r/'Sources').rglob('*.swift'))]+['-o',str(app/'ArticleBench')]
subprocess.run(cmd,check=True)
with (app/'Info.plist').open('wb') as f:
 plistlib.dump({'CFBundleIdentifier':'dev.weixi.ParadeRound2VARIANT20261109','CFBundleName':'Parade Round 2','CFBundleExecutable':'ArticleBench','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1.0','MinimumOSVersion':'17.0','LSRequiresIPhoneOS':True,'UIDeviceFamily':[1,2],'UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False}},f)
subprocess.run(['codesign','--force','--sign','-',str(app)],check=True)
env=json.loads((r/'environment.json').read_text());env['compileCommand']=[part.replace(str(r.parent),'EXPERIMENT_ROOT') for part in cmd];env['binarySHA256']=hashlib.sha256((app/'ArticleBench').read_bytes()).hexdigest();env['allSourceHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'Sources').rglob('*.swift')};(r/'environment.json').write_text(json.dumps(env,indent=2))
'''.replace('VARIANT',v)
 (d/'build.py').write_text(build)
(lib/'build.py').write_text('''# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
files=sorted((r/'Sources').rglob('*.swift'))
cmd=['xcrun','swiftc','-parse-as-library','-emit-library','-static','-emit-module','-module-name','ListKit','-emit-module-path',str(r/'ListKit.swiftmodule'),'-O','-whole-module-optimization','-swift-version','5','-sdk',sdk,'-target','arm64-apple-ios17.0-simulator','-module-cache-path',str(r/'ModuleCache')]+[str(p) for p in files]+['-o',str(r/'libListKit.a')]
subprocess.run(cmd,check=True)
(r/'environment.json').write_text(json.dumps({'commit':'221e1513f2786a4e5e836c9b76092c3bd6e61575','compileCommand':[x.replace(str(r),'LISTKIT_ROOT') for x in cmd],'hashes':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},indent=2))
''')
print('Prepared four variants, three comparison adapters, unchanged ListKit module')
