// Created by weixi on 2026/09/17.

import UIKit

/// Staged UIKit updates: replaceable sectioned diff and validated UIKit batches.
@MainActor
public final class StagedCollectionDataSource<Layout>: NSObject, CollectionDataSource, UICollectionViewDataSource {
    private let collectionView: UICollectionView
    private let views: CollectionViews
    private let diffAlgorithm: any SectionedDiffAlgorithm
    private var sectionLocations: [AnyHashable: Int] = [:]
    private var cellLocations: [AnyHashable: IndexPath] = [:]

    var sections: [SectionSnapshot<Layout>] = [] {
        didSet {
            sectionLocations.removeAll(keepingCapacity: true)
            cellLocations.removeAll(keepingCapacity: true)
            for (index, section) in sections.enumerated() {
                sectionLocations[section.id] = index
                for (item, presenter) in section.cells.enumerated() {
                    cellLocations[presenter.id] = IndexPath(item: item, section: index)
                }
            }
        }
    }

    public init(
        collectionView: UICollectionView,
        views: CollectionViews,
        diffAlgorithm: any SectionedDiffAlgorithm = SectionedDiff()
    ) {
        self.collectionView = collectionView
        self.views = views
        self.diffAlgorithm = diffAlgorithm
        super.init()
    }

    public var dataSource: any UICollectionViewDataSource { self }
    public var sectionIds: [AnyHashable] { sections.map(\.id) }
    public var numberOfSections: Int { sections.count }
    public var numberOfItems: Int { cellLocations.count }
    public var isEmpty: Bool { sections.allSatisfy(\.isEmpty) }

    public func sectionId(at index: Int) -> AnyHashable? { section(at: index)?.id }
    public func sectionIndex(for id: AnyHashable) -> Int? { sectionLocations[id] }
    public func indexPath(for id: AnyHashable) -> IndexPath? { cellLocations[id] }

    public func sectionSnapshot(at index: Int) -> SectionSnapshot<Layout>? {
        section(at: index)
    }

    public func cellPresenter(at indexPath: IndexPath) -> AnyCellPresenter? {
        section(at: indexPath.section)?.cell(at: indexPath.item)
    }

    public func supplementaryPresenter(ofKind kind: String, at indexPath: IndexPath) -> AnySupplementaryPresenter? {
        section(at: indexPath.section)?.supplementary(ofKind: kind, at: indexPath.item)
    }

    public func apply(
        from source: CollectionSnapshot<Layout>,
        to target: CollectionSnapshot<Layout>,
        animated: Bool,
        mode: CollectionUpdateMode
    ) async -> [CollectionDiagnostic] {
        guard mode == .diff, collectionView.window != nil else {
            reload(target)
            return []
        }
        // UIKit must consume the previous counts before the first batch.
        collectionView.layoutIfNeeded()
        let planningStart = SpikeTimings.now()
        let plan: CollectionUpdatePlan<Layout>
        do {
            if diffAlgorithm is SectionedDiff {
                let sourcePositions = try CollectionPositions(source.sections, input: .source)
                // Target snapshot validation already established target identity uniqueness.
                let input = PackedDiffInput(from: source.sections, to: target.sections,
                                            sourcePositions: sourcePositions)
                let workerStart = SpikeTimings.now()
                let result = try await Task.detached(priority: .userInitiated) {
                    precondition(!Thread.isMainThread)
                    return try PackedStructuralPlan.calculate(input)
                }.value
                SpikeTimings.workerWaitMs = SpikeTimings.elapsed(workerStart)
                plan = result.materialize(from: source, to: target, input: input)
            } else {
                plan = try CollectionUpdatePlan<Layout>(from: source, to: target, using: diffAlgorithm)
            }
        } catch {
            // Planning completes before mutating UIKit, so recovery installs target directly.
            reload(target)
            return [CollectionDiagnostic(
                reason: .invalidDiff(String(describing: error)),
                recovery: .reloadedTarget
            )]
        }

        SpikeTimings.planningMs = SpikeTimings.elapsed(planningStart)
        for batch in plan.batches {
            await performBatch(animated: animated) {
                self.sections = batch.sections
                // Structural edits invalidate the layout through UIKit. Explicit invalidation here
                // makes iOS 17 re-read the new snapshot as the pre-update item counts.
                if !batch.deletedSections.isEmpty {
                    self.collectionView.deleteSections(batch.deletedSections)
                }
                if !batch.insertedSections.isEmpty {
                    self.collectionView.insertSections(batch.insertedSections)
                }
                for move in batch.movedSections {
                    self.collectionView.moveSection(move.from, toSection: move.to)
                }
                if !batch.deletedItems.isEmpty {
                    self.collectionView.deleteItems(at: batch.deletedItems.map(\.indexPath))
                }
                if !batch.insertedItems.isEmpty {
                    self.collectionView.insertItems(at: batch.insertedItems.map(\.indexPath))
                }
                for move in batch.movedItems {
                    self.collectionView.moveItem(at: move.from.indexPath, to: move.to.indexPath)
                }
            }
        }

        let content = plan.content
        if !content.isEmpty {
            await performBatch(animated: animated) {
                self.sections = target.sections
                if content.hasLayoutUpdates {
                    self.collectionView.collectionViewLayout.invalidateLayout()
                }
                if !content.reloadedSections.isEmpty {
                    self.collectionView.reloadSections(content.reloadedSections)
                }
                if !content.replacedCells.isEmpty {
                    self.collectionView.reloadItems(at: content.replacedCells)
                }
                if !content.reconfiguredCells.isEmpty {
                    self.collectionView.reconfigureItems(at: content.reconfiguredCells)
                }
            }
        } else {
            sections = target.sections
        }
        views.reconfigureSupplementaries(content.supplementaryUpdates)
        return []
    }

    public func numberOfSections(in collectionView: UICollectionView) -> Int { sections.count }

    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.section(at: section)?.cells.count ?? 0
    }

    public func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath
    ) -> UICollectionViewCell {
        views.cell(at: indexPath, presenter: cellPresenter(at: indexPath))
    }

    public func collectionView(
        _ collectionView: UICollectionView,
        viewForSupplementaryElementOfKind kind: String,
        at indexPath: IndexPath
    ) -> UICollectionReusableView {
        views.supplementary(
            ofKind: kind,
            at: indexPath,
            presenter: supplementaryPresenter(ofKind: kind, at: indexPath)
        )
    }

    private func section(at index: Int) -> SectionSnapshot<Layout>? {
        sections.indices.contains(index) ? sections[index] : nil
    }

    private func reload(_ target: CollectionSnapshot<Layout>) {
        sections = target.sections
        collectionView.collectionViewLayout.invalidateLayout()
        collectionView.reloadData()
        collectionView.layoutIfNeeded()
    }

    private func performBatch(animated: Bool, updates: @escaping @MainActor () -> Void) async {
        await withCheckedContinuation { continuation in
            let perform = {
                self.collectionView.performBatchUpdates(updates) { _ in continuation.resume() }
            }
            if animated {
                perform()
            } else {
                UIView.performWithoutAnimation(perform)
            }
        }
    }
}

private extension ItemLocation {
    var indexPath: IndexPath { IndexPath(item: item, section: section) }
}
