# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,shutil,random,sys
root=Path(__file__).parent
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro')
variants=['baseline','previous','fast','lis'];containers={}
subprocess.run(['xcrun','simctl','bootstatus',u,'-b'],check=True)
for v in variants:
 r=root/v;bundle='dev.weixi.ParadeRound2'+v+'20261109'
 subprocess.run(['xcrun','simctl','install',u,str(r/'ArticleBench.app')],check=True)
 containers[v]=Path(subprocess.check_output(['xcrun','simctl','get_app_container',u,bundle,'data'],text=True).strip())
runs=[(0,100),(0,1000),(0,10000)] if '--smoke' in sys.argv else [(1,100),(1,1000),(1,10000),(2,10000),(2,100),(2,1000),(3,1000),(3,10000),(3,100)]
for rep,n in runs:
 order=(['fast','lis'] if rep==0 else variants).copy();random.Random(rep*821+n).shuffle(order)
 for v in order:
  r=root/v;bundle='dev.weixi.ParadeRound2'+v+'20261109';name=f'round2-{n}-{rep}';output=r/(name+'.json')
  if output.exists() and json.loads(output.read_text()).get('complete'):continue
  print('START',v,n,rep,flush=True)
  with (r/(name+'.log')).open('w') as f:p=subprocess.run(['xcrun','simctl','launch','--console','--terminate-running-process',u,bundle,str(rep),str(n)],stdout=f,stderr=subprocess.STDOUT,timeout=300)
  raw=containers[v]/'Documents'/output.name
  if raw.exists():shutil.copy2(raw,output)
  assert p.returncode==0 and output.exists(),v+' '+name
  d=json.loads(output.read_text());assert d['complete'] and len(d['records'])==36
  print('DONE',v,n,rep,flush=True)
