# Created by weixi on 2026/11/09.
from pathlib import Path
import json,statistics,math,sys,csv
root=Path(__file__).parent;groups={};files=[]
for v in ['baseline','previous','fast','lis']:
 for p in sorted((root/v).glob('round2-*-*.json')):
  d=json.loads(p.read_text())
  if d['repetition']==0 or not d['complete']:continue
  assert len(d['records'])==36;files.append(p)
  for row in d['records']:
   key=(v,d['n'],row['scenario'],row['engine']);groups.setdefault(key,[]).append((d['repetition'],row['samples']))
results=[]
fields=['totalMs','prepareMs','applyMs','layoutMs','planningMs','workerWaitMs','mainPreparePlanMs','batches','configuredCells','itemMoves','sectionMoves','reloadCalls','reconfiguredItems','reloadedItems']
for (v,n,s,e),runs in sorted(groups.items()):
 if '--partial' not in sys.argv:assert len(runs)==3
 x={'variant':v,'n':n,'scenario':s,'engine':e,'runs':len(runs),'samples':sum(len(ss) for _,ss in runs)}
 for field in fields:
  meds=[statistics.median(a[field] for a in ss) for _,ss in runs];x[field]=statistics.median(meds)
 x['runMedians']=[{'repetition':rep,'totalMs':statistics.median(a['totalMs'] for a in ss),'mainPreparePlanMs':statistics.median(a['mainPreparePlanMs'] for a in ss)} for rep,ss in runs]
 pool=[a['totalMs'] for _,ss in runs for a in ss];x['p95Ms']=sorted(pool)[math.ceil(len(pool)*.95)-1]
 assert x['reloadCalls']==0
 results.append(x)
if '--partial' not in sys.argv:
 assert len(files)==36 and len(results)==432 and sum(x['samples'] for x in results)==12960
 (root/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
 with (root/'summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=[k for k in results[0] if k!='runMedians'],extrasaction='ignore');w.writeheader();w.writerows(results)
for n in [100,1000,10000]:
 for s in ['no-op','update-pct50','rotate-left-1','shuffle','cross-section-update-pct5']:
  xs=[x for x in results if x['n']==n and x['scenario']==s and (x['engine']=='Current-staged' or x['variant']=='lis')]
  if xs:print(n,s,' '.join(f'{x["variant"]}/{x["engine"]}:{x["totalMs"]:.2f}(main {x["mainPreparePlanMs"]:.2f}, moves {x["itemMoves"]})' for x in xs))
print('completed processes',len(files),'formal samples',sum(x['samples'] for x in results))
