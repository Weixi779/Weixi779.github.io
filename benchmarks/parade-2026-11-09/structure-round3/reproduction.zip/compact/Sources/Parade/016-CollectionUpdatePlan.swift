// Created by weixi on 2026/09/17.

/// A complete update, constructed and validated before UIKit receives any edits.
/// Batches retain source content; the final content phase installs the target.
struct CollectionUpdatePlan<Layout> {
    let batches: [CollectionBatch<Layout>]
    let content: CollectionContentUpdates<Layout>

    init(
        from source: CollectionSnapshot<Layout>,
        to target: CollectionSnapshot<Layout>,
        using algorithm: any SectionedDiffAlgorithm = SectionedDiff(),
        prepared: PreparedSectionedDiff? = nil,
        profile: StructureProfile = StructureProfile()
    ) throws {
        let sourcePositions: CollectionPositions<AnyHashable, AnyHashable>
        let targetPositions: CollectionPositions<AnyHashable, AnyHashable>
        let changes: SectionedChanges
        if let prepared {
            sourcePositions = prepared.sourcePositions
            targetPositions = prepared.targetPositions
            changes = prepared.changes
        } else {
            sourcePositions = try CollectionPositions(source.sections, input: .source)
            targetPositions = try CollectionPositions(target.sections, input: .target)
            if algorithm is SectionedDiff {
                changes = try PackedDiffInput(from: source.sections, to: target.sections, sourcePositions: sourcePositions).calculate()
            } else {
                // Custom algorithms keep the original generic input and validation contract.
                changes = try algorithm.diff(from: source.sections, to: target.sections)
            }
        }
        try profile.measure("changesValidationMs") { try Self.validate(
            changes, from: source.sections, to: target.sections,
            sourcePositions: sourcePositions, targetPositions: targetPositions
        ) }

        // Retained identities keep their source presenters even when moved into a
        // new section. Construct this once; every batch then carries real contents.
        let buildStart = StructureProfile.now()
        let destinations = target.sections.map { section in
            let metadata = source.sectionsById[section.id] ?? section
            return metadata.replacingCells(section.cells.map { source.cellsById[$0.id] ?? $0 })
        }
        var batches: [CollectionBatch<Layout>] = []
        var current = source.sections

        // Create new destinations before moving retained cells into them. Anchor
        // them before the next surviving section to avoid moves for plain inserts.
        if !changes.insertedSections.isEmpty {
            var insertions = [[SectionSnapshot<Layout>]](repeating: [], count: current.count + 1)
            var anchor = current.count
            for (index, section) in destinations.enumerated().reversed() {
                if let origin = sourcePositions.sectionIndices[section.id] {
                    anchor = origin
                } else if changes.insertedSections.contains(index) {
                    insertions[anchor].append(section.replacingCells(section.cells.filter {
                        sourcePositions.itemLocations[$0.id] == nil
                    }))
                }
            }
            var batch = CollectionBatch<Layout>(sections: [])
            for position in 0...current.count {
                for section in insertions[position].reversed() {
                    batch.insertedSections.insert(batch.sections.count)
                    batch.sections.append(section)
                }
                if position < current.count { batch.sections.append(current[position]) }
            }
            batches.append(batch)
            current = batch.sections
        }

        let sectionPositions = Dictionary(uniqueKeysWithValues: current.enumerated().map {
            ($0.element.id, $0.offset)
        })
        func origin(_ location: ItemLocation) -> ItemLocation {
            ItemLocation(
                section: sectionPositions[source.sections[location.section].id]!,
                item: location.item
            )
        }
        func destination(_ location: ItemLocation) -> ItemLocation {
            ItemLocation(
                section: sectionPositions[target.sections[location.section].id]!,
                item: location.item
            )
        }

        // Section positions stay stable during cell edits. Cells that disappear
        // together with their section remain until the final section batch.
        let itemContents = current.map { section in
            if let index = targetPositions.sectionIndices[section.id] {
                return destinations[index]
            }
            return section.replacingCells(section.cells.filter {
                targetPositions.itemLocations[$0.id] == nil
            })
        }
        let itemBatch = CollectionBatch<Layout>(
            sections: itemContents,
            deletedItems: changes.deletedItems.filter {
                !changes.deletedSections.contains($0.section)
            }.map(origin),
            insertedItems: changes.insertedItems.filter {
                !changes.insertedSections.contains($0.section)
            }.map(destination),
            movedItems: changes.movedItems.map { (from: origin($0.from), to: destination($0.to)) }
        )
        if !itemBatch.isEmpty {
            batches.append(itemBatch)
            current = itemContents
        }

        if current.map(\.id) != destinations.map(\.id) || !changes.movedSections.isEmpty {
            var sectionBatch = CollectionBatch<Layout>(
                sections: destinations,
                deletedSections: .init(changes.deletedSections.map {
                    sectionPositions[source.sections[$0].id]!
                }),
                movedSections: changes.movedSections.map {
                    (from: sectionPositions[source.sections[$0.from].id]!, to: $0.to)
                }
            )
            // Inserted sections may need to move from their temporary position.
            // Retained section moves remain exactly as the algorithm supplied.
            for index in changes.insertedSections {
                sectionBatch.movedSections.append((
                    from: sectionPositions[target.sections[index].id]!, to: index
                ))
            }
            if !sectionBatch.isEmpty { batches.append(sectionBatch) }
        }

        profile.values["buildBatchesMs"] = Double(StructureProfile.now() - buildStart) / 1e6
        try profile.measure("batchReplayMs") { try Self.validate(batches, from: source.sections, to: target.sections, inputsAlreadyValidated: true) }
        self.batches = batches
        content = profile.measure("discardedContentMs") { CollectionContentUpdates<Layout>(
            from: source, to: target,
            updatedSections: changes.updatedSections, updatedItems: Set(changes.updatedItems)
        ) }
    }

    init(batches: [CollectionBatch<Layout>], content: CollectionContentUpdates<Layout>) {
        self.batches = batches
        self.content = content
    }

    typealias ValidationError = CollectionPlanValidationError
}

struct CollectionPlanValidationError: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) {
        self.description = description
    }
}
