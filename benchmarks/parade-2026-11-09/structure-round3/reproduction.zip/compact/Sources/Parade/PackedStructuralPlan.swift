// Created by weixi on 2026/11/09.
import UIKit

// Internal experiment. All values crossing the worker boundary are Sendable.
struct PackedStructuralPlan: Sendable {
    struct Contents: Sendable { let section: Int; let items: [Int] }
    struct Batch: Sendable {
        let contents: [Contents]
        let deletedSections: IndexSet
        let insertedSections: IndexSet
        let movedSections: [(from: Int, to: Int)]
        let deletedItems: [ItemLocation]
        let insertedItems: [ItemLocation]
        let movedItems: [(from: ItemLocation, to: ItemLocation)]
    }
    let changes: SectionedChanges
    let batches: [Batch]
    let metrics: [String: Double]

    static func calculate(_ input: PackedDiffInput) throws -> Self {
        let profile = StructureProfile()
        func capture(_ sections: [PackedDiffInput.Section]) throws -> CollectionSnapshot<Int> {
            let snapshots = profile.measure("workerPresentersMs") { sections.map { section in
                SectionSnapshot(id: section.id,
                    cells: section.items.map { AnyCellPresenter(WorkerPresenter(id: $0.id, changed: $0.changed)) },
                    layout: 0)
            } }
            return try profile.measure("workerSnapshotsMs") { try CollectionSnapshot(snapshots) }
        }
        let changes = try profile.measure("diffMs") { try input.calculate() }
        if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty && changes.movedSections.isEmpty &&
           changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            // Inputs are already validated snapshots. No structural operation exists
            // to replay, so avoid constructing worker-local intermediate snapshots.
            return Self(changes: changes, batches: [], metrics: profile.values)
        }

        if input.source.map(\.id) == input.target.map(\.id) {
            let batch = Batch(contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\.id)) },
                deletedSections: [], insertedSections: [], movedSections: [],
                deletedItems: changes.deletedItems, insertedItems: changes.insertedItems,
                movedItems: changes.movedItems)
            try profile.measure("typedReplayMs") { try validateItemBatch(batch, input: input) }
            return Self(changes: changes, batches: [batch], metrics: profile.values)
        }

        // Presenter erasers below are created and consumed entirely inside this worker.
        let source = try capture(input.source)
        let target = try capture(input.target)
        let prepared = try profile.measure("workerPositionsMs") { PreparedSectionedDiff(changes: changes,
            sourcePositions: try CollectionPositions(source.sections, input: .source),
            targetPositions: try CollectionPositions(target.sections, input: .target)) }
        let plan = try CollectionUpdatePlan(from: source, to: target, prepared: prepared, profile: profile)
        let batches = profile.measure("encodeBatchesMs") { plan.batches.map { batch in
            Batch(contents: batch.sections.map { section in
                Contents(section: section.id.base as! Int, items: section.cells.map { $0.id.base as! Int })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        } }
        return Self(changes: changes, batches: batches, metrics: profile.values)
    }

    // Same replay guarantee, on dense IDs; source/target uniqueness was checked
    // at capture. This path only accepts unchanged section identities and order.
    static func validateItemBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ value: Bool) throws {
            if !value { throw CollectionPlanValidationError("Invalid compact item replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target))
            try check(slots[p.section][p.item] == -1)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for m in batch.movedItems {
            try check(valid(m.from, input.source) && valid(m.to, input.target))
            try check(!removed[m.from.section][m.from.item] && slots[m.to.section][m.to.item] == -1)
            removed[m.from.section][m.from.item] = true
            slots[m.to.section][m.to.item] = input.source[m.from.section].items[m.from.item].id
        }
        for s in input.source.indices {
            var origin = 0
            for d in slots[s].indices {
                if slots[s][d] == -1 {
                    while origin < removed[s].count && removed[s][origin] { origin += 1 }
                    try check(origin < removed[s].count)
                    slots[s][d] = input.source[s].items[origin].id
                    origin += 1
                }
                try check(slots[s][d] == input.target[s].items[d].id)
            }
            while origin < removed[s].count && removed[s][origin] { origin += 1 }
            try check(origin == removed[s].count)
        }
    }

    func materialize<L>(from source: CollectionSnapshot<L>, to target: CollectionSnapshot<L>,
                        input: PackedDiffInput) -> CollectionUpdatePlan<L> {
        if batches.isEmpty {
            return CollectionUpdatePlan(batches: [], content: CollectionContentUpdates(
                from: source, to: target, updatedSections: changes.updatedSections,
                updatedItems: Set(changes.updatedItems)))
        }
        let oldItems = source.sections.flatMap(\.cells)
        var added: [AnyCellPresenter] = []
        for (encoded, section) in zip(input.target, target.sections) {
            for (item, presenter) in zip(encoded.items, section.cells) where item.id >= oldItems.count {
                precondition(item.id == oldItems.count + added.count)
                added.append(presenter)
            }
        }
        let batches = batches.map { batch in
            CollectionBatch<L>(sections: batch.contents.map { content in
                let original = content.section < source.sections.count
                    ? source.sections[content.section]
                    : target.sections[content.section - source.sections.count]
                return original.replacingCells(content.items.map {
                    $0 < oldItems.count ? oldItems[$0] : added[$0 - oldItems.count]
                })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        }
        return CollectionUpdatePlan(batches: batches,
            content: CollectionContentUpdates(from: source, to: target,
                updatedSections: changes.updatedSections, updatedItems: Set(changes.updatedItems)))
    }
}

private struct WorkerPresenter: CellPresenter {
    let id: Int
    let changed: Bool
    @MainActor func configure(_ cell: UICollectionViewCell) {}
}
