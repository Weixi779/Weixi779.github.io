// Created by weixi on 2026/11/09.
struct PreparedSectionedDiff {
    let changes: SectionedChanges
    let sourcePositions: CollectionPositions<AnyHashable, AnyHashable>
    let targetPositions: CollectionPositions<AnyHashable, AnyHashable>
}
