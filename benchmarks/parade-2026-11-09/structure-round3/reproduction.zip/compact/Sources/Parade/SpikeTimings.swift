// Created by weixi on 2026/11/09.
import Foundation
@MainActor enum SpikeTimings {
    static var detail: [String: Double] = [:]
    static var planningMs: Double = 0
    static var workerWaitMs: Double = 0
    static func now() -> UInt64 { DispatchTime.now().uptimeNanoseconds }
    static func elapsed(_ start: UInt64) -> Double { Double(now()-start)/1e6 }
    static func reset() { planningMs=0;workerWaitMs=0;detail=[:] }
}
