// Created by weixi on 2026/11/09.
import Foundation
final class StructureProfile {
    var values: [String: Double] = [:]
    static func now() -> UInt64 { DispatchTime.now().uptimeNanoseconds }
    func measure<T>(_ key: String, _ body: () throws -> T) rethrows -> T {
        let start = Self.now()
        defer { values[key, default: 0] += Double(Self.now() - start) / 1e6 }
        return try body()
    }
}
