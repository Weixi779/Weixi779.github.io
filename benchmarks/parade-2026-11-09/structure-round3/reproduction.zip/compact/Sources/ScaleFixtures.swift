// Created by weixi on 2026/11/09.
import Foundation

struct ScaleCase {
    let fixture:UIFixture
    let changeCount:Int
    let changeMode:String
}
func scaleFixtures(_ n:Int)->[ScaleCase] {
    let old=(0..<n).map { UIItem(id:"section-0:item-\($0)") }
    var result:[ScaleCase]=[]
    func add(_ name:String,_ values:[UIItem],_ count:Int,_ mode:String) {
        result.append(ScaleCase(fixture:UIFixture(name:name,old:[UISection(model:UIHeader(id:0),elements:old)],new:[UISection(model:UIHeader(id:0),elements:values)],flat:true),changeCount:count,changeMode:mode))
    }
    for (mode,k) in [("fixed5",5),("pct5",n/20),("pct25",n/4),("pct50",n/2)] {
        let indices=(0..<k).map { $0*n/k }
        let deletions=Set(indices.map { min(n-1,$0+1) })
        let extra=(n..<n+k).map { UIItem(id:"section-0:item-\($0)") }
        add("append-"+mode,old+extra,k,mode)
        add("delete-"+mode,old.enumerated().filter { !deletions.contains($0.offset) }.map(\.element),k,mode)
        var updated=old
        for i in indices { updated[i].revision += 1 }
        add("update-"+mode,updated,k,mode)
        var mixed=updated.enumerated().filter { !deletions.contains($0.offset) }.map(\.element)
        mixed.insert(contentsOf:extra,at:min(mixed.count,n/3))
        mixed=Array(mixed.dropFirst(k))+Array(mixed.prefix(k))
        add("mixed-"+mode,mixed,k,mode)
    }
    add("no-op",old,0,"none")
    add("rotate-left-1",Array(old.dropFirst())+Array(old.prefix(1)),1,"reorder")
    add("rotate-right-1",Array(old.suffix(1))+Array(old.dropLast()),1,"reorder")
    var rng=BenchRNG(state:0x504152414445 ^ UInt64(n));var shuffled=old;shuffled.shuffle(using:&rng)
    add("shuffle",shuffled,n,"reorder")
    let sections=(0..<10).map { s in UISection(model:UIHeader(id:s),elements:Array(old[s*(n/10)..<(s+1)*(n/10)])) }
    let rotated=Array(sections.dropFirst())+Array(sections.prefix(1))
    result.append(ScaleCase(fixture:UIFixture(name:"section-rotate-left",old:sections,new:rotated,flat:false),changeCount:1,changeMode:"section"))
    var crossed=sections
    let k=n/20
    let moved=crossed[0].elements.prefix(k).map { UIItem(id:$0.id,revision:$0.revision+1) }
    crossed[0].elements.removeFirst(k);crossed[1].elements.insert(contentsOf:moved,at:0)
    result.append(ScaleCase(fixture:UIFixture(name:"cross-section-update-pct5",old:sections,new:crossed,flat:false),changeCount:k,changeMode:"section"))
    return result
}
