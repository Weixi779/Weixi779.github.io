# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,plistlib,json,hashlib
r=Path(__file__).parent;lib=r.parent/'ListKit';app=r/'ArticleBench.app';app.mkdir(exist_ok=True)
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
cmd=['xcrun','swiftc','-O','-whole-module-optimization','-swift-version','5','-enable-upcoming-feature','IsolatedDefaultValues','-sdk',sdk,'-target','arm64-apple-ios17.0-simulator','-module-cache-path',str(r/'ModuleCache'),'-I',str(lib),'-L',str(lib),'-lListKit']+[str(p) for p in sorted((r/'Sources').rglob('*.swift'))]+['-o',str(app/'ArticleBench')]
subprocess.run(cmd,check=True)
with (app/'Info.plist').open('wb') as f:
 plistlib.dump({'CFBundleIdentifier':'dev.weixi.ParadeStructuredirectUI20261109','CFBundleName':'Parade Round 2','CFBundleExecutable':'ArticleBench','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1.0','MinimumOSVersion':'17.0','LSRequiresIPhoneOS':True,'UIDeviceFamily':[1,2],'UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False}},f)
subprocess.run(['codesign','--force','--sign','-',str(app)],check=True)
env=json.loads((r/'environment.json').read_text());env['compileCommand']=[part.replace(str(r.parent),'EXPERIMENT_ROOT') for part in cmd];env['binarySHA256']=hashlib.sha256((app/'ArticleBench').read_bytes()).hexdigest();env['allSourceHashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'Sources').rglob('*.swift')};(r/'environment.json').write_text(json.dumps(env,indent=2))
