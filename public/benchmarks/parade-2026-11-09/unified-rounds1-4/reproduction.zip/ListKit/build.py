# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],text=True).strip()
files=sorted((r/'Sources').rglob('*.swift'))
cmd=['xcrun','swiftc','-parse-as-library','-emit-library','-static','-emit-module','-module-name','ListKit','-emit-module-path',str(r/'ListKit.swiftmodule'),'-O','-whole-module-optimization','-swift-version','5','-sdk',sdk,'-target','arm64-apple-ios17.0-simulator','-module-cache-path',str(r/'ModuleCache')]+[str(p) for p in files]+['-o',str(r/'libListKit.a')]
subprocess.run(cmd,check=True)
(r/'environment.json').write_text(json.dumps({'commit':'221e1513f2786a4e5e836c9b76092c3bd6e61575','compileCommand':[x.replace(str(r),'LISTKIT_ROOT') for x in cmd],'hashes':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},indent=2))
