// Created by weixi on 2026/09/17.

import Foundation

/// A validated display version of the whole collection, with section and cell indexes.
/// Completed baselines and update targets use these snapshots; intermediate section
/// snapshots belong to update batches. This stores captured content, not live section instances.
public struct CollectionSnapshot<Layout> {
    let positions: CollectionPositions<AnyHashable, AnyHashable>
    public let sections: [SectionSnapshot<Layout>]
    public let sectionsById: [AnyHashable: SectionSnapshot<Layout>]
    public let cellsById: [AnyHashable: AnyCellPresenter]

    public static var empty: Self { Self() }

    private init() {
        positions = CollectionPositions(sectionIndices: [:], itemLocations: [:])
        sections = []
        sectionsById = [:]
        cellsById = [:]
    }

    /// Validate each section completely before the next, preserving error order.
    init(_ sections: [SectionSnapshot<Layout>]) throws(CollectionValidationFailure) {
        var sectionLocations = [AnyHashable: Int](minimumCapacity: sections.count)
        var cellLocations: [AnyHashable: ItemLocation] = [:]
        for (sectionIndex, section) in sections.enumerated() {
            if let first = sectionLocations.updateValue(sectionIndex, forKey: section.id) {
                throw CollectionValidationFailure(
                    .duplicateSectionId(String(describing: section.id)),
                    locations: [.init(section: first), .init(section: sectionIndex)]
                )
            }
            for (item, presenter) in section.cells.enumerated() {
                let location = ItemLocation(section: sectionIndex, item: item)
                if let first = cellLocations.updateValue(location, forKey: presenter.id) {
                    throw CollectionValidationFailure(
                        .duplicateCellId(String(describing: presenter.id)),
                        locations: [
                            .init(section: first.section, item: first.item),
                            .init(section: sectionIndex, item: item)
                        ]
                    )
                }
            }
            try Self.validateSupplementaries(in: section, at: sectionIndex)
        }
        positions = CollectionPositions(sectionIndices: sectionLocations, itemLocations: cellLocations)
        self.sections = sections
        sectionsById = sectionLocations.mapValues { sections[$0] }
        cellsById = cellLocations.mapValues { sections[$0.section].cells[$0.item] }
    }
}

// Validation errors do not depend on Layout. Keeping this type outside the generic
// snapshot also avoids a Swift 6.0 compiler crash when lowering typed throws.
struct CollectionValidationFailure: Error {
    let error: CollectionUpdateError
    let diagnostic: CollectionDiagnostic

    init(_ error: CollectionUpdateError, locations: [CollectionDiagnostic.Location]) {
        self.error = error
        diagnostic = CollectionDiagnostic(
            reason: .invalidUpdate(error), recovery: .rejectedUpdate, locations: locations
        )
    }
}

private extension CollectionSnapshot {
    struct SupplementaryAddress: Hashable {
        let kind: String
        let item: Int
    }

    struct SupplementaryIdentity: Hashable {
        let kind: String
        let id: AnyHashable
    }

    static func validateSupplementaries(
        in section: SectionSnapshot<Layout>,
        at sectionIndex: Int
    ) throws(CollectionValidationFailure) {
        let sectionDescription = String(describing: section.id)
        var placements: [SupplementaryAddress: CollectionDiagnostic.Location] = [:]
        var identities: [SupplementaryIdentity: CollectionDiagnostic.Location] = [:]
        for presenter in section.supplementaryViews {
            let address = SupplementaryAddress(kind: presenter.elementKind, item: presenter.itemIndex)
            let location = CollectionDiagnostic.Location(section: sectionIndex, item: address.item)
            guard !address.kind.isEmpty, address.item >= 0 else {
                throw CollectionValidationFailure(
                    .invalidSupplementaryPlacement(
                        section: sectionDescription, kind: address.kind, item: address.item
                    ),
                    locations: [location]
                )
            }
            if let first = placements.updateValue(location, forKey: address) {
                throw CollectionValidationFailure(
                    .duplicateSupplementaryPlacement(
                        section: sectionDescription, kind: address.kind, item: address.item
                    ),
                    locations: [first, location]
                )
            }
            let identity = SupplementaryIdentity(kind: address.kind, id: presenter.id)
            if let first = identities.updateValue(location, forKey: identity) {
                throw CollectionValidationFailure(
                    .duplicateSupplementaryId(
                        section: sectionDescription, kind: identity.kind,
                        id: String(describing: identity.id)
                    ),
                    locations: [first, location]
                )
            }
        }
    }
}
