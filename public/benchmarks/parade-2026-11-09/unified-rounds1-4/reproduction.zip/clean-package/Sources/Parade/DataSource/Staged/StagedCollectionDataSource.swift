// Created by weixi on 2026/09/17.

import UIKit

/// Staged UIKit updates: replaceable sectioned diff and validated UIKit batches.
@MainActor
public final class StagedCollectionDataSource<Layout>: NSObject, CollectionDataSource, UICollectionViewDataSource {
    private let collectionView: UICollectionView
    private let views: CollectionViews
    private let diffAlgorithm: any SectionedDiffAlgorithm
    private var sectionLocations: [AnyHashable: Int] = [:]
    private var cellLocations: [AnyHashable: ItemLocation] = [:]

    private var installedSections: [SectionSnapshot<Layout>] = []
    var sections: [SectionSnapshot<Layout>] {
        get { installedSections }
        set { install(newValue) }
    }

    // Intermediate custom-algorithm batches establish their own positions.
    // A validated built-in batch can reuse the target snapshot's position table.
    private func install(
        _ sections: [SectionSnapshot<Layout>],
        positions: CollectionPositions<AnyHashable, AnyHashable>? = nil
    ) {
        installedSections = sections
        if let positions {
            sectionLocations = positions.sectionIndices
            cellLocations = positions.itemLocations
            return
        }
        sectionLocations.removeAll(keepingCapacity: true)
        cellLocations.removeAll(keepingCapacity: true)
        for (index, section) in sections.enumerated() {
            sectionLocations[section.id] = index
            for (item, presenter) in section.cells.enumerated() {
                cellLocations[presenter.id] = ItemLocation(section: index, item: item)
            }
        }
    }

    public init(
        collectionView: UICollectionView,
        views: CollectionViews,
        diffAlgorithm: any SectionedDiffAlgorithm = SectionedDiff()
    ) {
        self.collectionView = collectionView
        self.views = views
        self.diffAlgorithm = diffAlgorithm
        super.init()
    }

    public var dataSource: any UICollectionViewDataSource { self }
    public var sectionIds: [AnyHashable] { sections.map(\.id) }
    public var numberOfSections: Int { sections.count }
    public var numberOfItems: Int { cellLocations.count }
    public var isEmpty: Bool { sections.allSatisfy(\.isEmpty) }

    public func sectionId(at index: Int) -> AnyHashable? { section(at: index)?.id }
    public func sectionIndex(for id: AnyHashable) -> Int? { sectionLocations[id] }
    public func indexPath(for id: AnyHashable) -> IndexPath? { cellLocations[id]?.indexPath }

    public func sectionSnapshot(at index: Int) -> SectionSnapshot<Layout>? {
        section(at: index)
    }

    public func cellPresenter(at indexPath: IndexPath) -> AnyCellPresenter? {
        section(at: indexPath.section)?.cell(at: indexPath.item)
    }

    public func supplementaryPresenter(ofKind kind: String, at indexPath: IndexPath) -> AnySupplementaryPresenter? {
        section(at: indexPath.section)?.supplementary(ofKind: kind, at: indexPath.item)
    }

    public func apply(
        from source: CollectionSnapshot<Layout>,
        to target: CollectionSnapshot<Layout>,
        animated: Bool,
        mode: CollectionUpdateMode
    ) async -> [CollectionDiagnostic] {
        guard mode == .diff, collectionView.window != nil else {
            reload(target)
            return []
        }
        // UIKit must consume the previous counts before the first batch.
        collectionView.layoutIfNeeded()
        let plan: CollectionUpdatePlan<Layout>
        do {
            plan = try await makePlan(from: source, to: target)
        } catch {
            // Planning completes before mutating UIKit, so recovery installs target directly.
            reload(target)
            return [CollectionDiagnostic(
                reason: .invalidDiff(String(describing: error)),
                recovery: .reloadedTarget
            )]
        }

        for batch in plan.batches {
            await performBatch(animated: animated) {
                let positions = self.diffAlgorithm is SectionedDiff ? target.positions : nil
                self.install(batch.sections, positions: positions)
                self.applyStructure(batch)
            }
        }

        let content = plan.content
        if !animated {
            UIView.performWithoutAnimation { self.applyContent(content, target: target) }
            collectionView.layoutIfNeeded()
        } else if !content.isEmpty {
            await performBatch(animated: true) { self.applyContent(content, target: target) }
        } else {
            installedSections = target.sections
        }
        views.reconfigureSupplementaries(content.supplementaryUpdates)
        return []
    }

    private func makePlan(
        from source: CollectionSnapshot<Layout>,
        to target: CollectionSnapshot<Layout>
    ) async throws -> CollectionUpdatePlan<Layout> {
        guard diffAlgorithm is SectionedDiff else {
            return try CollectionUpdatePlan(from: source, to: target, using: diffAlgorithm)
        }
        let input = PackedDiffInput(from: source.sections, to: target.sections,
                                    sourcePositions: source.positions)
        let result: PackedStructuralPlan
        // Retain the measured prototype's scheduling policy for this comparison.
        // This threshold has not been tuned for the application's workload.
        if max(source.cellsById.count, target.cellsById.count) >= 1_000 {
            result = try await Task.detached(priority: .userInitiated) {
                precondition(!Thread.isMainThread)
                return try PackedStructuralPlan.calculate(input)
            }.value
        } else {
            result = try PackedStructuralPlan.calculate(input)
        }
        return result.materialize(from: source, to: target, input: input)
    }

    private func applyStructure(_ batch: CollectionBatch<Layout>) {
        // UIKit invalidates structural edits itself. Explicit invalidation here
        // can make it read target counts as the pre-update counts.
        if !batch.deletedSections.isEmpty { collectionView.deleteSections(batch.deletedSections) }
        if !batch.insertedSections.isEmpty { collectionView.insertSections(batch.insertedSections) }
        for move in batch.movedSections {
            collectionView.moveSection(move.from, toSection: move.to)
        }
        if !batch.deletedItems.isEmpty { collectionView.deleteItems(at: batch.deletedItems.map(\.indexPath)) }
        if !batch.insertedItems.isEmpty { collectionView.insertItems(at: batch.insertedItems.map(\.indexPath)) }
        for move in batch.movedItems {
            collectionView.moveItem(at: move.from.indexPath, to: move.to.indexPath)
        }
    }

    private func applyContent(_ content: CollectionContentUpdates<Layout>, target: CollectionSnapshot<Layout>) {
        // Structure has already established final positions. Only presenters change.
        installedSections = target.sections
        if content.hasLayoutUpdates { collectionView.collectionViewLayout.invalidateLayout() }
        if !content.reloadedSections.isEmpty { collectionView.reloadSections(content.reloadedSections) }
        if !content.replacedCells.isEmpty { collectionView.reloadItems(at: content.replacedCells) }
        if !content.reconfiguredCells.isEmpty { collectionView.reconfigureItems(at: content.reconfiguredCells) }
    }

    public func numberOfSections(in collectionView: UICollectionView) -> Int { sections.count }

    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.section(at: section)?.cells.count ?? 0
    }

    public func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath
    ) -> UICollectionViewCell {
        views.cell(at: indexPath, presenter: cellPresenter(at: indexPath))
    }

    public func collectionView(
        _ collectionView: UICollectionView,
        viewForSupplementaryElementOfKind kind: String,
        at indexPath: IndexPath
    ) -> UICollectionReusableView {
        views.supplementary(
            ofKind: kind,
            at: indexPath,
            presenter: supplementaryPresenter(ofKind: kind, at: indexPath)
        )
    }

    private func section(at index: Int) -> SectionSnapshot<Layout>? {
        sections.indices.contains(index) ? sections[index] : nil
    }

    private func reload(_ target: CollectionSnapshot<Layout>) {
        install(target.sections, positions: target.positions)
        collectionView.collectionViewLayout.invalidateLayout()
        collectionView.reloadData()
        collectionView.layoutIfNeeded()
    }

    private func performBatch(animated: Bool, updates: @escaping @MainActor () -> Void) async {
        await withCheckedContinuation { continuation in
            let perform = {
                self.collectionView.performBatchUpdates(updates) { _ in continuation.resume() }
            }
            if animated {
                perform()
            } else {
                UIView.performWithoutAnimation(perform)
            }
        }
    }
}

private extension ItemLocation {
    var indexPath: IndexPath { IndexPath(item: item, section: section) }
}
