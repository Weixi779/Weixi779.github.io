// Created by weixi on 2026/11/09.
// Internal unique-identity matcher. LIS chooses stationary survivors; all other
// changes and content comparisons keep the existing sectioned diff semantics.
import Foundation

enum PackedLIS {
    static func diff<S: DiffableSection>(from source: [S], to target: [S]) throws -> SectionedChanges {
        let oldIndex = try CollectionPositions(source, input: .source)
        let newIndex = try CollectionPositions(target, input: .target)
        var result = SectionedChanges()
        let sections = target.enumerated().compactMap { index, section -> (old: Int, new: Int)? in
            oldIndex.sectionIndices[section.id].map { ($0, index) }
        }
        let stableSections = stableTargets(sections)
        for (section, value) in source.enumerated() {
            if newIndex.sectionIndices[value.id] == nil { result.deletedSections.insert(section) }
            for (item, value) in value.items.enumerated() where newIndex.itemLocations[value.id] == nil {
                result.deletedItems.append(ItemLocation(section: section, item: item))
            }
        }
        for (section, value) in target.enumerated() {
            if let origin = oldIndex.sectionIndices[value.id] {
                if !stableSections.contains(section) { result.movedSections.append((origin, section)) }
                if !source[origin].isContentEqual(to: value) { result.updatedSections.insert(section) }
            } else { result.insertedSections.insert(section) }
            let pairs = value.items.enumerated().compactMap { index, item -> (old: Int, new: Int)? in
                guard let old = oldIndex.itemLocations[item.id], source[old.section].id == value.id else { return nil }
                return (old.item, index)
            }
            let stableItems = stableTargets(pairs)
            for (item, valueItem) in value.items.enumerated() {
                let destination = ItemLocation(section: section, item: item)
                guard let old = oldIndex.itemLocations[valueItem.id] else {
                    result.insertedItems.append(destination)
                    continue
                }
                if source[old.section].id != value.id || !stableItems.contains(item) {
                    result.movedItems.append((old, destination))
                }
                if source[old.section].items[old.item] != valueItem { result.updatedItems.append(destination) }
            }
        }
        return result
    }

    // Patience sorting, O(n log n). Return destination coordinates in one LIS.
    private static func stableTargets(_ pairs: [(old: Int, new: Int)]) -> Set<Int> {
        guard !pairs.isEmpty else { return [] }
        var tails = ContiguousArray<Int>()
        tails.reserveCapacity(pairs.count)
        var previous = ContiguousArray(repeating: -1, count: pairs.count)
        for i in pairs.indices {
            var low = 0, high = tails.count
            while low < high {
                let middle = (low + high) / 2
                if pairs[tails[middle]].old < pairs[i].old { low = middle + 1 } else { high = middle }
            }
            if low > 0 { previous[i] = tails[low - 1] }
            if low == tails.count { tails.append(i) } else { tails[low] = i }
        }
        var stable = Set<Int>(minimumCapacity: tails.count)
        var cursor = tails.last!
        while cursor >= 0 {
            stable.insert(pairs[cursor].new)
            cursor = previous[cursor]
        }
        return stable
    }
}
