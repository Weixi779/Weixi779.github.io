// Created by weixi on 2026/11/09.
import Foundation

extension PackedStructuralPlan {
    // Same replay guarantee, on dense IDs; source/target uniqueness was checked
    // at capture. This path only accepts unchanged section identities and order.
    static func validateItemBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ value: Bool) throws {
            if !value { throw CollectionPlanValidationError("Invalid compact item replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target))
            try check(slots[p.section][p.item] == -1)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for m in batch.movedItems {
            try check(valid(m.from, input.source) && valid(m.to, input.target))
            try check(!removed[m.from.section][m.from.item] && slots[m.to.section][m.to.item] == -1)
            removed[m.from.section][m.from.item] = true
            slots[m.to.section][m.to.item] = input.source[m.from.section].items[m.from.item].id
        }
        for s in input.source.indices {
            var origin = 0
            for d in slots[s].indices {
                if slots[s][d] == -1 {
                    while origin < removed[s].count && removed[s][origin] { origin += 1 }
                    try check(origin < removed[s].count)
                    slots[s][d] = input.source[s].items[origin].id
                    origin += 1
                }
                try check(slots[s][d] == input.target[s].items[d].id)
            }
            while origin < removed[s].count && removed[s][origin] { origin += 1 }
            try check(origin == removed[s].count)
        }
    }

    static func validateSectionReorder(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ condition: Bool) throws {
            if !condition { throw CollectionPlanValidationError("Invalid compact section replay") }
        }
        try check(input.source.count == input.target.count)
        var removed = [Bool](repeating: false, count: input.source.count)
        var slots = [Int](repeating: -1, count: input.target.count)
        for move in batch.movedSections {
            try check(input.source.indices.contains(move.from) && slots.indices.contains(move.to))
            try check(!removed[move.from] && slots[move.to] == -1)
            removed[move.from] = true; slots[move.to] = move.from
        }
        var origin = 0
        for destination in slots.indices {
            if slots[destination] == -1 {
                while origin < removed.count && removed[origin] { origin += 1 }
                try check(origin < removed.count)
                slots[destination] = origin; origin += 1
            }
            let old = input.source[slots[destination]], new = input.target[destination]
            try check(old.id == new.id && old.items.map(\.id) == new.items.map(\.id))
        }
        while origin < removed.count && removed[origin] { origin += 1 }
        try check(origin == removed.count)
    }

    // Replay mixed operations using old coordinates for origins and target
    // coordinates for destinations. Whole-section edits account for their own
    // new/deleted items; globally retained identities must still move explicitly.
    static func validateMixedBatch(_ batch: Batch, input: PackedDiffInput) throws {
        func check(_ condition: Bool) throws {
            if !condition { throw CollectionPlanValidationError("Invalid mixed replay") }
        }
        func valid(_ p: ItemLocation, _ sections: [PackedDiffInput.Section]) -> Bool {
            sections.indices.contains(p.section) && sections[p.section].items.indices.contains(p.item)
        }
        let oldCount = input.source.reduce(0) { $0 + $1.items.count }
        var removedSections = [Bool](repeating: false, count: input.source.count)
        var sectionSlots = [Int](repeating: -1, count: input.target.count)
        for s in batch.deletedSections {
            try check(input.source.indices.contains(s)); removedSections[s] = true
        }
        for s in batch.insertedSections {
            try check(input.target.indices.contains(s))
            try check(input.target[s].id >= input.source.count)
            sectionSlots[s] = -2
        }
        for move in batch.movedSections {
            try check(input.source.indices.contains(move.from) && sectionSlots.indices.contains(move.to))
            try check(!removedSections[move.from] && sectionSlots[move.to] == -1)
            removedSections[move.from] = true; sectionSlots[move.to] = move.from
        }
        var originSection = 0
        for s in sectionSlots.indices {
            if sectionSlots[s] == -1 {
                while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
                try check(originSection < removedSections.count)
                sectionSlots[s] = originSection; originSection += 1
            }
            if sectionSlots[s] >= 0 { try check(input.source[sectionSlots[s]].id == input.target[s].id) }
        }
        while originSection < removedSections.count && removedSections[originSection] { originSection += 1 }
        try check(originSection == removedSections.count)

        var removed = input.source.map { [Bool](repeating: false, count: $0.items.count) }
        var slots = input.target.map { [Int](repeating: -1, count: $0.items.count) }
        for p in batch.deletedItems {
            try check(valid(p, input.source) && !batch.deletedSections.contains(p.section))
            try check(!removed[p.section][p.item]); removed[p.section][p.item] = true
        }
        for p in batch.insertedItems {
            try check(valid(p, input.target) && !batch.insertedSections.contains(p.section))
            try check(slots[p.section][p.item] == -1 && input.target[p.section].items[p.item].id >= oldCount)
            slots[p.section][p.item] = input.target[p.section].items[p.item].id
        }
        for move in batch.movedItems {
            try check(valid(move.from, input.source) && valid(move.to, input.target))
            try check(!removed[move.from.section][move.from.item] && slots[move.to.section][move.to.item] == -1)
            removed[move.from.section][move.from.item] = true
            slots[move.to.section][move.to.item] = input.source[move.from.section].items[move.from.item].id
        }
        for targetSection in input.target.indices {
            let sourceSection = sectionSlots[targetSection]
            var origin = 0
            for item in slots[targetSection].indices {
                if slots[targetSection][item] == -1 {
                    if sourceSection == -2 {
                        let id = input.target[targetSection].items[item].id
                        try check(id >= oldCount)
                        slots[targetSection][item] = id
                    } else {
                        while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                        try check(origin < removed[sourceSection].count)
                        slots[targetSection][item] = input.source[sourceSection].items[origin].id
                        origin += 1
                    }
                }
                try check(slots[targetSection][item] == input.target[targetSection].items[item].id)
            }
            if sourceSection >= 0 {
                while origin < removed[sourceSection].count && removed[sourceSection][origin] { origin += 1 }
                try check(origin == removed[sourceSection].count)
            }
        }
        // Contents are what the data source will expose to UIKit.
        try check(batch.contents.count == input.target.count)
        for (content, section) in zip(batch.contents, input.target) {
            try check(content.section == section.id && content.items == section.items.map(\.id))
        }
    }

}
