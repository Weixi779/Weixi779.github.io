// Created by weixi on 2026/11/09.
import Foundation

// A validated structural plan containing only Sendable values.
struct PackedStructuralPlan: Sendable {
    struct Contents: Sendable { let section: Int; let items: [Int] }
    struct Batch: Sendable {
        let contents: [Contents]
        let deletedSections: IndexSet
        let insertedSections: IndexSet
        let movedSections: [(from: Int, to: Int)]
        let deletedItems: [ItemLocation]
        let insertedItems: [ItemLocation]
        let movedItems: [(from: ItemLocation, to: ItemLocation)]
    }
    let changes: SectionedChanges
    let batches: [Batch]

    static func calculate(_ input: PackedDiffInput) throws -> Self {
        let changes = try input.calculate()
        if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty && changes.movedSections.isEmpty &&
           changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            // Inputs are already validated snapshots. No structural operation exists
            // to replay, so skip structural planning and replay.
            return Self(changes: changes, batches: [])
        }

        let batch = Batch(
            contents: input.target.map { Contents(section: $0.id, items: $0.items.map(\.id)) },
            deletedSections: changes.deletedSections,
            insertedSections: changes.insertedSections,
            movedSections: changes.movedSections,
            deletedItems: changes.deletedItems.filter { !changes.deletedSections.contains($0.section) },
            insertedItems: changes.insertedItems.filter { !changes.insertedSections.contains($0.section) },
            movedItems: changes.movedItems
        )
        if input.source.map(\.id) == input.target.map(\.id) {
            try validateItemBatch(batch, input: input)
        } else if changes.deletedSections.isEmpty && changes.insertedSections.isEmpty &&
                  changes.deletedItems.isEmpty && changes.insertedItems.isEmpty && changes.movedItems.isEmpty {
            try validateSectionReorder(batch, input: input)
        } else {
            try validateMixedBatch(batch, input: input)
        }
        return Self(changes: changes, batches: [batch])
    }

    func materialize<L>(from source: CollectionSnapshot<L>, to target: CollectionSnapshot<L>,
                        input: PackedDiffInput) -> CollectionUpdatePlan<L> {
        if batches.isEmpty {
            return CollectionUpdatePlan(batches: [], content: CollectionContentUpdates(
                from: source, to: target, updatedSections: changes.updatedSections,
                updatedItems: Set(changes.updatedItems)))
        }
        let oldItems = source.sections.flatMap(\.cells)
        var added: [AnyCellPresenter] = []
        for (encoded, section) in zip(input.target, target.sections) {
            for (item, presenter) in zip(encoded.items, section.cells) where item.id >= oldItems.count {
                precondition(item.id == oldItems.count + added.count)
                added.append(presenter)
            }
        }
        let batches = batches.map { batch in
            CollectionBatch<L>(sections: batch.contents.map { content in
                let original = content.section < source.sections.count
                    ? source.sections[content.section]
                    : target.sections[content.section - source.sections.count]
                return original.replacingCells(content.items.map {
                    $0 < oldItems.count ? oldItems[$0] : added[$0 - oldItems.count]
                })
            }, deletedSections: batch.deletedSections, insertedSections: batch.insertedSections,
               movedSections: batch.movedSections, deletedItems: batch.deletedItems,
               insertedItems: batch.insertedItems, movedItems: batch.movedItems)
        }
        return CollectionUpdatePlan(batches: batches,
            content: CollectionContentUpdates(from: source, to: target,
                updatedSections: changes.updatedSections, updatedItems: Set(changes.updatedItems)))
    }
}
