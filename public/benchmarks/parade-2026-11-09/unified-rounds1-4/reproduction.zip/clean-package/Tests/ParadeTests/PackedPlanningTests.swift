// Created by weixi on 2026/11/09.
import UIKit
import Testing
@testable import Parade

@MainActor
struct PackedPlanningTests {
    private struct Item: CellPresenter {
        let id: Int
        var revision: Int = 0
        func configure(_ cell: UICollectionViewCell) {}
    }
    private func snapshot(_ sections: [(Int, [Item])]) throws -> CollectionSnapshot<Int> {
        try CollectionSnapshot(sections.map {
            SectionSnapshot(id: $0.0, cells: $0.1.map(AnyCellPresenter.init), layout: 0)
        })
    }
    private func validate(_ old: CollectionSnapshot<Int>, _ new: CollectionSnapshot<Int>) throws -> SectionedChanges {
        let oldIndex = try CollectionPositions(old.sections, input: .source)
        let input = PackedDiffInput(from: old.sections, to: new.sections, sourcePositions: oldIndex)
        let changes = try input.calculate()
        // Replay every optimized result through the existing full validator,
        // even when the built-in planner would bypass an empty structure.
        _ = try CollectionUpdatePlan(from: old, to: new, changes: changes)
        let packed = try PackedStructuralPlan.calculate(input)
        for batch in packed.batches { try PackedStructuralPlan.validateMixedBatch(batch, input: input) }
        // The old independent staged planner above still verifies the same diff.
        // Its replay explicitly forbids mixed batches, so it cannot replay this executor format.
        var expected: [ItemLocation] = []
        for (s, section) in new.sections.enumerated() {
            for (i, item) in section.cells.enumerated() {
                if let prior = old.cellsById[item.id], prior != item { expected.append(ItemLocation(section: s,item: i)) }
            }
        }
        #expect(Set(changes.updatedItems) == Set(expected))
        return changes
    }
    @Test func allSmallPermutations() throws {
        func permutations(_ values: [Int], _ visit: ([Int]) throws -> Void) rethrows {
            if values.isEmpty { try visit([]); return }
            for i in values.indices {
                var rest = values; let first = rest.remove(at: i)
                try permutations(rest) { try visit([first] + $0) }
            }
        }
        for n in 0...7 {
            let source = try snapshot([(0, (0..<n).map { Item(id: $0) })])
            try permutations(Array(0..<n)) { order in
                let target = try snapshot([(0, order.map { Item(id: $0, revision: $0 % 2) })])
                let changes = try validate(source, target)
                var lengths = [Int](repeating: 1, count: order.count)
                for i in order.indices {
                    for j in 0..<i where order[j] < order[i] { lengths[i] = max(lengths[i], lengths[j] + 1) }
                }
                #expect(changes.movedItems.count == n - (lengths.max() ?? 0))
                _ = changes
            }
        }
    }
    @Test func crossSectionInsertionDeletionAndContent() throws {
        var state: UInt64 = 0x504152414445
        func next(_ limit: Int) -> Int {
            state = state &* 6364136223846793005 &+ 1
            return Int(state >> 32) % limit
        }
        let source = try snapshot((0..<4).map { s in (s, (s*10..<s*10+10).map { Item(id: $0) }) })
        for _ in 0..<200 {
            var ids = Array(0..<4)
            ids.remove(at: next(ids.count)); ids.append(4)
            for i in ids.indices.reversed() { ids.swapAt(i, next(i+1)) }
            var items = (0..<45).filter { $0 >= 40 || next(5) != 0 }
            for i in items.indices.reversed() { items.swapAt(i, next(i+1)) }
            var groups = [[Item]](repeating: [], count: ids.count)
            for id in items { groups[next(groups.count)].append(Item(id: id, revision: next(2))) }
            let target = try snapshot(Array(zip(ids,groups)))
            _ = try validate(source, target)
        }
    }
    @Test func stableSectionsMixedChanges() throws {
        var state: UInt64 = 1731
        func next(_ limit: Int) -> Int {
            state = state &* 6364136223846793005 &+ 1
            return Int(state >> 32) % limit
        }
        let source = try snapshot((0..<4).map { s in (s, (s*10..<s*10+10).map { Item(id: $0) }) })
        for _ in 0..<500 {
            var ids = (0..<45).filter { $0 >= 40 || next(5) != 0 }
            for i in ids.indices.reversed() { ids.swapAt(i, next(i+1)) }
            var groups = [[Item]](repeating: [], count: 4)
            for id in ids { groups[next(4)].append(Item(id: id, revision: next(2))) }
            _ = try validate(source, snapshot(Array(zip(0..<4,groups))))
        }
    }

    @Test func compactReplayRejectsMissingAndConflictingMoves() throws {
        let old = try snapshot([(0, [Item(id: 0), Item(id: 1), Item(id: 2)])])
        let new = try snapshot([(0, [Item(id: 1), Item(id: 2), Item(id: 0)])])
        let input = PackedDiffInput(from: old.sections, to: new.sections,
            sourcePositions: try CollectionPositions(old.sections, input: .source))
        let good = try PackedStructuralPlan.calculate(input).batches[0]
        try PackedStructuralPlan.validateItemBatch(good, input: input)
        for moves in [[], good.movedItems + good.movedItems,
                      [(from: ItemLocation(section: 9, item: 0), to: ItemLocation(section: 0, item: 2))]] {
            let bad = PackedStructuralPlan.Batch(contents: good.contents, deletedSections: [],
                insertedSections: [], movedSections: [], deletedItems: [], insertedItems: [], movedItems: moves)
            #expect(throws: CollectionPlanValidationError.self) {
                try PackedStructuralPlan.validateItemBatch(bad, input: input)
            }
        }
    }

    @Test func sectionReorderUsesCompactReplay() throws {
        let source = try snapshot((0..<5).map { s in (s, (s*4..<s*4+4).map { Item(id: $0) }) })
        func permutations(_ ids: [Int], prefix: [Int] = []) throws {
            if ids.isEmpty {
                _ = try validate(source, snapshot(prefix.map { s in (s, (s*4..<s*4+4).map { Item(id: $0, revision: 1) }) }))
                return
            }
            for i in ids.indices {
                var rest = ids; let first = rest.remove(at: i)
                try permutations(rest, prefix: prefix + [first])
            }
        }
        try permutations(Array(0..<5))
    }

}
