// Created by weixi on 2026/09/23.

import Foundation
import Parade
import Testing

@MainActor
@Suite("Section instance reconciliation", .timeLimit(.minutes(1)))
struct SectionStoreTests {
    @Test("Queries use accepted or target membership and preserve type order")
    func typedQueries() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a"), definition("b"), definition("c")])
        let original: Controller<Regular>? = store.controller(for: "a")
        let a = try #require(original)
        try await store.reconcile([
            definition("c"),
            SectionDefinition(id: "a", input: "replacement", make: {
                Controller<Featured>("a", value: $0)
            }, update: { $0.value = $1 }),
            definition("new"),
        ]) { change in
            let query: any SectionControllerQuery<CompositionalSectionLayout> = change
            #expect(query.controller(for: "a", as: Controller<Regular>.self) == nil)
            #expect(query.controller(for: "a", as: Controller<Featured>.self)?.value == "replacement")
            #expect(query.controller(for: "missing", as: Controller<Regular>.self) == nil)
            #expect(query.controllers(ofType: Controller<Regular>.self).map(\.id) == ["c", "new"])
            #expect(store.controller(for: "a", as: Controller<Regular>.self) === a)
            #expect(store.controller(for: "new", as: Controller<Regular>.self) == nil)
            #expect(store.controllers(ofType: Controller<Regular>.self).map(\.id) == ["a", "b", "c"])
        }
        let query: any SectionControllerQuery<CompositionalSectionLayout> = store
        let replacement: Controller<Featured>? = query.controller(for: "a")
        #expect(replacement != nil)
        #expect(query.controller(for: "a", as: Controller<Regular>.self) == nil)
        #expect(query.controller(for: "b", as: Controller<Regular>.self) == nil)
        #expect(query.controllers(ofType: Controller<Regular>.self).map(\.id) == ["c", "new"])
    }

    @Test("Input updates include only fresh survivors in target order")
    func inputUpdateClassification() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        let initial = try store.reconcile([definition("a"), definition("b"), definition("c"), definition("d")])
        #expect(initial.inputUpdated.isEmpty)
        let retainingB = try #require(store.retainingDefinitions.first { $0.id == AnyHashable("b") })
        let change = try store.reconcile([
            definition("d"), retainingB, definition("new"), definition("a"),
            SectionDefinition(id: "c", input: 42, make: {
                Controller<Regular>("c", value: String($0))
            }, update: { $0.value = String($1) }),
        ])
        #expect(ids(change.retained) == ["d", "b", "a"])
        #expect(ids(change.inputUpdated) == ["d", "a"])
        #expect(ids(change.removed) == ["c"])
        let reordered = try store.reconcile(Array(store.retainingDefinitions.reversed()))
        #expect(reordered.inputUpdated.isEmpty)
        let empty = try store.reconcile([])
        #expect(empty.inputUpdated.isEmpty)
    }

    @Test("Input update facts do not persist across failed submissions")
    func inputUpdateRetry() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "old")])
        await #expect(throws: Rejection.failed) {
            try await store.reconcile([definition("a", value: "pending")]) { change in
                #expect(ids(change.inputUpdated) == ["a"])
                throw Rejection.failed
            }
        }
        let retainingRetry = try store.reconcile(store.retainingDefinitions)
        #expect(retainingRetry.inputUpdated.isEmpty)
        #expect(store.controller(for: "a", as: Controller<Regular>.self)?.value == "pending")
        let freshRetry = try store.reconcile([definition("a", value: "pending")])
        #expect(ids(freshRetry.inputUpdated) == ["a"])
    }

    @Test("Retaining definitions reorder and remove instances without replaying inputs, then accept typed updates")
    func retainingDefinitionsPreserveStateAndType() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "server"), definition("b", value: "second")])
        let a = try #require(store.controllers.first as? Controller<Regular>)
        let b = try #require(store.controllers.last as? Controller<Regular>)
        a.value = "local"
        let reversed = Array(store.retainingDefinitions.reversed())
        try store.reconcile(reversed)
        #expect(store.controllers.first === b)
        #expect(store.controllers.last === a)
        #expect(a.value == "local")

        try store.reconcile(store.retainingDefinitions.filter { $0.id == AnyHashable("a") })
        #expect(store.controllers.first === a)
        #expect(a.value == "local")
        try store.reconcile([definition("a", value: "fresh")])
        #expect(store.controllers.first === a)
        #expect(a.value == "fresh")
    }

    @Test("Rejected retaining compositions preserve membership and local state")
    func failedRetainingComposition() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "server"), definition("b", value: "second")])
        let a = try #require(store.controllers.first as? Controller<Regular>)
        a.value = "local"
        enum Failure: Error { case rejected }
        await #expect(throws: Failure.self) {
            try await store.reconcile(Array(store.retainingDefinitions.reversed())) { _ in
                throw Failure.rejected
            }
        }
        #expect(store.ids == [AnyHashable("a"), AnyHashable("b")])
        #expect(store.controllers.first === a)
        #expect(a.value == "local")
    }

    @Test("Even an empty composition reaches the caller's submission boundary")
    func emptyComposition() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        var submissions = 0
        let change = try await store.reconcile([]) { change in
            submissions += 1
            #expect(change.controllers.isEmpty)
        }

        #expect(submissions == 1)
        #expect(store.ids.isEmpty)
        #expect(store.controllers.isEmpty)
        #expect(change.controllers.isEmpty)
        #expect(change.retained.isEmpty)
        #expect(change.removed.isEmpty)
        #expect(!change.hasStructuralChanges)
    }

    @Test("Definitions are lazy and creation does not also run the updater")
    func lazyCreation() throws {
        var creations = 0
        let definition = SectionDefinition<CompositionalSectionLayout>(id: "a", input: "initial", make: {
            creations += 1
            return Controller<Regular>("a", value: $0)
        }, update: { _, _ in
            Issue.record("A new instance already received its input through make")
        })
        #expect(definition.id == AnyHashable("a"))
        #expect(creations == 0)

        let store = SectionStore<CompositionalSectionLayout>()
        let change = try store.reconcile([definition])
        let section = try #require(store.controllers.first as? Controller<Regular>)
        #expect(creations == 1)
        #expect(section.value == "initial")
        #expect(!section.updateContext.isAttached)
        #expect(change.hasStructuralChanges)
        #expect(change.retained.isEmpty)
        #expect(change.removed.isEmpty)
        #expect(change.controllers.first === section)
    }

    @Test("Reused instances keep local state and receive the current update closure")
    func retainedState() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "first")])
        let section = try #require(store.controllers.first as? Controller<Regular>)
        section.isExpanded = true

        let change = try store.reconcile([
            SectionDefinition<CompositionalSectionLayout>(id: "a", input: "second", make: {
                Issue.record("Matching instances must not be reconstructed")
                return Controller<Regular>("a", value: $0)
            }, update: { $0.value = "current closure: \($1)" }),
        ])

        #expect(store.controllers.first === section)
        #expect(change.retained.first === section)
        #expect(section.value == "current closure: second")
        #expect(section.isExpanded)
        #expect(!change.hasStructuralChanges)
    }

    @Test("Repeated input still reaches state that changed locally")
    func repeatedInput() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "server")])
        let section = try #require(store.controllers.first as? Controller<Regular>)
        section.value = "local edit"

        var submissions = 0
        let change = try await store.reconcile([definition("a", value: "server")]) { change in
            submissions += 1
            #expect(change.retained.first === section)
            #expect(section.value == "server")
        }

        #expect(submissions == 1)
        #expect(section.value == "server")
        #expect(change.retained.first === section)
        #expect(!change.hasStructuralChanges)
    }

    @Test("The same input type may feed different concrete controllers")
    func heterogeneousControllers() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([
            definition("regular", value: "one"),
            SectionDefinition<CompositionalSectionLayout>(id: "featured", input: "two", make: {
                Controller<Featured>("featured", value: $0)
            }, update: { $0.value = $1 }),
        ])
        let regular = try #require(store.controllers.first as? Controller<Regular>)
        let featured = try #require(store.controllers.last as? Controller<Featured>)

        let change = try store.reconcile([
            SectionDefinition<CompositionalSectionLayout>(id: "featured", input: "updated", make: {
                Controller<Featured>("featured", value: $0)
            }, update: { $0.value = $1 }),
            definition("regular", value: "also updated"),
        ])

        #expect(store.ids == [AnyHashable("featured"), AnyHashable("regular")])
        #expect(change.retained.count == 2)
        #expect(change.retained.first === featured)
        #expect(change.retained.last === regular)
        #expect(regular.value == "also updated")
        #expect(featured.value == "updated")
    }

    @Test("Changing controller type replaces the instance under the same ID")
    func controllerTypeReplacement() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a")])
        let previous = try #require(store.controllers.first)

        let change = try store.reconcile([
            SectionDefinition<CompositionalSectionLayout>(id: "a", input: "replacement", make: {
                Controller<Featured>("a", value: $0)
            }, update: { _, _ in Issue.record("A replacement must be created, not updated") }),
        ])

        #expect(change.hasStructuralChanges)
        #expect(change.retained.isEmpty)
        #expect(change.removed.count == 1)
        #expect(change.removed.first === previous)
        #expect(store.controllers.first is Controller<Featured>)
        #expect(store.controllers.first !== previous)
        #expect(store.ids == [AnyHashable("a")])
    }

    @Test("Changing input type replaces the association even with the same controller type")
    func inputTypeReplacement() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a")])
        let previous = try #require(store.controllers.first)

        let change = try store.reconcile([
            SectionDefinition<CompositionalSectionLayout>(id: "a", input: 42, make: {
                Controller<Regular>("a", value: String($0))
            }, update: { _, _ in Issue.record("A different Input establishes a new association") }),
        ])

        #expect(change.hasStructuralChanges)
        #expect(change.retained.isEmpty)
        #expect(change.removed.first === previous)
        #expect(store.controllers.first !== previous)
        #expect((store.controllers.first as? Controller<Regular>)?.value == "42")
    }

    @Test("Changes preserve target order for survivors and previous order for removals", arguments: [
        MembershipCase(target: ["a", "b", "c"], retained: ["a", "b", "c"], removed: [], structural: false),
        MembershipCase(target: ["c", "b", "a"], retained: ["c", "b", "a"], removed: [], structural: true),
        MembershipCase(target: ["c", "new", "a"], retained: ["c", "a"], removed: ["b"], structural: true),
        MembershipCase(target: ["new", "b"], retained: ["b"], removed: ["a", "c"], structural: true),
        MembershipCase(target: [], retained: [], removed: ["a", "b", "c"], structural: true),
    ])
    func membership(_ scenario: MembershipCase) throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a"), definition("b"), definition("c")])
        let previous = Dictionary(uniqueKeysWithValues: zip(store.ids, store.controllers))

        let change = try store.reconcile(scenario.target.map { definition($0) })

        #expect(store.ids == scenario.target.map(AnyHashable.init))
        #expect(ids(change.controllers) == scenario.target)
        #expect(ids(change.retained) == scenario.retained)
        #expect(ids(change.removed) == scenario.removed)
        #expect(change.hasStructuralChanges == scenario.structural)
        for retained in change.retained {
            #expect(retained === previous[AnyHashable(retained.id)])
        }
    }

    @Test("Duplicate IDs reject the entire input before any side effect", arguments: [false, true])
    func duplicateIds(useAsync: Bool) async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "accepted")])
        let section = try #require(store.controllers.first as? Controller<Regular>)
        let watched: (String) -> SectionDefinition<CompositionalSectionLayout> = { id in
            SectionDefinition<CompositionalSectionLayout>(id: id, input: "rejected", make: {
                Issue.record("Validation must finish before creating any instance")
                return Controller<Regular>(id, value: $0)
            }, update: { _, _ in Issue.record("Validation must finish before updating any instance") })
        }
        // Both an insertion and a survivor precede the duplicate at the end.
        let definitions = [watched("new"), watched("a"), watched("duplicate"), watched("duplicate")]

        await #expect(throws: CollectionUpdateError.duplicateSectionId("duplicate")) {
            if useAsync {
                try await store.reconcile(definitions) { _ in Issue.record("Invalid membership must not be submitted") }
            } else {
                try store.reconcile(definitions)
            }
        }

        #expect(store.ids == [AnyHashable("a")])
        #expect(store.controllers.first === section)
        #expect(section.value == "accepted")
        try store.reconcile([definition("a", value: "valid retry")])
        #expect(section.value == "valid retry")
    }

    @Test("A removed identity gets a fresh instance when it returns")
    func reinsertion() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a")])
        let previous = try #require(store.controllers.first as? Controller<Regular>)
        previous.isExpanded = true
        try store.reconcile([])
        let change = try store.reconcile([definition("a")])
        let replacement = try #require(store.controllers.first as? Controller<Regular>)

        #expect(replacement !== previous)
        #expect(!replacement.isExpanded)
        #expect(change.retained.isEmpty)
        #expect(change.removed.isEmpty)
        #expect(change.hasStructuralChanges)
    }

    @Test("Store instances are independent even when they share definitions")
    func independentStores() throws {
        let first = SectionStore<CompositionalSectionLayout>()
        let second = SectionStore<CompositionalSectionLayout>()
        let definitions = [definition("a")]
        try first.reconcile(definitions)
        try second.reconcile(definitions)
        let a = try #require(first.controllers.first as? Controller<Regular>)
        let b = try #require(second.controllers.first as? Controller<Regular>)
        a.isExpanded = true

        #expect(a !== b)
        #expect(!b.isExpanded)
    }

    @Test("Inputs and closure captures are released after creation and reuse", arguments: [false, true])
    func releasesDefinitions(reuse: Bool) throws {
        let store = SectionStore<CompositionalSectionLayout>()
        if reuse {
            try store.reconcile([
                SectionDefinition<CompositionalSectionLayout>(id: "a", input: Reference(), make: { _ in
                    Controller<Regular>("a", value: "initial")
                }, update: { _, _ in }),
            ])
        }
        let input = WeakReference()
        let factoryCapture = WeakReference()
        let updateCapture = WeakReference()
        do {
            let model = Reference()
            let factory = Reference()
            let updater = Reference()
            input.value = model
            factoryCapture.value = factory
            updateCapture.value = updater
            try store.reconcile([
                SectionDefinition<CompositionalSectionLayout>(id: "a", input: model, make: { model in
                    Controller<Regular>("a", value: factory.value + model.value)
                }, update: { section, model in
                    section.value = updater.value + model.value
                }),
            ])
        }

        #expect(input.value == nil)
        #expect(factoryCapture.value == nil)
        #expect(updateCapture.value == nil)
        #expect(store.controllers.count == 1)
    }

    @Test("A change retains removed controllers only for the lifetime of the result")
    func removalLifetime() throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a")])
        let removed = try WeakReference(#require(store.controllers.first as? Controller<Regular>))
        do {
            let change = try store.reconcile([])
            #expect(store.controllers.isEmpty)
            #expect(removed.value != nil)
            #expect(change.removed.first === removed.value)
        }
        #expect(removed.value == nil)
    }

    @Test("Releasing the store releases its remaining instances")
    func storeLifetime() throws {
        let reference = WeakReference()
        do {
            let store = SectionStore<CompositionalSectionLayout>()
            try store.reconcile([definition("a")])
            reference.value = try #require(store.controllers.first as? Controller<Regular>)
            #expect(reference.value != nil)
        }
        #expect(reference.value == nil)
    }

    @Test("Suspended submission keeps accepted membership until completion")
    func suspendedAcceptance() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "old"), definition("b")])
        let a = try #require(store.controllers.first as? Controller<Regular>)
        let gate = SubmissionGate()
        let submission = Task {
            try await store.reconcile([definition("new"), definition("a", value: "pending")]) { change in
                #expect(ids(change.controllers) == ["new", "a"])
                #expect(ids(change.removed) == ["b"])
                let pending: Controller<Regular>? = change.controller(for: "new")
                #expect(pending != nil)
                #expect(ids(change.inputUpdated) == ["a"])
                await gate.pause()
                #expect(change.controller(for: "new", as: Controller<Regular>.self) === pending)
            }
        }
        await gate.waitUntilStarted()
        #expect(store.ids == [AnyHashable("a"), AnyHashable("b")])
        #expect(store.controllers.first === a)
        #expect(a.value == "pending")
        #expect(store.controller(for: "new", as: Controller<Regular>.self) == nil)
        #expect(store.controller(for: "a", as: Controller<Regular>.self) === a)
        gate.resume()
        let change = try await submission.value

        #expect(store.ids == [AnyHashable("new"), AnyHashable("a")])
        #expect(store.controllers.last === a)
        #expect(change.retained.first === a)
    }

    @Test("Rejected structure preserves membership, not input mutations, and can be retried")
    func rejectedSubmission() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        try store.reconcile([definition("a", value: "old"), definition("b")])
        let a = try #require(store.controllers.first as? Controller<Regular>)
        let b = try #require(store.controllers.last)
        let rejected = WeakReference()

        await #expect(throws: Rejection.failed) {
            try await store.reconcile([definition("a", value: "pending"), definition("new")]) { change in
                rejected.value = change.controllers.last
                throw Rejection.failed
            }
        }

        #expect(store.ids == [AnyHashable("a"), AnyHashable("b")])
        #expect(store.controllers.first === a)
        #expect(store.controllers.last === b)
        #expect(a.value == "pending")
        #expect(rejected.value == nil)

        let retry = try await store.reconcile([definition("a", value: "retry"), definition("new")]) { change in
            #expect(change.retained.first === a)
            #expect(change.removed.first === b)
        }
        #expect(retry.hasStructuralChanges)
        #expect(store.ids == [AnyHashable("a"), AnyHashable("new")])
        #expect(a.value == "retry")
    }

    @Test("Cancellation thrown by the submitter rejects membership and releases candidates")
    func cancelledSubmission() async throws {
        let store = SectionStore<CompositionalSectionLayout>()
        let rejected = WeakReference()
        await #expect(throws: CancellationError.self) {
            try await store.reconcile([definition("a")]) { change in
                rejected.value = change.controllers.first
                throw CancellationError()
            }
        }
        #expect(store.ids.isEmpty)
        #expect(rejected.value == nil)
        try await store.reconcile([definition("a")]) { _ in }
        #expect(store.ids == [AnyHashable("a")])
    }

    private func definition(_ id: String, value: String = "value") -> SectionDefinition<CompositionalSectionLayout> {
        SectionDefinition<CompositionalSectionLayout>(id: id, input: value, make: {
            Controller<Regular>(id, value: $0)
        }, update: { $0.value = $1 })
    }

    private func ids(_ controllers: [any SectionController<CompositionalSectionLayout>]) -> [String] {
        controllers.map { String(describing: $0.id) }
    }
}

struct MembershipCase {
    let target: [String]
    let retained: [String]
    let removed: [String]
    let structural: Bool
}

private enum Regular {}
private enum Featured {}
private enum Rejection: Error { case failed }

@MainActor
private final class Controller<Kind>: SectionController {
    let id: String
    let updateContext = SectionUpdateContext()
    var value: String
    var isExpanded = false

    init(_ id: String, value: String) {
        self.id = id
        self.value = value
    }

    func captureContent() -> LayoutContent<CompositionalSectionLayout> {
        Issue.record("SectionStore<CompositionalSectionLayout> must not capture or submit a presentation")
        return testSectionContent(cells: [])
    }
}

private final class Reference {
    let value = "reference"
}

private final class WeakReference {
    weak var value: AnyObject?
    init(_ value: AnyObject? = nil) {
        self.value = value
    }
}

@MainActor
private final class SubmissionGate {
    private let started = AsyncStream<Void>.makeStream()
    private var continuation: CheckedContinuation<Void, Never>?

    func pause() async {
        await withCheckedContinuation {
            continuation = $0
            started.continuation.yield(())
            started.continuation.finish()
        }
    }

    func waitUntilStarted() async {
        for await _ in started.stream {
            return
        }
    }

    func resume() {
        continuation?.resume()
        continuation = nil
    }
}
