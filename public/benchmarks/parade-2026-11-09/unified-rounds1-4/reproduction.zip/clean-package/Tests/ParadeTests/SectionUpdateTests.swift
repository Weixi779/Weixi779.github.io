// Created by weixi on 2026/09/21.

import Testing
import UIKit
@testable import Parade

@MainActor
@Suite("Section-owned presentation updates")
struct SectionUpdateTests {
    @Test("Update descriptions are inert and capture fresh content on every apply", arguments: [false, true])
    func deferredCapture(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: [1])
        var captures = 0
        section.onCapture = { captures += 1 }
        let composition = fixture.owner.compose([section])
        let update = fixture.owner.update([section])
        #expect(captures == 0)
        #expect(!fixture.owner.isApplying)
        #expect(!section.updateContext.isAttached)

        section.items = [2]
        try await composition.apply(animated: false)
        #expect(captures == 1)
        #expect(fixture.owner.indexPath(for: 1) == nil)
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 0))

        section.items = [3]
        try await update.apply(animated: false)
        section.items = [4]
        try await update.apply(animated: false)
        #expect(captures == 3)
        #expect(fixture.owner.indexPath(for: 3) == nil)
        #expect(fixture.owner.indexPath(for: 4) == IndexPath(item: 0, section: 0))
        #expect(fixture.owner.appliedRevision == 3)
    }

    @Test("Chained selections accumulate once per instance without changing another description")
    func independentSelections() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        var captures = [0, 0]
        a.onCapture = { captures[0] += 1 }
        b.onCapture = { captures[1] += 1 }
        a.items = [3]
        b.items = [4]
        let base = fixture.owner.update([a, a])
        let extended = base.updating([b, a]).updating([b])
        #expect(captures == [0, 0])

        try await base.apply(animated: false)
        #expect(captures == [1, 0])
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 1))
        #expect(fixture.owner.indexPath(for: 4) == nil)
        try await extended.apply(animated: false)
        #expect(captures == [2, 1])
        #expect(fixture.owner.indexPath(for: 4) == IndexPath(item: 0, section: 1))
    }

    @Test("Composition and selected content transfer a cell to a newcomer in one submission",
          arguments: [false, true], [CollectionUpdateMode.diff, .reload])
    func combinedTransfer(native: Bool, mode: CollectionUpdateMode) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1, 2])
        let b = Section("b", items: [3])
        let newcomer = Section("new", items: [1])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        var receipts = 0
        fixture.owner.onDidApply = { _ in receipts += 1 }
        var captures = 0
        a.onCapture = { captures += 1 }
        a.items = [2]
        a.height = 80
        b.items = [3, 3] // An unselected survivor keeps its accepted, valid content.
        try await fixture.owner.compose([b, newcomer, a])
            .updating([a, newcomer, a]).apply(animated: false, mode: mode)

        #expect(captures == 1)
        #expect(receipts == 1)
        #expect(fixture.owner.appliedRevision == 2)
        #expect(fixture.owner.numberOfItems == 3)
        #expect(fixture.owner.indexPath(for: 1) == IndexPath(item: 0, section: 1))
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 2))
        #expect(fixture.view.layoutAttributesForItem(at: IndexPath(item: 0, section: 2))?.frame.height == 80)
        #expect(a.events == [.attach])
        #expect(b.events == [.attach])
        #expect(newcomer.events == [.attach])
    }

    @Test("Queued combined updates freeze selected content and preserve the latest unselected baseline",
          arguments: [false, true])
    func queuedCombinedUpdate(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1, 2])
        let b = Section("b", items: [3])
        let newcomer = Section("new", items: [1])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        b.items = [4]
        b.height = 80
        let first = Task { try await b.update(animated: false) }
        await gate.waitUntilStarted()

        a.items = [2]
        a.height = 96
        b.items = [9]
        b.height = 140
        try await withCheckedThrowingContinuation { (receipt: CheckedContinuation<Void, any Error>) in
            fixture.owner.compose([b, newcomer, a]).updating([a]).apply(animated: false) {
                receipt.resume(with: $0)
            }
            a.items = [8]
            a.height = 160
            newcomer.items = [7]
            gate.release()
        }
        try await first.value
        #expect(fixture.owner.appliedRevision == 3)
        #expect(fixture.owner.indexPath(for: 4) == IndexPath(item: 0, section: 0))
        #expect(fixture.owner.indexPath(for: 1) == IndexPath(item: 0, section: 1))
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 2))
        #expect(fixture.view.layoutAttributesForItem(at: IndexPath(item: 0, section: 0))?.frame.height == 80)
        #expect(fixture.view.layoutAttributesForItem(at: IndexPath(item: 0, section: 2))?.frame.height == 96)
    }

    @Test("Selections must be target instances, even when another instance has the same section ID")
    func selectionOutsideComposition() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let old = Section("a", items: [1])
        let replacement = Section("a", items: [2])
        try await fixture.owner.compose([old]).apply(animated: false)
        await #expect(throws: CollectionUpdateError.sectionNotInComposition("a")) {
            try await fixture.owner.compose([replacement]).updating([old]).apply(animated: false)
        }
        #expect(fixture.owner.appliedRevision == 1)
        #expect(old.updateContext.isAttached)
        #expect(replacement.events.isEmpty)
        #expect(fixture.owner.indexPath(for: 1) == IndexPath(item: 0, section: 0))
        try await fixture.owner.compose([replacement]).updating([replacement]).apply(animated: false)
        #expect(!old.updateContext.isAttached)
        #expect(replacement.updateContext.isAttached)
    }

    @Test("An invalid combined target changes neither membership nor content and can be retried",
          arguments: [false, true])
    func rejectedCombinedUpdate(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let newcomer = Section("new", items: [2])
        try await fixture.owner.compose([a]).apply(animated: false)
        a.items = [2]
        let update = fixture.owner.compose([newcomer, a]).updating([a])
        await #expect(throws: CollectionUpdateError.duplicateCellId("2")) {
            try await update.apply(animated: false)
        }
        #expect(fixture.owner.appliedRevision == 1)
        #expect(fixture.owner.sectionIds == [AnyHashable("a")])
        #expect(fixture.owner.indexPath(for: 1) == IndexPath(item: 0, section: 0))
        #expect(a.events == [.attach])
        #expect(newcomer.events.isEmpty)
        #expect(!newcomer.updateContext.isAttached)

        newcomer.items = [3]
        try await update.apply(animated: false)
        #expect(newcomer.events == [.attach])
        #expect(fixture.owner.indexPath(for: 3) == IndexPath(item: 0, section: 0))
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 1))
    }

    @Test("Selected content diagnostics retain section positions in the complete composition")
    func combinedDiagnosticPositions() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2, 2])
        let reported = Signal()
        var diagnostics: [CollectionDiagnostic] = []
        fixture.owner.onDiagnostic = { diagnostics.append($0); reported.send() }
        await #expect(throws: CollectionUpdateError.duplicateCellId("2")) {
            try await fixture.owner.compose([a, b]).updating([b]).apply(animated: false)
        }
        await reported.wait()
        let diagnostic = try #require(diagnostics.first)
        #expect(diagnostic.locations == [.init(section: 1, item: 0), .init(section: 1, item: 1)])
        #expect(!a.updateContext.isAttached)
        #expect(!b.updateContext.isAttached)
    }

    @Test("Layout-only updates take effect without replacing equal cells", arguments: [false, true])
    func layoutOnly(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: [1])
        try await fixture.owner.compose([section]).apply(animated: false)
        let path = IndexPath(item: 0, section: 0)
        let cell = try #require(fixture.view.cellForItem(at: path))
        #expect(cell.frame.height == 44)
        section.height = 96
        try await section.update(animated: false)
        #expect(fixture.view.cellForItem(at: path) === cell)
        #expect(cell.frame.height == 96)
        #expect(fixture.owner.appliedRevision == 2)
    }

    @Test("Queued local updates preserve each other and use captured layout input", arguments: [false, true])
    func capturedUpdates(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        a.items = [1, 3]
        a.height = 80
        let first = Task { try await a.update(animated: false) }
        await gate.waitUntilStarted()
        a.height = 140
        b.items = [2, 4]
        let captured = Signal()
        b.onCapture = { captured.send() }
        let second = Task { try await b.update(animated: false) }
        await captured.wait()
        gate.release()
        try await first.value
        try await second.value
        #expect(fixture.owner.numberOfItems == 4)
        #expect(fixture.owner.indexPath(for: 3) == IndexPath(item: 1, section: 0))
        #expect(fixture.owner.indexPath(for: 4) == IndexPath(item: 1, section: 1))
        #expect(fixture.view.layoutAttributesForItem(at: IndexPath(item: 0, section: 0))?.frame.height == 80)
    }

    @Test("Reordering preserves accepted contents even when live state is invalid")
    func reorderUsesBaseline() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        a.height = 80
        let update = Task { try await a.update(animated: false) }
        await gate.waitUntilStarted()
        a.height = 140
        a.items = [1, 1]
        try await withCheckedThrowingContinuation { (receipt: CheckedContinuation<Void, any Error>) in
            fixture.owner.compose([b, a]).apply(animated: false) { receipt.resume(with: $0) }
            gate.release()
        }
        try await update.value
        #expect(fixture.owner.sectionIds == [AnyHashable("b"), AnyHashable("a")])
        #expect(fixture.view.layoutAttributesForItem(at: IndexPath(item: 0, section: 1))?.frame.height == 80)
    }

    @Test(
        "Reordering during initial attachment ignores unused invalid live contents",
        arguments: [false, true], [false, true]
    )
    func reorderDuringInitialAttachment(native: Bool, initialIsExecuting: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        let gate = Gate()
        fixture.source.gate = gate
        let first = Task {
            try await fixture.owner.compose(initialIsExecuting ? [a, b] : []).apply(animated: false)
        }
        await gate.waitUntilStarted()
        var initial: Result<Void, CollectionUpdateError>?
        let initialCompleted = Signal()
        if !initialIsExecuting {
            fixture.owner.compose([a, b]).apply(animated: false) {
                initial = $0
                initialCompleted.send()
            }
        }

        a.items = [1, 1]
        a.height = 96
        let result: Result<Void, CollectionUpdateError> = await withCheckedContinuation { receipt in
            fixture.owner.compose([b, a]).apply(animated: false) { receipt.resume(returning: $0) }
            gate.release()
        }
        try await first.value
        if !initialIsExecuting {
            await initialCompleted.wait()
            try #require(initial).get()
        }
        try result.get()

        #expect(fixture.owner.sectionIds == [AnyHashable("b"), AnyHashable("a")])
        #expect(fixture.owner.numberOfItems == 2)
        let path = IndexPath(item: 0, section: 1)
        #expect(fixture.owner.indexPath(for: 1) == path)
        #expect(fixture.view.layoutAttributesForItem(at: path)?.frame.height == 44)
        #expect(fixture.owner.appliedRevision == (initialIsExecuting ? 2 : 3))
    }

    @Test("Reattachment after a queued removal uses the submission's captured presentation", arguments: [false, true])
    func queuedReattachment(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: [1])
        try await fixture.owner.compose([section]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        let first = Task { try await section.update(animated: false) }
        await gate.waitUntilStarted()

        var removal: Result<Void, CollectionUpdateError>?
        fixture.owner.compose([]).apply(animated: false) { removal = $0 }
        section.items = [2]
        section.height = 96
        try await withCheckedThrowingContinuation { (receipt: CheckedContinuation<Void, any Error>) in
            fixture.owner.compose([section]).apply(animated: false) { receipt.resume(with: $0) }
            section.items = [3]
            section.height = 144
            gate.release()
        }
        try await first.value
        try #require(removal).get()

        let path = IndexPath(item: 0, section: 0)
        #expect(fixture.owner.indexPath(for: 1) == nil)
        #expect(fixture.owner.indexPath(for: 2) == path)
        #expect(fixture.owner.indexPath(for: 3) == nil)
        #expect(fixture.view.cellForItem(at: path)?.accessibilityLabel == "2")
        #expect(fixture.view.layoutAttributesForItem(at: path)?.frame.height == 96)
        #expect(section.updateContext.isAttached)
        #expect(fixture.owner.appliedRevision == 4)
    }

    @Test("An old instance cannot update a replacement with the same ID")
    func staleInstance() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let old = Section("a", items: [1])
        let replacement = Section("a", items: [2])
        try await fixture.owner.compose([old]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        let removal = Task { try await fixture.owner.compose([]).apply(animated: false) }
        await gate.waitUntilStarted()
        let captured = Signal()
        old.onCapture = { captured.send() }
        let lateUpdate = Task { try await old.update(animated: false) }
        await captured.wait()
        try await withCheckedThrowingContinuation { (receipt: CheckedContinuation<Void, any Error>) in
            fixture.owner.compose([replacement]).apply(animated: false) { receipt.resume(with: $0) }
            gate.release()
        }
        try await removal.value
        await #expect(throws: CollectionUpdateError.staleSectionInstance("a")) { try await lateUpdate.value }
        #expect(!old.updateContext.isAttached)
        #expect(replacement.updateContext.isAttached)
        #expect(fixture.owner.indexPath(for: 1) == nil)
        #expect(fixture.owner.indexPath(for: 2) == IndexPath(item: 0, section: 0))
    }

    @Test("Execution rejects a global ID conflict, settles its receipt, and continues")
    func globalConflict() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        a.items = [9]
        let first = Task { try await a.update(animated: false) }
        await gate.waitUntilStarted()
        b.items = [9]
        let captured = Signal()
        b.onCapture = { captured.send() }
        let second = Task { try await b.update(animated: false) }
        await captured.wait()
        gate.release()
        try await first.value
        await #expect(throws: CollectionUpdateError.duplicateCellId("9")) { try await second.value }
        b.items = [10]
        try await b.update(animated: false)
        #expect(fixture.owner.appliedRevision == 3)
        #expect(fixture.owner.indexPath(for: 9) == IndexPath(item: 0, section: 0))
        #expect(fixture.owner.indexPath(for: 10) == IndexPath(item: 0, section: 1))
    }

    @Test("Multiple sections transfer a cell atomically", arguments: [false, true])
    func transfer(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1, 2])
        let b = Section("b", items: [3])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        a.items = [2]
        b.items = [3, 1]
        try await fixture.owner.update([a, b]).apply(animated: false)
        #expect(fixture.owner.indexPath(for: 1) == IndexPath(item: 1, section: 1))
        #expect(fixture.owner.numberOfItems == 3)
    }

    @Test("An in-flight attachment reserves the section for one collection")
    func attachmentReservation() async throws {
        let first = Fixture()
        let second = Fixture()
        defer { first.close(); second.close() }
        let section = Section("a", items: [1])
        let gate = Gate()
        first.source.gate = gate
        let attachment = Task { try await first.owner.compose([section]).apply(animated: false) }
        await gate.waitUntilStarted()
        #expect(!section.updateContext.isAttached)
        await #expect(throws: CollectionUpdateError.sectionAlreadyAttached) {
            try await second.owner.compose([section]).apply(animated: false)
        }
        gate.release()
        try await attachment.value
        try await first.owner.compose([]).apply(animated: false)
        try await second.owner.compose([section]).apply(animated: false)
        #expect(section.updateContext.isAttached)
    }

    @Test("Structural stages retain layout with their section metadata")
    func stagedLayoutIdentity() throws {
        let a = Section("a", items: [1, 2])
        let b = Section("b", items: [3])
        let oldA = SectionSnapshot<CompositionalSectionLayout>(capturing: a)
        let oldB = SectionSnapshot<CompositionalSectionLayout>(capturing: b)
        let source = try CollectionSnapshot<CompositionalSectionLayout>([oldA, oldB])
        a.height = 90
        a.items = [2]
        b.items = [3, 1]
        let target = try CollectionSnapshot<CompositionalSectionLayout>([SectionSnapshot<CompositionalSectionLayout>(capturing: b), SectionSnapshot<CompositionalSectionLayout>(capturing: a)])
        let plan = try CollectionUpdatePlan<CompositionalSectionLayout>(from: source, to: target)
        for batch in plan.batches {
            for section in batch.sections {
                #expect(section.layout === source.sectionsById[section.id]?.layout)
            }
        }
        #expect(plan.content.hasLayoutUpdates)
    }

    @Test("Membership and collection visibility have separate lifecycles", arguments: [false, true])
    func lifecycle(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        #expect(a.events == [.attach])
        fixture.owner.isVisible = true
        fixture.owner.isVisible = true
        let events = a.events
        try await fixture.owner.compose([b, a]).apply(animated: false)
        try await a.update(animated: false)
        #expect(a.events == events)
        try await fixture.owner.compose([b]).apply(animated: false)
        #expect(a.events == events + [.visibility(false), .detach])
        fixture.owner.isVisible = false
        #expect(a.events == events + [.visibility(false), .detach])
        try await fixture.owner.compose([a, b]).apply(animated: false)
        #expect(a.events.suffix(1) == [.attach])
        #expect(a.attachmentStates == [true, false, true])
    }

    @Test("Visibility changes reach current members while attachment is pending", arguments: [false, true])
    func visibilityDuringAttachment(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([a]).apply(animated: false)
        #expect(a.events == [.attach, .visibility(true)])
        let gate = Gate()
        fixture.source.gate = gate
        let attachment = Task { try await fixture.owner.compose([a, b]).apply(animated: false) }
        await gate.waitUntilStarted()
        fixture.owner.isVisible = false
        #expect(a.events.last == .visibility(false))
        #expect(b.events.isEmpty)
        gate.release()
        try await attachment.value
        #expect(b.events == [.attach])
    }

    @Test("Rejected membership emits no lifecycle events; same-ID replacement does", arguments: [false, true])
    func replacementLifecycle(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let old = Section("a", items: [1])
        let replacement = Section("a", items: [2])
        let invalid = Section("invalid", items: [2])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([old]).apply(animated: false)
        await #expect(throws: CollectionUpdateError.duplicateCellId("2")) {
            try await fixture.owner.compose([replacement, invalid]).apply(animated: false)
        }
        #expect(old.events == [.attach, .visibility(true)])
        #expect(replacement.events.isEmpty)
        #expect(invalid.events.isEmpty)
        try await fixture.owner.compose([replacement]).apply(animated: false)
        #expect(old.events == [.attach, .visibility(true), .visibility(false), .detach])
        #expect(replacement.events == [.attach, .visibility(true)])
        #expect(old.attachmentStates == [true, false])
    }

    @Test("Reentrant visibility changes do not leave another member with stale state")
    func reentrantVisibility() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let sections = [Section("a", items: [1]), Section("b", items: [2])]
        try await fixture.owner.compose(sections).apply(animated: false)
        for section in sections {
            section.onVisibility = { [weak owner = fixture.owner] visible in
                if visible { owner?.isVisible = false }
            }
        }
        fixture.owner.isVisible = true
        #expect(!fixture.owner.isVisible)
        for section in sections {
            #expect(section.events == [.attach] || section.events == [.attach, .visibility(true), .visibility(false)])
        }
    }

    @Test("Attachment callbacks may enqueue updates and change collection visibility")
    func updateFromAttachment() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [2])
        var update: Task<Void, any Error>?
        a.onAttach = { [weak owner = fixture.owner, weak a] in
            owner?.isVisible = true
            #expect(a?.events == [.attach])
            update = Task {
                guard let a else { return }
                a.items = [3]
                try await a.update(animated: false)
            }
        }
        try await fixture.owner.compose([a, b]).apply(animated: false)
        try await #require(update).value
        #expect(a.events == [.attach, .visibility(true)])
        #expect(b.events == [.attach, .visibility(true)])
        #expect(fixture.owner.indexPath(for: 3) != nil)
    }

    @Test("Releasing an orchestrator ends retained sections' attachments", .timeLimit(.minutes(1)))
    func ownerRelease() async throws {
        let section = Section("a", items: [1])
        let frame = CGRect(x: 0, y: 0, width: 320, height: 640)
        let view = UICollectionView(frame: frame, collectionViewLayout: UICollectionViewLayout())
        let window = UIWindow(frame: frame)
        let controller = UIViewController()
        controller.view = view
        window.rootViewController = controller
        window.isHidden = false
        defer { window.isHidden = true }
        let detached = Signal()
        section.onDetach = { detached.send() }
        var owner: CollectionOrchestrator<CompositionalSectionLayout>? = CollectionOrchestrator<CompositionalSectionLayout>(collectionView: view)
        weak var weakOwner = owner
        owner?.isVisible = true
        try await owner?.compose([section]).apply(animated: false)
        #expect(section.sectionDisplayEvents == [true])
        owner = nil
        await detached.wait()
        #expect(weakOwner == nil)
        #expect(!section.updateContext.isAttached)
        #expect(section.events == [.attach, .visibility(true), .visibility(false), .detach])
        #expect(section.sectionDisplayEvents == [true, false])
    }

    @Test("Collection display reaches offscreen sections; section display follows scrolling", arguments: [false, true])
    func twoDisplayLevels(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let top = Section("top", items: [1])
        top.height = 2000
        let bottom = Section("bottom", items: [2])
        try await fixture.owner.compose([top, bottom]).apply(animated: false)
        #expect(top.sectionDisplayEvents.isEmpty)
        fixture.owner.isVisible = true
        #expect(top.sectionDisplayEvents == [true])
        #expect(bottom.events == [.attach, .visibility(true)])
        #expect(bottom.sectionDisplayEvents.isEmpty)

        fixture.view.contentOffset.y = 2000
        fixture.view.layoutIfNeeded()
        #expect(top.sectionDisplayEvents == [true, false])
        #expect(bottom.sectionDisplayEvents == [true])
        #expect(bottom.events == [.attach, .visibility(true)])
        fixture.owner.isVisible = false
        fixture.owner.isVisible = false
        #expect(bottom.sectionDisplayEvents == [true, false])
        fixture.owner.isVisible = true
        #expect(top.sectionDisplayEvents == [true, false])
        #expect(bottom.sectionDisplayEvents == [true, false, true])
    }

    @Test("A section enters on its first cell and exits on its last cell", arguments: [false, true])
    func firstAndLastCell(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: [1, 2])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([section]).apply(animated: false)
        let bridge = try #require((fixture.view.delegate as? CollectionLayoutDelegate)?.bridge)
        let firstPath = IndexPath(item: 0, section: 0)
        let lastPath = IndexPath(item: 1, section: 0)
        let first = try #require(fixture.view.cellForItem(at: firstPath))
        let last = try #require(fixture.view.cellForItem(at: lastPath))
        #expect(section.sectionDisplayEvents == [true])
        bridge.collectionView(fixture.view, didEndDisplaying: first, forItemAt: firstPath)
        #expect(section.sectionDisplayEvents == [true])
        bridge.collectionView(fixture.view, didEndDisplaying: last, forItemAt: lastPath)
        #expect(section.sectionDisplayEvents == [true, false])
        fixture.owner.isVisible = false
        fixture.owner.isVisible = true
        #expect(section.sectionDisplayEvents == [true, false])
        bridge.collectionView(fixture.view, willDisplay: first, forItemAt: firstPath)
        bridge.collectionView(fixture.view, willDisplay: last, forItemAt: lastPath)
        #expect(section.sectionDisplayEvents == [true, false, true])
    }

    @Test("Supplementary-only and mixed sections count supplementary display", arguments: [false, true], [false, true])
    func supplementaryDisplay(native: Bool, hasCells: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: hasCells ? [1] : [])
        section.hasHeader = true
        fixture.owner.isVisible = true
        try await fixture.owner.compose([section]).apply(animated: false)
        let path = IndexPath(item: 0, section: 0)
        let kind = UICollectionView.elementKindSectionHeader
        let bridge = try #require((fixture.view.delegate as? CollectionLayoutDelegate)?.bridge)
        let header = try #require(fixture.view.supplementaryView(forElementKind: kind, at: path))
        #expect(section.sectionDisplayEvents == [true])
        if hasCells {
            let cell = try #require(fixture.view.cellForItem(at: path))
            bridge.collectionView(fixture.view, didEndDisplaying: cell, forItemAt: path)
            #expect(section.sectionDisplayEvents == [true])
        }
        bridge.collectionView(fixture.view, didEndDisplayingSupplementaryView: header, forElementOfKind: kind, at: path)
        #expect(section.sectionDisplayEvents == [true, false])
        bridge.collectionView(fixture.view, willDisplaySupplementaryView: header, forElementKind: kind, at: path)
        #expect(section.sectionDisplayEvents == [true, false, true])
    }

    @Test("Updates settle section display once, including a cell transfer", arguments: [false, true])
    func displayAcrossUpdates(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let a = Section("a", items: [1])
        let b = Section("b", items: [])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([a, b]).apply(animated: false)
        try await fixture.owner.compose([b, a]).apply(animated: false)
        a.height = 96
        try await a.update(animated: false)
        try await a.update(animated: false, mode: .reload)
        #expect(a.sectionDisplayEvents == [true])
        #expect(b.sectionDisplayEvents.isEmpty)
        a.items = []
        b.items = [1]
        try await fixture.owner.update([a, b]).apply(animated: false)
        #expect(a.sectionDisplayEvents == [true, false])
        #expect(b.sectionDisplayEvents == [true])
    }

    @Test("Late view callbacks cannot end a new same-ID attachment", arguments: [false, true])
    func replacementDisplay(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let old = Section("a", items: [1])
        let replacement = Section("a", items: [2])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([old]).apply(animated: false)
        let path = IndexPath(item: 0, section: 0)
        let cell = try #require(fixture.view.cellForItem(at: path))
        let bridge = try #require((fixture.view.delegate as? CollectionLayoutDelegate)?.bridge)
        // Keep an old display cycle pending while UIKit ends its own cycle.
        bridge.collectionView(fixture.view, willDisplay: cell, forItemAt: path)
        try await fixture.owner.compose([replacement]).apply(animated: false)
        #expect(old.displayOrder == ["attach", "collection.begin", "section.begin", "section.end", "collection.end", "detach"])
        #expect(replacement.sectionDisplayEvents == [true])
        bridge.collectionView(fixture.view, didEndDisplaying: cell, forItemAt: path)
        #expect(replacement.sectionDisplayEvents == [true])
        try await fixture.owner.compose([]).apply(animated: false)
        #expect(replacement.sectionDisplayEvents == [true, false])
        try await fixture.owner.compose([old]).apply(animated: false)
        #expect(old.sectionDisplayEvents == [true, false, true])
    }

    @Test("Same-content replacement transfers display even when UIKit retains the cell", arguments: [false, true])
    func replacementWithoutDequeue(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let old = Section("a", items: [1])
        let replacement = Section("a", items: [1])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([old]).apply(animated: false)
        let path = IndexPath(item: 0, section: 0)
        let cell = try #require(fixture.view.cellForItem(at: path))
        try await fixture.owner.compose([replacement]).apply(animated: false)
        #expect(fixture.view.cellForItem(at: path) === cell)
        #expect(old.sectionDisplayEvents == [true, false])
        #expect(replacement.sectionDisplayEvents == [true])
        let bridge = try #require((fixture.view.delegate as? CollectionLayoutDelegate)?.bridge)
        bridge.collectionView(fixture.view, didEndDisplaying: cell, forItemAt: path)
        #expect(replacement.sectionDisplayEvents == [true, false])
    }

    @Test("A collection can hide during a section update", arguments: [false, true])
    func hideDuringUpdate(native: Bool) async throws {
        let fixture = Fixture(native: native)
        defer { fixture.close() }
        let section = Section("a", items: [1])
        fixture.owner.isVisible = true
        try await fixture.owner.compose([section]).apply(animated: false)
        let gate = Gate()
        fixture.source.gate = gate
        section.items = [2]
        let update = Task { try await section.update(animated: false) }
        await gate.waitUntilStarted()
        fixture.owner.isVisible = false
        #expect(section.sectionDisplayEvents == [true, false])
        gate.release()
        try await update.value
        #expect(section.sectionDisplayEvents == [true, false])
        fixture.owner.isVisible = true
        #expect(section.sectionDisplayEvents == [true, false, true])
    }

    @Test("Reentrant section callbacks keep collection and section display balanced")
    func reentrantSectionDisplay() async throws {
        let fixture = Fixture()
        defer { fixture.close() }
        let section = Section("a", items: [1])
        try await fixture.owner.compose([section]).apply(animated: false)
        section.onSectionDisplay = { [weak owner = fixture.owner, weak section] visible in
            if visible {
                owner?.isVisible = false
                #expect(section?.displayOrder.last == "section.begin")
            }
        }
        fixture.owner.isVisible = true
        #expect(section.displayOrder == ["attach", "collection.begin", "section.begin", "section.end", "collection.end"])
        #expect(!fixture.owner.isVisible)
    }

}

private struct Cell: CellPresenter {
    let id: Int
    func configure(_ cell: UICollectionViewCell) { cell.accessibilityLabel = String(id) }
}

private struct Header: SupplementaryPresenter {
    let id: String
    var elementKind: String { UICollectionView.elementKindSectionHeader }
    func configure(_ view: UICollectionReusableView) {}
}

private struct Content: SectionContent {
    let cells: [AnyCellPresenter]
    let height: CGFloat
    var supplementaryViews: [AnySupplementaryPresenter] = []

    var layout: CompositionalSectionLayout {
        CompositionalSectionLayout { _ in
            let size = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .absolute(height))
            let section = NSCollectionLayoutSection(group: .vertical(layoutSize: size, subitems: [NSCollectionLayoutItem(layoutSize: size)]))
            if !supplementaryViews.isEmpty {
                section.boundarySupplementaryItems = [NSCollectionLayoutBoundarySupplementaryItem(
                    layoutSize: size,
                    elementKind: UICollectionView.elementKindSectionHeader,
                    alignment: .top
                )]
            }
            return section
        }
    }
}

@MainActor
private final class Section: SectionController, SectionAttachmentObserving, CollectionDisplayObserving, SectionDisplayObserving {
    enum Event: Equatable {
        case attach, visibility(Bool), detach
    }

    let id: String
    let updateContext = SectionUpdateContext()
    var items: [Int]
    var height: CGFloat = 44
    var hasHeader = false
    var sectionDisplayEvents: [Bool] = []
    var displayOrder: [String] = []
    var onSectionDisplay: ((Bool) -> Void)?
    var onCapture: (() -> Void)?
    var onAttach: (() -> Void)?
    var onDetach: (() -> Void)?
    var onVisibility: ((Bool) -> Void)?
    var events: [Event] = []
    var attachmentStates: [Bool] = []

    init(_ id: String, items: [Int]) { self.id = id; self.items = items }

    func captureContent() -> Content {
        let result = Content(
            cells: items.map { AnyCellPresenter(Cell(id: $0)) }, height: height,
            supplementaryViews: hasHeader ? [AnySupplementaryPresenter(Header(id: id))] : []
        )
        onCapture?()
        return result
    }

    func didAttach() {
        events.append(.attach)
        displayOrder.append("attach")
        attachmentStates.append(updateContext.isAttached)
        onAttach?()
    }

    func didDetach() {
        events.append(.detach)
        displayOrder.append("detach")
        attachmentStates.append(updateContext.isAttached)
        onDetach?()
    }

    func sectionWillDisplay() {
        sectionDisplayEvents.append(true)
        displayOrder.append("section.begin")
        onSectionDisplay?(true)
    }

    func sectionDidEndDisplaying() {
        sectionDisplayEvents.append(false)
        displayOrder.append("section.end")
        onSectionDisplay?(false)
    }

    func collectionWillDisplay() {
        events.append(.visibility(true))
        displayOrder.append("collection.begin")
        onVisibility?(true)
    }

    func collectionDidEndDisplaying() {
        events.append(.visibility(false))
        displayOrder.append("collection.end")
        onVisibility?(false)
    }
}

@MainActor
private final class Signal {
    private var sent = false
    private var waiter: CheckedContinuation<Void, Never>?
    func send() { sent = true; waiter?.resume(); waiter = nil }
    func wait() async {
        if !sent { await withCheckedContinuation { waiter = $0 } }
    }
}

@MainActor
private final class Gate {
    private let started = Signal()
    private var receipt: CheckedContinuation<Void, Never>?
    func pause() async {
        await withCheckedContinuation { receipt = $0; started.send() }
    }
    func waitUntilStarted() async { await started.wait() }
    func release() { receipt?.resume(); receipt = nil }
}

@MainActor
private final class ControlledSource: CollectionDataSource {
    let base: any CollectionDataSource<CompositionalSectionLayout>
    var gate: Gate?
    init(_ base: any CollectionDataSource<CompositionalSectionLayout>) {
        self.base = base
    }
    var dataSource: any UICollectionViewDataSource { base.dataSource }
    var sectionIds: [AnyHashable] { base.sectionIds }
    var numberOfSections: Int { base.numberOfSections }
    var numberOfItems: Int { base.numberOfItems }
    var isEmpty: Bool { base.isEmpty }
    func sectionId(at index: Int) -> AnyHashable? { base.sectionId(at: index) }
    func sectionIndex(for id: AnyHashable) -> Int? { base.sectionIndex(for: id) }
    func indexPath(for id: AnyHashable) -> IndexPath? { base.indexPath(for: id) }
    func cellPresenter(at indexPath: IndexPath) -> AnyCellPresenter? { base.cellPresenter(at: indexPath) }
    func supplementaryPresenter(ofKind kind: String, at indexPath: IndexPath) -> AnySupplementaryPresenter? {
        base.supplementaryPresenter(ofKind: kind, at: indexPath)
    }
    func sectionSnapshot(at index: Int) -> SectionSnapshot<CompositionalSectionLayout>? {
        base.sectionSnapshot(at: index)
    }
    func apply(from source: CollectionSnapshot<CompositionalSectionLayout>, to target: CollectionSnapshot<CompositionalSectionLayout>, animated: Bool, mode: CollectionUpdateMode) async -> [CollectionDiagnostic] {
        if let gate { self.gate = nil; await gate.pause() }
        return await base.apply(from: source, to: target, animated: animated, mode: mode)
    }
}

@MainActor
private final class Fixture {
    let view: UICollectionView
    let owner: CollectionOrchestrator<CompositionalSectionLayout>
    let source: ControlledSource
    private let window: UIWindow

    init(native: Bool = false) {
        let frame = CGRect(x: 0, y: 0, width: 320, height: 640)
        let view = UICollectionView(frame: frame, collectionViewLayout: UICollectionViewLayout())
        self.view = view
        var controlled: ControlledSource!
        owner = CollectionOrchestrator<CompositionalSectionLayout>(collectionView: view) { view, views in
            let base: any CollectionDataSource<CompositionalSectionLayout> = native
                ? DiffableCollectionDataSource<CompositionalSectionLayout>(collectionView: view, views: views)
                : StagedCollectionDataSource<CompositionalSectionLayout>(collectionView: view, views: views)
            let source = ControlledSource(base)
            controlled = source
            return source
        }
        source = controlled
        window = UIWindow(frame: frame)
        let controller = UIViewController()
        controller.view = view
        window.rootViewController = controller
        window.isHidden = false
    }
    func close() { window.isHidden = true }
}
