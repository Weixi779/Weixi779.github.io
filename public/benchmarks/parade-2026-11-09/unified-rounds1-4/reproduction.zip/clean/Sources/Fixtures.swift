// Created by weixi on 2026/11/09.
import UIKit

struct UIItem: Equatable { let id: String; var revision: Int = 0 }
struct UIHeader { let id: Int }
struct UISection { let model: UIHeader; var elements: [UIItem] }
struct UIFixture { let name: String; let old: [UISection]; let new: [UISection]; let flat: Bool }
struct ScaleCase { let fixture: UIFixture; let changeCount: Int; let changeMode: String }
func nanos() -> UInt64 { DispatchTime.now().uptimeNanoseconds }

struct BenchRNG: RandomNumberGenerator {
    var state: UInt64
    mutating func next() -> UInt64 {
        state &+= 0x9e3779b97f4a7c15
        var z = state
        z = (z ^ (z >> 30)) &* 0xbf58476d1ce4e5b9
        z = (z ^ (z >> 27)) &* 0x94d049bb133111eb
        return z ^ (z >> 31)
    }
}

@MainActor final class BenchCell: UICollectionViewCell {
    static var configurations=0
    let label = UILabel()
    var renderedID = ""
    var renderedRevision = -1
    override init(frame: CGRect) {
        super.init(frame: frame)
        label.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        contentView.addSubview(label)
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); label.frame = contentView.bounds.insetBy(dx: 8, dy: 0) }
    func configure(_ item: UIItem) {
        Self.configurations += 1
        renderedID = item.id; renderedRevision = item.revision
        label.text = "\(item.id) · \(item.revision)"
    }
}

