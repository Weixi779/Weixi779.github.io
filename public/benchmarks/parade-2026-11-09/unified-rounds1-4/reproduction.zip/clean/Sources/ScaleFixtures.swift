// Created by weixi on 2026/11/09.
func generalFixtures(_ n:Int)->[ScaleCase] {
    let old=(0..<n).map { UIItem(id:"section-0:item-\($0)") }
    var result:[ScaleCase]=[]
    func add(_ name:String,_ values:[UIItem],_ count:Int,_ mode:String) {
        result.append(ScaleCase(fixture:UIFixture(name:name,old:[UISection(model:UIHeader(id:0),elements:old)],new:[UISection(model:UIHeader(id:0),elements:values)],flat:true),changeCount:count,changeMode:mode))
    }
    for (mode,k) in [("fixed5",5),("pct5",n/20),("pct25",n/4),("pct50",n/2)] {
        let indices=(0..<k).map { $0*n/k }
        let deletions=Set(indices.map { min(n-1,$0+1) })
        let extra=(n..<n+k).map { UIItem(id:"section-0:item-\($0)") }
        add("append-"+mode,old+extra,k,mode)
        add("delete-"+mode,old.enumerated().filter { !deletions.contains($0.offset) }.map(\.element),k,mode)
        var updated=old
        for i in indices { updated[i].revision += 1 }
        add("update-"+mode,updated,k,mode)
        var mixed=updated.enumerated().filter { !deletions.contains($0.offset) }.map(\.element)
        mixed.insert(contentsOf:extra,at:min(mixed.count,n/3))
        mixed=Array(mixed.dropFirst(k))+Array(mixed.prefix(k))
        add("mixed-"+mode,mixed,k,mode)
    }
    add("no-op",old,0,"none")
    add("rotate-left-1",Array(old.dropFirst())+Array(old.prefix(1)),1,"reorder")
    add("rotate-right-1",Array(old.suffix(1))+Array(old.dropLast()),1,"reorder")
    var rng=BenchRNG(state:0x504152414445 ^ UInt64(n));var shuffled=old;shuffled.shuffle(using:&rng)
    add("shuffle",shuffled,n,"reorder")
    let sections=(0..<10).map { s in UISection(model:UIHeader(id:s),elements:Array(old[s*(n/10)..<(s+1)*(n/10)])) }
    let rotated=Array(sections.dropFirst())+Array(sections.prefix(1))
    result.append(ScaleCase(fixture:UIFixture(name:"section-rotate-left",old:sections,new:rotated,flat:false),changeCount:1,changeMode:"section"))
    var crossed=sections
    let k=n/20
    let moved=crossed[0].elements.prefix(k).map { UIItem(id:$0.id,revision:$0.revision+1) }
    crossed[0].elements.removeFirst(k);crossed[1].elements.insert(contentsOf:moved,at:0)
    result.append(ScaleCase(fixture:UIFixture(name:"cross-section-update-pct5",old:sections,new:crossed,flat:false),changeCount:k,changeMode:"section"))
    return result
}

func sectionFixtures(_ n: Int) -> [ScaleCase] {
    let values = (0..<n).map { UIItem(id: "item-\($0)") }
    let old = (0..<10).map { s in UISection(model: UIHeader(id:s), elements: Array(values[s*(n/10)..<(s+1)*(n/10)])) }
    var result: [ScaleCase] = []
    func add(_ name: String, _ source: [UISection], _ target: [UISection], _ changes: Int) {
        result.append(ScaleCase(fixture: UIFixture(name:name, old:source, new:target, flat:false),changeCount:changes,changeMode:"mixed-section"))
    }
    func changed(_ items: [UIItem]) -> [UIItem] { items.map { UIItem(id:$0.id,revision:$0.revision+1) } }
    for k in [1,n/20] {
        var target = old
        let moving = changed(Array(target[0].elements.prefix(k)))
        target[0].elements.removeFirst(k)
        target.insert(UISection(model:UIHeader(id:10),elements:moving),at:0)
        add(k == 1 ? "new-section-move1" : "new-section-move5pct",old,target,k)
    }
    var deleted = old
    let outgoing = changed(deleted.removeFirst().elements)
    deleted[0].elements.insert(contentsOf:outgoing,at:0)
    add("delete-section-transfer",old,deleted,outgoing.count)
    var replaced = old
    replaced[0] = UISection(model:UIHeader(id:10),elements:changed(replaced[0].elements))
    add("replace-section",old,replaced,n/10)
    var crossed = old
    let moved = changed(Array(crossed[0].elements.prefix(n/20)))
    crossed[0].elements.removeFirst(n/20);crossed[1].elements.insert(contentsOf:moved,at:0)
    add("existing-cross-update",old,crossed,moved.count)
    let reordered = Array(crossed.dropFirst()) + Array(crossed.prefix(1))
    add("section-reorder-transfer",old,reordered,moved.count)
    var churn = old
    let removed = churn.removeFirst()
    let half = n/20
    let fromSecond = Array(churn[0].elements.prefix(half))
    churn[0].elements.removeFirst(half)
    churn[1].elements.append(contentsOf:changed(Array(removed.elements.dropFirst(half))))
    churn.insert(UISection(model:UIHeader(id:10),elements:changed(Array(removed.elements.prefix(half))+fromSecond)),at:2)
    churn = Array(churn.dropFirst(3)) + Array(churn.prefix(3))
    add("section-churn",old,churn,n/10+half)
    let allNew = old.enumerated().map { s, section in
        UISection(model:UIHeader(id:s+10),elements:changed(section.elements))
    }
    add("replace-all-sections",old,allNew,n)
    let flatOld = [UISection(model:UIHeader(id:0),elements:values)]
    add("rotate-control",flatOld,[UISection(model:UIHeader(id:0),elements:Array(values.dropFirst())+Array(values.prefix(1)))],1)
    return result
}

func scaleFixtures(_ n: Int) -> [ScaleCase] {
    generalFixtures(n) + sectionFixtures(n)
}
