# Created by weixi on 2026/11/09.
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).parent
def command(*args):
    return subprocess.check_output(args, text=True).strip()

data = json.loads((root / 'clean/environment.json').read_text())
for key in ['differenceKitCommit', 'sourceHashes', 'previousBenchmark', 'selectedSimulator', 'otherBootedDevices']:
    data.pop(key, None)
devices = json.loads(command('xcrun', 'simctl', 'list', 'devices', 'booted', '-j'))
booted = [(runtime, d['name'], d['udid']) for runtime, ds in devices['devices'].items() for d in ds]
data.update({
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'paradeCommit': command('git', '-C', '/Users/sunshiwei/Develop/Parade', 'rev-parse', 'HEAD'),
    'paradeStatus': command('git', '-C', '/Users/sunshiwei/Develop/Parade', 'status', '--porcelain'),
    'xcode': command('xcodebuild', '-version'),
    'swift': command('xcrun', 'swift', '--version'),
    'hostCPU': command('sysctl', '-n', 'machdep.cpu.brand_string'),
    'selectedSimulator': next(x for x in booted if x[1] == 'iPhone 18 Pro'),
    'otherBootedDevices': [x for x in booted if x[1] != 'iPhone 18 Pro'],
    'candidate': 'Rounds 1-4 consolidated; round 5 excluded',
    'sourceHashes': {str(p.relative_to(root / 'clean-package')): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted((root / 'clean-package/Sources').rglob('*.swift'))},
})
(root / 'clean/environment.json').write_text(json.dumps(data, indent=2) + '\n')
print(data['selectedSimulator'], 'production clean:', not data['paradeStatus'])
