# Created by weixi on 2026/11/09.
from pathlib import Path
import json

root = Path(__file__).parent
rows = json.loads((root / 'summary.json').read_text())
assert len(rows) == 372 and all(r['runs'] == 3 for r in rows)
lookup = {(r['n'], r['scenario'], r['engine']): r for r in rows}
engines = ['Current-staged', 'Current-Apple-adapter', 'Current-Apple-background', 'Current-ListKit']
general = ['no-op']
labels = {'no-op': '内容相同的新快照', 'rotate-left-1': '左旋一项', 'rotate-right-1': '右旋一项',
          'shuffle': '随机打乱', 'section-rotate-left': 'Section 左旋',
          'cross-section-update-pct5': '已有 Section 跨组移动并更新 5%',
          'new-section-move1': '新建 Section，移入并更新一项',
          'new-section-move5pct': '新建 Section，移入并更新 5%',
          'delete-section-transfer': '删除 Section，迁出并更新其中全部 Item',
          'replace-section': '替换一个 Section，保留并更新其 Item',
          'existing-cross-update': '已有 Section 跨组迁移并更新（短 ID）',
          'section-reorder-transfer': 'Section 重排与跨组迁移',
          'section-churn': 'Section 增删、重排与跨组迁移混合',
          'replace-all-sections': '全部 Section 替换，保留并更新全部 Item',
          'rotate-control': '左旋一项对照（短 ID）'}
for operation, title in [('append', '追加'), ('delete', '删除'), ('update', '更新'), ('mixed', '增删改移混合')]:
    for mode, amount in [('fixed5', '固定 5 项'), ('pct5', '5%'), ('pct25', '25%'), ('pct50', '50%')]:
        name = operation + '-' + mode
        general.append(name)
        labels[name] = title + amount
general += ['rotate-left-1', 'rotate-right-1', 'shuffle', 'section-rotate-left', 'cross-section-update-pct5']
section = ['new-section-move1', 'new-section-move5pct', 'delete-section-transfer', 'replace-section',
           'existing-cross-update', 'section-reorder-transfer', 'section-churn', 'replace-all-sections', 'rotate-control']
assert len(general) == 22 and len(section) == 9
text = ['# 前四轮合并后的统一对比', '',
        '2026-11-09。所有行来自同一套整理后源码、同一二进制的本轮重新运行。第五轮原位 Section 替换未加入。Parade 生产仓库与默认装配不变。', '',
        '单位为毫秒，取三个独立进程各自十次正式样本中位数的中位数。每行四个后端来自同一组进程；原生后台是 completion API 的运行时实验，SDK 隔离注解问题仍未解决。', '',
        '这是共享 Parade Presenter 捕获、注册、视图桥接后的完整适配路径，包含目标准备、apply 完成等待与同步布局；不含业务 SectionController 捕获、外层队列等待及计时后的 host 基线替换。模拟器、无动画、简单 Label Cell，不代表真实首页帧时间。', '',
        '原来的两套 fixture 原样保留：一般场景使用较长 ID，复杂 Section 场景使用短 ID。因此两个左旋、两个已有跨组场景分别保留，不把不同输入合成一行。', '']
for n in [100, 1000, 10000]:
    text += [f'## {n:,} 项', '']
    for title, scenarios in [('一般更新', general), ('复杂 Section', section)]:
        text += [f'### {title}', '', '| 场景 | 整理后临时版 | 原生主线程 | 原生后台 | ListKit |', '|---|---:|---:|---:|---:|']
        for scenario in scenarios:
            values = [lookup[n, scenario, e]['totalMs'] for e in engines]
            text.append('| ' + labels[scenario] + ' | ' + ' | '.join(f'{v:.3f}' for v in values) + ' |')
        text.append('')
text += ['## 状态与操作', '',
         '每次计时前选中第一条消息，31 个 fixture 都保留该身份。完整输入身份、数量和可见 Cell 内容均逐次校验，所有计时样本 reloadData 为零。', '',
         '| 后端 | 选中状态失败／正式样本 |', '|---|---:|']
for e in engines:
    selected = [r for r in rows if r['engine'] == e]
    text.append(f"| {e} | {sum(r['selectionFailures'] for r in selected)}／{sum(r['samples'] for r in selected)} |")
text += ['', 'ListKit 的失败仍集中在跨新建／删除 Section 的六类场景。此表描述原始 ListKit 适配的实测行为，不表示它无法通过额外逻辑补齐。', '',
         '以下为一万项样本的操作中位数。Cell 对象比较只涉及更新前后均可见的同身份 Cell，不把屏幕外 Item 当作已实例化 Cell。', '',
         '| 场景 | 后端 | 批次 | Item move | reconfigure 项数 | 比较／保留的可见 Cell |', '|---|---|---:|---:|---:|---:|']
for s in ['update-pct50', 'rotate-left-1', 'new-section-move1', 'section-churn', 'replace-all-sections']:
    for e in engines:
        r = lookup[10000, s, e]
        text.append(f"| {labels[s]} | {e} | {r['batches']:g} | {r['itemMoves']:g} | {r['reconfiguredItems']:g} | {r['comparedCells']:g}／{r['reusedCells']:g} |")
text += ['', '完整精度、三个进程各自中位数见 summary.json；逐次样本见 reproduction.zip。没有用单轮较低数字替换整组统计，也没有跨轮挑选对照。', '']
(root / 'comparison.md').write_text('\n'.join(text))
print('Wrote comparison.md')
