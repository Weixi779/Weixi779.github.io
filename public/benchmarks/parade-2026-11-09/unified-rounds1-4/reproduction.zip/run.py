# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,shutil,random,sys
root=Path(__file__).parent
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro')
variants=sys.argv[1].split(',');ns=list(map(int,sys.argv[2].split(',')));reps=list(map(int,sys.argv[3].split(',')))
containers={}
subprocess.run(['xcrun','simctl','bootstatus',u,'-b'],check=True)
for v in variants:
 r=root/v;bundle='dev.weixi.ParadeUnified'+v+'20261109'
 subprocess.run(['xcrun','simctl','install',u,str(r/'ArticleBench.app')],check=True)
 containers[v]=Path(subprocess.check_output(['xcrun','simctl','get_app_container',u,bundle,'data'],text=True).strip())
for rep in reps:
 for n in ns:
  order=variants.copy();random.Random(rep*821+n).shuffle(order)
  for v in order:
   r=root/v;bundle='dev.weixi.ParadeUnified'+v+'20261109';name=f'unified-{n}-{rep}';output=r/(name+'.json')
   if output.exists() and json.loads(output.read_text()).get('complete'):continue
   print('START',v,n,rep,flush=True)
   with (r/(name+'.log')).open('w') as f:p=subprocess.run(['xcrun','simctl','launch','--console','--terminate-running-process',u,bundle,str(rep),str(n)],stdout=f,stderr=subprocess.STDOUT,timeout=900)
   raw=containers[v]/'Documents'/output.name
   if raw.exists():shutil.copy2(raw,output)
   assert p.returncode==0 and output.exists(),v+' '+name
   d=json.loads(output.read_text());assert d['complete'] and len(d['records'])==124
   print('DONE',v,n,rep,flush=True)
