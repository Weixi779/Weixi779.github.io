# Created by weixi on 2026/11/09.
from pathlib import Path
import csv
import json
import statistics

root = Path(__file__).parent
groups = {}
for p in sorted((root / 'clean').glob('unified-*-*.json')):
    data = json.loads(p.read_text())
    if data['repetition'] == 0:
        continue
    assert data['complete'] and len(data['records']) == 124
    for record in data['records']:
        samples = record['samples']
        assert len(samples) == 10 and all(s['reloadCalls'] == 0 for s in samples)
        metrics = {k: statistics.median(s[k] for s in samples)
                   for k in samples[0] if k != 'selectionPreserved'}
        key = record['n'], record['scenario'], record['engine']
        groups.setdefault(key, []).append({
            'repetition': data['repetition'], 'samples': len(samples),
            'selectionFailures': sum(not s['selectionPreserved'] for s in samples),
            **metrics,
        })
rows = []
for (n, scenario, engine), runs in sorted(groups.items()):
    keys = set(runs[0]) - {'repetition', 'samples', 'selectionFailures'}
    rows.append({
        'variant': 'clean', 'n': n, 'scenario': scenario, 'engine': engine,
        'runs': len(runs), 'samples': sum(r['samples'] for r in runs),
        'selectionFailures': sum(r['selectionFailures'] for r in runs),
        **{k: statistics.median(r[k] for r in runs) for k in sorted(keys)},
        'runMedians': runs,
    })
(root / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
columns = ['variant', 'n', 'scenario', 'engine', 'runs', 'samples', 'selectionFailures']
columns += sorted(set().union(*(r.keys() for r in rows)) - set(columns) - {'runMedians'})
with (root / 'summary.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
print('groups', len(rows), 'samples', sum(r['samples'] for r in rows))
