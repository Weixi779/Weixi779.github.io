# Created by weixi on 2026/11/09.
from pathlib import Path
import subprocess,json,shutil,sys
r=Path(__file__).parent;d=r/(sys.argv[1]+'-package')
inv=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','booted','-j']))
u=next(d['udid'] for ds in inv['devices'].values() for d in ds if d['name']=='iPhone 18 Pro')
base=['xcodebuild','-scheme','Parade','-destination',f'platform=iOS Simulator,id={u}','-derivedDataPath',str(d/'DerivedData'),'-parallel-testing-enabled','NO','CODE_SIGNING_ALLOWED=NO']
for stage,args in [('build', ['build-for-testing']),('test',['-resultBundlePath',str(d/'VerifiedClean.xcresult'),'-collect-test-diagnostics','never','test-without-building'])]:
 with (d/(stage+'.log')).open('w') as f:p=subprocess.run(base+args,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 print(stage,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
