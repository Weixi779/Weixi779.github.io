# Created by weixi on 2026/11/09.
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).parent
production = Path('/Users/sunshiwei/Develop/Parade')
package = root / 'clean-package'
bench = root / 'clean'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def declarations(text):
    result = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.search(r'\b(public|open)\s', line) and not line.lstrip().startswith('//'):
            value = line.strip()
            while '{' not in value and value.count('(') > value.count(')'):
                i += 1
                value += ' ' + lines[i].strip()
            result.append(value.split('{')[0].strip())
    return result

production_status = subprocess.check_output(['git', '-C', str(production), 'status', '--porcelain'], text=True)
assert not production_status
head = subprocess.check_output(['git', '-C', str(production), 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'dedfb5907f54890b3e0b11da99610e933cea5508'
assertions = {}
for p in (production / 'Sources').rglob('*.swift'):
    q = package / p.relative_to(production)
    assert declarations(p.read_text()) == declarations(q.read_text()), p
for p in (package / 'Sources/Parade').rglob('*.swift'):
    q = bench / 'Sources/Parade' / p.relative_to(package / 'Sources/Parade')
    assert p.read_bytes() == q.read_bytes(), p
    for forbidden in ['SpikeTimings', 'StructureProfile', 'WorkerPresenter', 'PreparedSectionedDiff', 'canReuseSectionSlots', 'reusesSectionSlots']:
        assert forbidden not in p.read_text(), (p, forbidden)
for rel in ['Collection/CollectionOrchestrator.swift', 'DataSource/Staged/CollectionOrchestrator+Staged.swift',
            'DataSource/Diffable/DiffableCollectionDataSource.swift', 'Diff/SectionedDiff.swift',
            'UIKit/CollectionViewBridge.swift', 'Section/Store/SectionStore.swift', 'Cell/AnyCellPresenter.swift']:
    p = production / 'Sources/Parade' / rel
    q = package / 'Sources/Parade' / rel
    assert p.read_bytes() == q.read_bytes()
    assertions[rel] = 'byte-identical to production'
log = (package / 'test.log').read_text()
match = re.search(r'Test run with (\d+) tests in (\d+) suites passed after ([\d.]+) seconds', log)
assert match and match.group(1) == '164' and '** TEST EXECUTE SUCCEEDED **' in log
assert '✘' not in log
rows = json.loads((root / 'summary.json').read_text())
assert len(rows) == 372
assert all(r['runs'] == 3 and r['samples'] == 30 and r['reloadCalls'] == 0 for r in rows)
for r in rows:
    if r['engine'] != 'Current-ListKit':
        assert r['selectionFailures'] == 0, r
    if r['engine'] == 'Current-staged' and r['scenario'] == 'replace-all-sections':
        assert r['itemMoves'] == r['n'], r
source_hashes = {str(p.relative_to(package)): digest(p) for p in sorted((package / 'Sources').rglob('*.swift'))}
environment = json.loads((bench / 'environment.json').read_text())
assert source_hashes == environment['sourceHashes']
assert digest(bench / 'ArticleBench.app/ArticleBench') == environment['binarySHA256']
assert all(digest(bench / p) == sha for p, sha in environment['allSourceHashes'].items())
subprocess.run(['git', '-C', str(production), 'apply', '--check', str(root / 'patches/library.patch'), str(root / 'patches/tests.patch')], check=True)
report = {
    'productionCommit': head, 'productionClean': True, 'fifthRoundExcluded': True,
    'publicDeclarationTextUnchanged': True, 'note': 'Source declaration comparison, not a binary ABI audit.',
    'benchmarkAndTestLibraryByteIdentical': True, 'unchangedOwnersAndEntrypoints': assertions,
    'tests': {'count': 164, 'suites': 14, 'seconds': float(match.group(3))},
    'fixtures': 31, 'sizes': [100, 1000, 10000], 'repetitions': 3,
    'formalSamples': sum(r['samples'] for r in rows),
    'smokeSamples': 372,
    'selectionFailures': {e: sum(r['selectionFailures'] for r in rows if r['engine'] == e) for e in sorted({r['engine'] for r in rows})},
    'patchesApplyToProduction': True, 'sourceHashes': source_hashes,
}
(root / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'sourceHashes'}, indent=2))
